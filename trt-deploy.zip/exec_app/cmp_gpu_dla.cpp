#include "common.h"
#include "base_eng.h"

void buildGPU(engine::BaseEnginePtr model_p, std::vector<char> serial_data, 
            std::string output_eng_path, std::string build_type, std::string fallback_type, bool rebuild_flag){
    std::cout<<"start build gpu"<<std::endl;
    model_p->buildEngineModel(serial_data.data(), 0, output_eng_path, build_type, fallback_type, -1, rebuild_flag);
    std::cout<<"end build gpu"<<std::endl;
}

void buildDLA(engine::BaseEnginePtr model_p, std::vector<char> serial_data, 
            std::string output_eng_path, std::string build_type, std::string fallback_type, bool rebuild_flag){
    std::cout<<"start build dla"<<std::endl;
    model_p->buildEngineModel(serial_data.data(), 0, output_eng_path, build_type, fallback_type, 0, rebuild_flag);
    std::cout<<"end build dla"<<std::endl;
}

std::vector<std::vector<int8_t>> computeTestCPUS8AF16(int layers_num, std::vector<int> kernel_size, std::vector<int> in_channels, std::vector<int> out_channels,
                    std::vector<int8_t> input, half input_scale, std::vector<half> layer_out_scales, std::vector<std::vector<half>> weight,
                    int h, int w){
    //suppose tensor shape is always the same, kernel_size is always odd
    //here scale = 127/amax
    std::vector<std::vector<int8_t>> weight_s8(layers_num);
    std::vector<std::vector<half>> weight_scale(layers_num);
    std::vector<int8_t> layer_input;
    std::vector<int8_t> layer_output = input;
    half layer_input_scale;
    half layer_output_scale = input_scale;
    std::vector<std::vector<int8_t>> layers_output(layers_num);
    for (int i = 0; i < layers_num; i++){
        weight_scale[i].resize(out_channels[i], static_cast<half>(0.0f));
        for (int oc = 0; oc < out_channels[i]; oc++){
            int rsc = weight[i].size() / out_channels[i];
            for (int j = 0; j < rsc; j++){
                half tmp = weight[i][oc*rsc + j];
                if (tmp < static_cast<half>(0.0f)) tmp = -tmp;
                if (tmp > weight_scale[i][oc]) weight_scale[i][oc] = tmp;
            }
        }
        weight_s8[i].resize(weight[i].size()); //-> use 4 drop 5 in
        for (int oc = 0; oc < out_channels[i]; oc++){
            int rsc = weight[i].size() / out_channels[i];
            half scale = static_cast<half>(127.0f) / weight_scale[i][oc];
            for (int j = 0; j < rsc; j++){
                half tmp = weight[i][oc*rsc + j];
                tmp = tmp * scale;
                if (tmp < static_cast<half>(0.0f)) tmp = tmp - static_cast<half>(0.5f);
                else tmp = tmp + static_cast<half>(0.5f);
                weight_s8[i][oc*rsc + j] = static_cast<int8_t>(tmp);
            }
            // std::cout<<scale<<' '<<weight_scale[i][oc]<<' '<<weight_scale[i][oc] / static_cast<half>(127.0f)<<std::endl;
        }
        // std::cout<<std::endl;
        int out_channel = out_channels[i];
        int in_channel = in_channels[i];
        int layer_kernel_size = kernel_size[i];
        layer_input_scale = layer_output_scale;
        layer_output_scale = layer_out_scales[i];
        layer_input = layer_output;
        layer_output.resize(layer_input.size() * out_channel / in_channel);
        for (int oc = 0; oc < out_channel; oc++){
            half weight_oc_scale = static_cast<half>(127.0f) / weight_scale[i][oc];
            for (int h_id = 0; h_id < h; h_id++){
                for (int w_id = 0; w_id < w; w_id++){
                    int16_t res = 0;
                    for (int kh = 0; kh < layer_kernel_size; kh++){
                        int src_h_id = h_id + kh - layer_kernel_size / 2;
                        // src_h_id = std::max(0, std::min(src_h_id, h - 1));
                        if (src_h_id < 0 || src_h_id >= h) continue;
                        for (int kw = 0; kw < layer_kernel_size; kw++){
                            int src_w_id = w_id + kw - layer_kernel_size / 2;
                            // src_w_id = std::max(0, std::min(src_w_id, w - 1));
                            if (src_w_id < 0 || src_w_id >= w) continue;
                            for (int ic = 0; ic < in_channel; ic++){
                                res = res + layer_input[ic*h*w + src_h_id*w + src_w_id] * weight_s8[i][oc*in_channel*layer_kernel_size*layer_kernel_size 
                                                                                                    + ic*layer_kernel_size*layer_kernel_size
                                                                                                    + kh*layer_kernel_size + kw];
                            }
                        }
                    }
                    half res_f16 = static_cast<half>(static_cast<float>(res)) * (layer_output_scale / layer_input_scale / weight_oc_scale);
                    if (res_f16 > static_cast<half>(0.0f)) layer_output[oc*h*w + h_id*w + w_id] = static_cast<int8_t>(res_f16 + static_cast<half>(0.5f));
                    else layer_output[oc*h*w + h_id*w + w_id] = static_cast<int8_t>(res_f16 - static_cast<half>(0.5f));
                }
            }
        }
        layers_output[i] = layer_output;
    }
    return layers_output;
}

std::vector<std::vector<int8_t>> computeTestCPUS8AF16(int layers_num, std::vector<int> kernel_size, std::vector<int> in_channels, std::vector<int> out_channels,
                    std::vector<int8_t> input, half input_scale, std::vector<half> layer_out_scales, std::vector<std::vector<float>> weight,
                    int h, int w){
    //suppose tensor shape is always the same, kernel_size is always odd
    //here scale = 127/amax
    std::vector<std::vector<int8_t>> weight_s8(layers_num);
    std::vector<std::vector<float>> weight_scale(layers_num);
    std::vector<int8_t> layer_input;
    std::vector<int8_t> layer_output = input;
    half layer_input_scale;
    half layer_output_scale = input_scale;
    std::vector<std::vector<int8_t>> layers_output(layers_num);
    for (int i = 0; i < layers_num; i++){
        weight_scale[i].resize(out_channels[i], 0.0f);
        for (int oc = 0; oc < out_channels[i]; oc++){
            int rsc = weight[i].size() / out_channels[i];
            for (int j = 0; j < rsc; j++){
                float tmp = weight[i][oc*rsc + j];
                if (tmp < 0.0f) tmp = -tmp;
                if (tmp > weight_scale[i][oc]) weight_scale[i][oc] = tmp;
            }
        }
        weight_s8[i].resize(weight[i].size()); //-> use 4 drop 5 in
        for (int oc = 0; oc < out_channels[i]; oc++){
            int rsc = weight[i].size() / out_channels[i];
            float scale = 127.0f / weight_scale[i][oc];
            for (int j = 0; j < rsc; j++){
                float tmp = weight[i][oc*rsc + j];
                tmp = tmp * scale;
                if (tmp < 0.0f) tmp = tmp - 0.5f;
                else tmp = tmp + 0.5f;
                weight_s8[i][oc*rsc + j] = static_cast<int8_t>(tmp);
            }
            // std::cout<<scale<<' '<<weight_scale[i][oc]<<' '<<weight_scale[i][oc] / static_cast<half>(127.0f)<<std::endl;
        }
        // std::cout<<std::endl;
        int out_channel = out_channels[i];
        int in_channel = in_channels[i];
        int layer_kernel_size = kernel_size[i];
        layer_input_scale = layer_output_scale;
        layer_output_scale = layer_out_scales[i];
        layer_input = layer_output;
        layer_output.resize(layer_input.size() * out_channel / in_channel);
        for (int oc = 0; oc < out_channel; oc++){
            half weight_oc_scale = static_cast<half>(127.0f / weight_scale[i][oc]);
            for (int h_id = 0; h_id < h; h_id++){
                for (int w_id = 0; w_id < w; w_id++){
                    int res = 0;
                    for (int kh = 0; kh < layer_kernel_size; kh++){
                        int src_h_id = h_id + kh - layer_kernel_size / 2;
                        // src_h_id = std::max(0, std::min(src_h_id, h - 1));
                        if (src_h_id < 0 || src_h_id >= h) continue;
                        for (int kw = 0; kw < layer_kernel_size; kw++){
                            int src_w_id = w_id + kw - layer_kernel_size / 2;
                            // src_w_id = std::max(0, std::min(src_w_id, w - 1));
                            if (src_w_id < 0 || src_w_id >= w) continue;
                            for (int ic = 0; ic < in_channel; ic++){
                                res = res + layer_input[ic*h*w + src_h_id*w + src_w_id] * weight_s8[i][oc*in_channel*layer_kernel_size*layer_kernel_size 
                                                                                                    + ic*layer_kernel_size*layer_kernel_size
                                                                                                    + kh*layer_kernel_size + kw];
                            }
                        }
                    }
                    half res_f16 = static_cast<half>(static_cast<float>(res)) * (layer_output_scale / layer_input_scale / weight_oc_scale);
                    if (res_f16 > static_cast<half>(0.0f)) layer_output[oc*h*w + h_id*w + w_id] = static_cast<int8_t>(res_f16 + static_cast<half>(0.5f));
                    else layer_output[oc*h*w + h_id*w + w_id] = static_cast<int8_t>(res_f16 - static_cast<half>(0.5f));
                }
            }
        }
        layers_output[i] = layer_output;
    }
    return layers_output;
}

std::vector<std::vector<int8_t>> computeTestCPUS8AF32(int layers_num, std::vector<int> kernel_size, std::vector<int> in_channels, std::vector<int> out_channels,
                    std::vector<int8_t> input, float input_scale, std::vector<float> layer_out_scales, std::vector<std::vector<float>> weight,
                    int h, int w){
    //suppose tensor shape is always the same, kernel_size is always odd
    //here scale = 127/amax
    std::vector<std::vector<int8_t>> weight_s8(layers_num);
    std::vector<std::vector<float>> weight_scale(layers_num);
    std::vector<int8_t> layer_input;
    std::vector<int8_t> layer_output = input;
    float layer_input_scale;
    float layer_output_scale = input_scale;
    std::vector<std::vector<int8_t>> layers_output(layers_num);
    for (int i = 0; i < layers_num; i++){
        weight_scale[i].resize(out_channels[i], 0.0f);
        for (int oc = 0; oc < out_channels[i]; oc++){
            int rsc = weight[i].size() / out_channels[i];
            for (int j = 0; j < rsc; j++){
                float tmp = weight[i][oc*rsc + j];
                if (tmp < 0.0f) tmp = -tmp;
                if (tmp > weight_scale[i][oc]) weight_scale[i][oc] = tmp;
            }
        }
        weight_s8[i].resize(weight[i].size()); //-> use 4 drop 5 in
        for (int oc = 0; oc < out_channels[i]; oc++){
            int rsc = weight[i].size() / out_channels[i];
            float scale = 127.0f / weight_scale[i][oc];
            for (int j = 0; j < rsc; j++){
                float tmp = weight[i][oc*rsc + j];
                tmp = tmp * scale;
                if (tmp < 0.0f) tmp = tmp - 0.5f;
                else tmp = tmp + 0.5f;
                weight_s8[i][oc*rsc + j] = static_cast<int8_t>(tmp);
            }
            // std::cout<<scale<<' '<<weight_scale[i][oc]<<' '<<weight_scale[i][oc] / 127.0f<<std::endl;
        }
        // std::cout<<std::endl;
        int out_channel = out_channels[i];
        int in_channel = in_channels[i];
        int layer_kernel_size = kernel_size[i];
        layer_input_scale = layer_output_scale;
        layer_output_scale = layer_out_scales[i];
        layer_input = layer_output;
        layer_output.resize(layer_input.size() * out_channel / in_channel);
        for (int oc = 0; oc < out_channel; oc++){
            float weight_oc_scale = 127.0f / weight_scale[i][oc];
            for (int h_id = 0; h_id < h; h_id++){
                for (int w_id = 0; w_id < w; w_id++){
                    int res = 0;
                    for (int kh = 0; kh < layer_kernel_size; kh++){
                        int src_h_id = h_id + kh - layer_kernel_size / 2;
                        // src_h_id = std::max(0, std::min(src_h_id, h - 1));
                        if (src_h_id < 0 || src_h_id >= h) continue;
                        for (int kw = 0; kw < layer_kernel_size; kw++){
                            int src_w_id = w_id + kw - layer_kernel_size / 2;
                            // src_w_id = std::max(0, std::min(src_w_id, w - 1));
                            if (src_w_id < 0 || src_w_id >= w) continue;
                            for (int ic = 0; ic < in_channel; ic++){
                                res = res + layer_input[ic*h*w + src_h_id*w + src_w_id] * weight_s8[i][oc*in_channel*layer_kernel_size*layer_kernel_size 
                                                                                                    + ic*layer_kernel_size*layer_kernel_size
                                                                                                    + kh*layer_kernel_size + kw];
                            }
                        }
                    }
                    float res_f16 = res * (layer_output_scale / layer_input_scale / weight_oc_scale);
                    if (res_f16 > 0.0f) layer_output[oc*h*w + h_id*w + w_id] = static_cast<int8_t>(res_f16 + 0.5f);
                    else layer_output[oc*h*w + h_id*w + w_id] = static_cast<int8_t>(res_f16 - 0.5f);
                }
            }
        }
        layers_output[i] = layer_output;
    }
    return layers_output;
}

int main(int argc, char *argv[]){
    std::string cfg_path = argv[1];
    std::ifstream json_file(cfg_path);
    nlohmann::json config;
    json_file >> config;
    std::vector<nlohmann::json> engines = config.at("engines").get<std::vector<nlohmann::json>>();
    std::unordered_map<std::string, int> ele_type_size_table = {{"float", 4}, {"float16", 2}, {"int8", 1}};
    for (int engine_id = 0; engine_id < engines.size(); engine_id++){
        nlohmann::json engine_config = engines[engine_id];
        std::string engine_name = engine_config.at("eng_name").get<std::string>();
        std::string input_net_path = engine_config.at("net_path").get<std::string>();
        std::string gpu_output_eng_path = engine_config.at("gpu_eng_path").get<std::string>();
        std::string dla_output_eng_path = engine_config.at("dla_eng_path").get<std::string>();
        bool rebuild_flag = engine_config.at("rebuild").get<bool>();
        std::string build_type = engine_config.at("build_type").get<std::string>();
        std::string fallback_type = engine_config.at("fallback_type").get<std::string>();
        std::vector<char> serial_data = common::loadDataFromFile<char, char>(input_net_path);
        std::string engine_type = "TRTEngine";
        engine::BaseEnginePtr gpu_model_p = engine::EngineFactory::createEngineInstance(engine_type);
        engine::BaseEnginePtr dla_model_p = engine::EngineFactory::createEngineInstance(engine_type);
        buildGPU(gpu_model_p, serial_data, gpu_output_eng_path, build_type, fallback_type, rebuild_flag);
        buildDLA(dla_model_p, serial_data, dla_output_eng_path, build_type, fallback_type, rebuild_flag);
        std::vector<nlohmann::json> inputs_config = engine_config.at("inputs").get<std::vector<nlohmann::json>>();
        std::vector<nlohmann::json> outputs_config = engine_config.at("outputs").get<std::vector<nlohmann::json>>();
        int inputs_num = inputs_config.size();
        int outputs_num = outputs_config.size();
        std::vector<std::vector<char>> inputs_data(inputs_num);
        std::vector<std::vector<int8_t>> inputs_data_s8(inputs_num);
        std::vector<std::vector<half>> inputs_data_f16(inputs_num);
        std::vector<float> inputs_amax(inputs_num);
        std::vector<memory::BaseBufferPtr> inputs_buffer_p(inputs_num, nullptr);
        std::vector<std::string> inputs_name(inputs_num);
        std::vector<std::vector<int64_t>> inputs_shape(inputs_num);
        std::vector<int> inputs_ele_num(inputs_num);
        for (int i = 0; i < inputs_num; i++){
            std::string input_data_path = inputs_config[i].at("file_path").get<std::string>();
            inputs_shape[i] = inputs_config[i].at("shape").get<std::vector<int64_t>>();
            inputs_amax[i] = inputs_config[i].at("amax").get<float>();
            int input_byte_size;
            if (input_data_path == ""){
                input_byte_size = ele_type_size_table.at(inputs_config[i].at("type").get<std::string>());
                for (int j = 0; j < inputs_shape[i].size(); j++) input_byte_size *= inputs_shape[i][j];
                inputs_data[i].resize(input_byte_size);
            }
            else{
                inputs_data[i] = common::loadDataFromFile<char, char>(input_data_path);
                input_byte_size = inputs_data[i].size();
            }
            int ele_size = ele_type_size_table.at(inputs_config[i].at("type").get<std::string>());
            std::string buffer_name = inputs_config[i].at("name").get<std::string>();
            inputs_data_s8[i].resize(input_byte_size / ele_size);
            inputs_data_f16[i].resize(input_byte_size / ele_size);
            float scale = inputs_amax[i] / 127.0f;
            std::cout<<scale<<std::endl;//cast may cause error
            for (int j = 0; j < input_byte_size / ele_size; j++){
                inputs_data_f16[i][j] = static_cast<half>(reinterpret_cast<float*>(inputs_data[i].data())[j]);
                inputs_data_s8[i][j] = 
                // 0;
                static_cast<int8_t>(reinterpret_cast<float*>(inputs_data[i].data())[j] / scale + 0.5f);
                // inputs_data_f16[i][j] = static_cast<half>(static_cast<float>(reinterpret_cast<int8_t*>(inputs_data[i].data())[j]));
                // inputs_data_s8[i][j] = reinterpret_cast<int8_t*>(inputs_data[i].data())[j];
            }
            // for (int j = 5; j < 10; j++){
            //     inputs_data_s8[i][64 + j] = 64;
            //     inputs_data_s8[i][64*2 + j] = 64;
            //     inputs_data_s8[i][64*3 + j] = 64;
            //     inputs_data_s8[i][64*4 + j] = 64;
            //     inputs_data_s8[i][64*5 + j] = 64;
            // } 
            if (build_type == "int8"){
                int sum = 0;
                for (int j = 0; j < inputs_data_s8[i].size(); j++) sum += std::abs(inputs_data_s8[i][j]);
                std::cout<<sum<<' '<<float(sum) / float(inputs_data_s8[i].size())<<std::endl;
                inputs_buffer_p[i] = std::make_shared<memory::GPUBuffer>(buffer_name, input_byte_size / ele_size);
                inputs_buffer_p[i]->copyFromCPU(inputs_data_s8[i].data(), input_byte_size / ele_size);
            }
            else{
                inputs_buffer_p[i] = std::make_shared<memory::GPUBuffer>(buffer_name, input_byte_size / ele_size * sizeof(half));
                inputs_buffer_p[i]->copyFromCPU(inputs_data_f16[i].data(), input_byte_size / ele_size * sizeof(half));
            }
            inputs_name[i] = buffer_name;
            inputs_ele_num[i] = input_byte_size / ele_size;
        }
        std::vector<memory::BaseBufferPtr> outputs_buffer_p(outputs_num, nullptr);
        std::vector<std::vector<int64_t>> outputs_shape(outputs_num);
        std::vector<std::string> outputs_name(outputs_num);
        std::vector<int> outputs_ele_num(outputs_num);
        std::vector<float> outputs_amax(outputs_num);
        for (int i = 0; i < outputs_num; i++){
            std::cout<<i<<std::endl;
            outputs_shape[i] = outputs_config[i].at("shape").get<std::vector<int64_t>>();
            outputs_amax[i] = outputs_config[i].at("amax").get<float>();
            
            int output_byte_size;
            output_byte_size = ele_type_size_table.at(outputs_config[i].at("type").get<std::string>());

            for (int j = 0; j < outputs_shape[i].size(); j++) output_byte_size *= outputs_shape[i][j];
            int ele_size = ele_type_size_table.at(outputs_config[i].at("type").get<std::string>());
            
            std::string buffer_name = outputs_config[i].at("name").get<std::string>();
            if (build_type == "int8") outputs_buffer_p[i] = std::make_shared<memory::GPUBuffer>(buffer_name, output_byte_size / ele_size);
            else outputs_buffer_p[i] = std::make_shared<memory::GPUBuffer>(buffer_name, output_byte_size / ele_size * sizeof(half));
            outputs_buffer_p[i]->setZeros();
            outputs_name[i] = buffer_name;
            outputs_ele_num[i] = output_byte_size / ele_size;
            std::cout<<buffer_name<<std::endl;
        }
        gpu_model_p->setDeviceId(0);
        gpu_model_p->setEngineIONumber(inputs_num, outputs_num);
        gpu_model_p->setStreamInternal();
        gpu_model_p->setEngineName(engine_name);
        gpu_model_p->setInputsShape(inputs_shape);
        gpu_model_p->setOutputsShape(outputs_shape);
        gpu_model_p->setEngineIOBuffer(inputs_buffer_p, outputs_buffer_p);
        dla_model_p->setDeviceId(0);
        dla_model_p->setEngineIONumber(inputs_num, outputs_num);
        dla_model_p->setStreamInternal();
        dla_model_p->setEngineName(engine_name);
        dla_model_p->setInputsShape(inputs_shape);
        dla_model_p->setOutputsShape(outputs_shape);
        cudaDeviceSynchronize();
        std::cout<<"ready set"<<std::endl;

        gpu_model_p->loadEngineModel(gpu_output_eng_path, false, 0, -1);
        dla_model_p->loadEngineModel(dla_output_eng_path, true, 2, 0);
        cudaDeviceSynchronize();
        std::cout<<"ready load"<<std::endl;

        gpu_model_p->initEngineModel();
        dla_model_p->initEngineModel();
        cudaDeviceSynchronize();
        std::cout<<"ready init"<<std::endl;

        gpu_model_p->waitSignalAndLaunchEngine();
        gpu_model_p->syncAfterLaunchEngine();
        dla_model_p->waitSignalAndLaunchEngine();
        dla_model_p->syncAfterLaunchEngine();
        cudaDeviceSynchronize();
        std::cout<<"end test infer"<<std::endl;

        std::vector<std::vector<int8_t>> gpu_outputs_ref_data_s8(outputs_num);
        std::vector<std::vector<half>> gpu_outputs_ref_data_f16(outputs_num);
        for (int i = 0; i < outputs_num; i++){
            if (build_type == "int8"){
                gpu_outputs_ref_data_s8[i].resize(outputs_ele_num[i]);
                outputs_buffer_p[i]->copyToCPU(gpu_outputs_ref_data_s8[i].data(), gpu_outputs_ref_data_s8[i].size());
            }
            else{
                gpu_outputs_ref_data_f16[i].resize(outputs_ele_num[i]);
                outputs_buffer_p[i]->copyToCPU(gpu_outputs_ref_data_f16[i].data(), gpu_outputs_ref_data_f16[i].size() * sizeof(half));
            }
        }
        
        std::vector<void*> input_cpu_p_vec(inputs_num);
        std::vector<void*> input_gpu_p_vec(inputs_num);
        std::vector<uint64_t*> input_dla_p_vec(inputs_num);
        std::vector<int> input_size(inputs_num);
        std::vector<void*> output_cpu_p_vec(outputs_num);
        std::vector<void*> output_gpu_p_vec(outputs_num);
        std::vector<uint64_t*> output_dla_p_vec(outputs_num);
        std::vector<int> output_size(outputs_num);
        cudaStream_t stream = dla_model_p->getStream();

        for (int i = 0; i < inputs_num; i++){
            std::string input_name = inputs_name[i] + "'";
            input_cpu_p_vec[i] = dla_model_p->getCpuMemPtr(input_name);
            input_gpu_p_vec[i] = dla_model_p->getGpuMemPtr(input_name);
            input_dla_p_vec[i] = dla_model_p->getDlaMemPtr(input_name);
            input_size[i] = dla_model_p->getDlaMemSize(input_name);
            std::cout<<input_size[i]<<std::endl;
            int last_dim = inputs_shape[i][inputs_shape[i].size() - 1];
            int dla_last_dim = (last_dim + 63) / 64 * 64;
            int same_dim = input_size[i] / dla_last_dim;
            std::cout<<input_name<<": "<<same_dim<<' '<<last_dim<<' '<<dla_last_dim<<std::endl;
            if (dla_last_dim != last_dim) std::cout<<"warning: dla-format w not aligned, should modified input"<<std::endl;
        }

        for (int i = 0; i < outputs_num; i++){
            std::string output_name = outputs_name[i] + "'";
            output_cpu_p_vec[i] = dla_model_p->getCpuMemPtr(output_name);
            output_gpu_p_vec[i] = dla_model_p->getGpuMemPtr(output_name);
            output_dla_p_vec[i] = dla_model_p->getDlaMemPtr(output_name);
            output_size[i] = dla_model_p->getDlaMemSize(output_name);
            std::cout<<output_size[i]<<std::endl;
            int last_dim = outputs_shape[i][outputs_shape[i].size() - 1];
            int dla_last_dim = (last_dim + 63) / 64 * 64;
            int same_dim = output_size[i] / dla_last_dim;
            std::cout<<output_name<<": "<<same_dim<<' '<<last_dim<<' '<<dla_last_dim<<std::endl;
            if (dla_last_dim != last_dim) std::cout<<"warning: dla-format w not aligned, should modified output"<<std::endl;
        }

        for (int i = 0; i < outputs_num; i++) cudaMemsetAsync(output_gpu_p_vec[i], 0, output_size[i], stream);
        for (int i = 0; i < inputs_num; i++){
            if (build_type == "int8") cudaMemcpyAsync(input_gpu_p_vec[i], inputs_data_s8[i].data(), input_size[i], cudaMemcpyHostToDevice, stream);
            else cudaMemcpyAsync(input_gpu_p_vec[i], inputs_data_f16[i].data(), input_size[i], cudaMemcpyHostToDevice, stream);
        } 
        dla_model_p->waitSignalAndLaunchEngine();
        dla_model_p->syncAfterLaunchEngine();
        cudaStreamSynchronize(stream);
//====================
        // int layers_num = 10;
        // std::vector<int> kernel_size(layers_num, 3);
        // std::vector<int> in_channels = {4, 16, 16, 16, 16,
        //                                 16, 16, 16, 16, 16};
        // std::vector<int> out_channels = {16, 16, 16, 16, 16,
        //                                 16, 16, 16, 16, 16};
        // int h = 512;
        // int w = 512;
        // std::vector<std::string> weight_file_name = {"../weights/blocks.0.conv1.weight.bin",
        //                                             "../weights/blocks.0.conv2.weight.bin",
        //                                             "../weights/blocks.1.conv1.weight.bin",
        //                                             "../weights/blocks.1.conv2.weight.bin",
        //                                             "../weights/blocks.2.conv1.weight.bin",
        //                                             "../weights/blocks.2.conv2.weight.bin",
        //                                             "../weights/blocks.3.conv1.weight.bin",
        //                                             "../weights/blocks.3.conv2.weight.bin",
        //                                             "../weights/blocks.4.conv1.weight.bin",
        //                                             "../weights/blocks.4.conv2.weight.bin"};
        // half input_scale = static_cast<half>(127.0f / inputs_amax[0]);
        // std::vector<half> layer_out_scales(layers_num);
        // for (int i = 0; i < layers_num; i++) layer_out_scales[i] = static_cast<half>(127.0f / outputs_amax[i]);
        // // std::vector<std::vector<half>> weight(layers_num);
        // // for (int i = 0; i < layers_num; i++){
        // //     std::vector<char> weight_raw = common::loadDataFromFile<char, char>(weight_file_name[i]);
        // //     weight[i].resize(weight_raw.size()/sizeof(float));
        // //     for (int j = 0; j < weight[i].size(); j++) weight[i][j] = static_cast<half>(reinterpret_cast<float*>(weight_raw.data())[j]);
        // // }
        // // std::vector<std::vector<int8_t>> cpu_cal_res_s8 = computeTestCPUS8AF16(layers_num, kernel_size, in_channels, out_channels,
        // //                                             inputs_data_s8[0], input_scale, layer_out_scales, weight,
        // //                                             h, w);
        // float input_scale_f32 = 127.0f / inputs_amax[0];
        // std::vector<float> layer_out_scales_f32(layers_num);
        // for (int i = 0; i < layers_num; i++) layer_out_scales_f32[i] = 127.0f / outputs_amax[i];
        // std::vector<std::vector<float>> weight_f32(layers_num);
        // for (int i = 0; i < layers_num; i++){
        //     std::vector<char> weight_raw = common::loadDataFromFile<char, char>(weight_file_name[i]);
        //     weight_f32[i].resize(weight_raw.size()/sizeof(float));
        //     for (int j = 0; j < weight_f32[i].size(); j++) weight_f32[i][j] = reinterpret_cast<float*>(weight_raw.data())[j];
        // }
        // std::vector<std::vector<int8_t>> cpu_cal_f32_res_s8 = computeTestCPUS8AF32(layers_num, kernel_size, in_channels, out_channels,
        //                                             inputs_data_s8[0], input_scale_f32, layer_out_scales_f32, weight_f32,
        //                                             h, w);

        // std::vector<std::vector<int8_t>> cpu_cal_f16_res_s8 = computeTestCPUS8AF16(layers_num, kernel_size, in_channels, out_channels,
        //                                             inputs_data_s8[0], input_scale, layer_out_scales, weight_f32,
        //                                             h, w);
//====================
        if (build_type == "int8"){
            for (int i = 0; i < outputs_num; i++){
                // std::ofstream out_file;
                // std::string file_name = "../weights/layer_"+std::to_string(i)+".bin";
                // out_file.open(file_name, std::ios::binary);
                // out_file.write(reinterpret_cast<char*>(output_cpu_p_vec[i]), output_size[i]);
                // out_file.close();
                // std::cout<<"write file at "<<file_name<<std::endl;
                int max_err = 0;
                int err_sum = 0;
                int rec_res = 0;
                int rec_ref = 0;
                int abs_sum = 0;
                int max_ref = 0;
                int abs_sum_res = 0;
                int sum = 0;
                int sum_res = 0;
                std::vector<int> err_num_histro(128, 0);
                // std::cout<<cpu_cal_res_s8[i].size()<<' '<<output_size[i]<<std::endl;
                for (int j = 0; j < output_size[i]; j++){
                    int res = static_cast<int>(reinterpret_cast<int8_t*>(output_cpu_p_vec[i])[j]);
                    // int res = static_cast<int>(cpu_cal_f16_res_s8[i][j]);
                    int ref = static_cast<int>(gpu_outputs_ref_data_s8[i][j]);
                    // int ref = static_cast<int>(cpu_cal_f16_res_s8[i][j]);
                    int err = std::abs(res - ref);
                    err_sum += err;
                    abs_sum += std::abs(ref);
                    sum += ref;
                    abs_sum_res += std::abs(res);
                    sum_res += res;
                    if (max_err < err){
                        max_err = err;
                        rec_ref = ref;
                        rec_res = res;
                    }
                    if (std::abs(ref) > max_ref) max_ref = std::abs(ref);
                    err_num_histro[err] += 1;
                }
                for (int j = 0; j < 128; j++){
                    if (err_num_histro[j] > 0) std::cout<<"err histro "<<j<<": "<<err_num_histro[j]<<std::endl;
                }
                std::cout<<outputs_name[i]<<": max err: "<<max_err<<", ref: "<<rec_ref<<", res: "<<rec_res<<", sum err: "<<err_sum<<", abs sum: "<<abs_sum
                                            <<", sum ref: "<<sum<<std::endl;
                std::cout<<"max ref abs: " <<max_ref<<", ave. abs: "<<static_cast<float>(abs_sum) / static_cast<float>(output_size[i])<<std::endl;
                std::cout<<"dla res abs sum: "<<abs_sum_res<<", res sum: "<<sum_res<<std::endl;
                std::ofstream out_file;
                std::string file_name = "../weights/_dla_layer_"+std::to_string(i)+".bin";
                out_file.open(file_name, std::ios::binary);
                out_file.write(reinterpret_cast<char*>(output_cpu_p_vec[i]), output_size[i]);
                out_file.close();
                file_name = "../weights/gpu_layer_"+std::to_string(i)+".bin";
                out_file.open(file_name, std::ios::binary);
                out_file.write(reinterpret_cast<char*>(gpu_outputs_ref_data_s8[i].data()), output_size[i]);
                out_file.close();
            }
        }
        else{
            for (int i = 0; i < outputs_num; i++){
                double max_err = 0.0f;
                double err_sum = 0.0f;
                double rec_res = 0.0f;
                double rec_ref = 0.0f;
                double abs_sum = 0.0f;
                for (int j = 0; j < output_size[i] / sizeof(half); j++){
                    double res = static_cast<double>(reinterpret_cast<half*>(output_cpu_p_vec[i])[j]);
                    double ref = static_cast<double>(gpu_outputs_ref_data_f16[i][j]);
                    double err = std::abs(res - ref);
                    err_sum += err;
                    abs_sum += std::abs(ref);
                    if (max_err < err){
                        max_err = err;
                        rec_ref = ref;
                        rec_res = res;
                    }
                }
                std::cout<<outputs_name[i]<<": max err: "<<max_err<<", ref: "<<rec_ref<<", res: "<<rec_res<<", sum err: "<<err_sum<<", abs sum: "<<abs_sum<<std::endl;
            }
        }

        cudaStream_t gpu_stream = gpu_model_p->getStream();
        cudaStream_t dla_stream = dla_model_p->getStream();
        auto t0 = std::chrono::system_clock::now();
        for (int i = 0; i < 100; i++){
            gpu_model_p->waitSignalAndLaunchEngine();
            gpu_model_p->syncAfterLaunchEngine();
        }
        cudaStreamSynchronize(gpu_stream);
        auto t1 = std::chrono::system_clock::now();
        double duration0 = std::chrono::duration<double>(t1 - t0).count();
        duration0 *= 1000.0f;
        std::cout<<"gpu model 100 round total cost: "<<duration0 <<" ms"<<std::endl;
        std::cout<<"gpu model 100 round average cost: "<<duration0 / 100.0f<<" ms"<<std::endl;
        t0 = std::chrono::system_clock::now();
        for (int i = 0; i < 100; i++){
            dla_model_p->waitSignalAndLaunchEngine();
            dla_model_p->syncAfterLaunchEngine();
        }
        cudaStreamSynchronize(dla_stream);
        t1 = std::chrono::system_clock::now();
        duration0 = std::chrono::duration<double>(t1 - t0).count();
        duration0 *= 1000.0f;
        std::cout<<"dla model 100 round total cost: "<<duration0 <<" ms"<<std::endl;
        std::cout<<"dla model 100 round average cost: "<<duration0 / 100.0f<<" ms"<<std::endl;
    }

    return 0;
}