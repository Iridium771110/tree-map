#include "common.h"
#include "base_eng.h"

int main(int argc, char *argv[]){
    std::unordered_map<std::string, int> type_size_table = {{"float", 4}, {"float16", 2}, {"int8", 1}};

    std::string cfg_path = argv[1];
    std::ifstream json_file(cfg_path);
    nlohmann::json config;
    json_file >> config;
    bool test_status = config.at("test_status").get<bool>();
    std::vector<nlohmann::json> engines = config.at("engines").get<std::vector<nlohmann::json>>();
    cudaStream_t test_stream;
    cudaStreamCreateWithPriority(&test_stream, cudaStreamNonBlocking, -5);
    std::unordered_map<std::string, memory::GPUBufferPtr> external_mem_pool;
    std::unordered_map<std::string, std::vector<int64_t>> external_mem_shape;
    std::unordered_map<std::string, int> external_mem_size;
    std::unordered_map<std::string, std::vector<std::string>> engine_external_input_buffer_names;
    std::unordered_map<std::string, std::vector<std::string>> engine_input_names;
    std::unordered_map<std::string, std::vector<std::vector<int64_t>>> engine_input_shapes;
    std::unordered_map<std::string, std::vector<std::string>> engine_external_output_buffer_names;
    std::unordered_map<std::string, std::vector<std::string>> engine_output_names;
    std::unordered_map<std::string, std::vector<std::vector<int64_t>>> engine_output_shapes;
    std::unordered_map<std::string, engine::BaseEnginePtr> engines_ptr;
    for (int engine_id = 0; engine_id < engines.size(); engine_id++){
        nlohmann::json engine_config = engines[engine_id];
        std::string engine_name = engine_config.at("eng_name").get<std::string>();
        std::string input_net_path = engine_config.at("net_path").get<std::string>();
        std::string output_eng_path = engine_config.at("eng_path").get<std::string>();
        bool rebuild_flag = engine_config.at("rebuild").get<bool>();
        std::string build_type = engine_config.at("build_type").get<std::string>();
        std::string fallback_type = engine_config.at("fallback_type").get<std::string>();
        int gpu_id = engine_config.at("gpu").get<int>();
        int dla_id = engine_config.at("dla").get<int>();
        bool gpu_direct_io_flag = engine_config.at("gpu_direct_io").get<bool>();
        int sync_type = engine_config.at("sync_type").get<int>();
        bool on_dla = static_cast<bool>(sync_type);
        bool use_cuda_graph_flag = engine_config.at("use_cuda_graph").get<bool>();
        std::vector<char> serial_data = common::loadDataFromFile<char, char>(input_net_path);
        std::string engine_type = "TRTEngine";
        engine::BaseEnginePtr model_p = engine::EngineFactory::createEngineInstance(engine_type);
        std::cout<<engine_name<<std::endl;
        std::cout<<"start build"<<std::endl;
        model_p->buildEngineModel(serial_data.data(), 0, output_eng_path, build_type, fallback_type, dla_id, rebuild_flag);
        std::cout<<"end build"<<std::endl;

        std::vector<nlohmann::json> inputs_config = engine_config.at("inputs").get<std::vector<nlohmann::json>>();
        std::vector<nlohmann::json> outputs_config = engine_config.at("outputs").get<std::vector<nlohmann::json>>();
        int inputs_num = inputs_config.size();
        int outputs_num = outputs_config.size();
        engine_external_input_buffer_names.emplace(engine_name, std::vector<std::string>({}));
        engine_input_names.emplace(engine_name, std::vector<std::string>({}));
        engine_input_shapes.emplace(engine_name, std::vector<std::vector<int64_t>>({}));
        engine_external_output_buffer_names.emplace(engine_name, std::vector<std::string>({}));
        engine_output_names.emplace(engine_name, std::vector<std::string>({}));
        engine_output_shapes.emplace(engine_name, std::vector<std::vector<int64_t>>({}));
        std::vector<memory::BaseBufferPtr> engine_input_buffer;
        std::vector<memory::BaseBufferPtr> engine_output_buffer;
        for (int i = 0; i < inputs_num; i++){
            std::string name = inputs_config[i].at("name").get<std::string>();
            std::string global_name = inputs_config[i].at("buffer_global_name").get<std::string>();
            std::vector<int64_t> shape = inputs_config[i].at("shape").get<std::vector<int64_t>>();
            int mem_size = type_size_table.at(inputs_config[i].at("type").get<std::string>());
            for (int j = 0; j < shape.size(); j++) mem_size *= shape[j];
            if (external_mem_pool.count(global_name) == 0){
                external_mem_size.emplace(global_name, mem_size);
                external_mem_shape.emplace(global_name, shape);
                external_mem_pool.emplace(global_name, std::make_shared<memory::GPUBuffer>(global_name, mem_size));
            }
            engine_external_input_buffer_names.at(engine_name).emplace_back(global_name);
            engine_input_names.at(engine_name).emplace_back(name);
            engine_input_shapes.at(engine_name).emplace_back(shape);
            if (mem_size == external_mem_pool.at(global_name)->getDataByteSize()){
                engine_input_buffer.emplace_back(std::make_shared<memory::GPUBuffer>(name, external_mem_pool.at(global_name)->getDataPtrAddr(), mem_size));
            }
        }
        for (int i = 0; i < outputs_num; i++){
            std::string name = outputs_config[i].at("name").get<std::string>();
            std::string global_name = outputs_config[i].at("buffer_global_name").get<std::string>();
            std::vector<int64_t> shape = outputs_config[i].at("shape").get<std::vector<int64_t>>();
            int mem_size = type_size_table.at(outputs_config[i].at("type").get<std::string>());
            for (int j = 0; j < shape.size(); j++) mem_size *= shape[j];
            if (external_mem_pool.count(global_name) == 0){
                external_mem_size.emplace(global_name, mem_size);
                external_mem_shape.emplace(global_name, shape);
                external_mem_pool.emplace(global_name, std::make_shared<memory::GPUBuffer>(global_name, mem_size));
            }
            engine_external_output_buffer_names.at(engine_name).emplace_back(global_name);
            engine_output_names.at(engine_name).emplace_back(name);
            engine_output_shapes.at(engine_name).emplace_back(shape);
            if (mem_size == external_mem_pool.at(global_name)->getDataByteSize()){
                engine_output_buffer.emplace_back(std::make_shared<memory::GPUBuffer>(name, external_mem_pool.at(global_name)->getDataPtrAddr(), mem_size));
            }
        }
        model_p->setDeviceId(gpu_id);
        model_p->setEngineIONumber(inputs_num, outputs_num);
        // model_p->setStreamInternal();
        model_p->setStreamExternal(test_stream);
        model_p->setEngineName(engine_name);
        model_p->setInputsShape(engine_input_shapes.at(engine_name));
        model_p->setOutputsShape(engine_output_shapes.at(engine_name));
        model_p->setEngineIOBuffer(engine_input_buffer, engine_output_buffer);
        cudaDeviceSynchronize();
        std::cout<<"ready set engine "<<engine_name<<std::endl;
        model_p->loadEngineModel(output_eng_path, on_dla, sync_type, dla_id, use_cuda_graph_flag);
        cudaDeviceSynchronize();
        std::cout<<"ready load engine "<<engine_name<<std::endl;
        model_p->initEngineModel();
        std::cout<<"ready init engine "<<engine_name<<std::endl;
        engines_ptr.emplace(engine_name, model_p);
    }
    engine::BaseEnginePtr img_backbone_p = engines_ptr.at("img_backbone");
    engine::BaseEnginePtr img_neck_p = engines_ptr.at("img_neck");
    engine::BaseEnginePtr depth_net_p = engines_ptr.at("depth_main");
    engine::BaseEnginePtr bev_backbone_p = engines_ptr.at("bev_backbone");
    engine::BaseEnginePtr bev_neck_p = engines_ptr.at("bev_neck");
    engine::BaseEnginePtr occ_head_p = engines_ptr.at("occ_head");

    cudaEvent_t start, end;
    cudaEventCreate(&start);
    cudaEventCreate(&end);
    float total_cost = 0.0f;
    int repeat_times = 10;
    for (int round = 0; round < repeat_times; round++){
        cudaEventRecord(start, test_stream);
        img_backbone_p->waitSignalAndLaunchEngine();
        img_backbone_p->syncAfterLaunchEngine();
        img_neck_p->waitSignalAndLaunchEngine();
        img_neck_p->syncAfterLaunchEngine();
        depth_net_p->waitSignalAndLaunchEngine();
        depth_net_p->syncAfterLaunchEngine();
        bev_backbone_p->waitSignalAndLaunchEngine();
        bev_backbone_p->syncAfterLaunchEngine();
        bev_neck_p->waitSignalAndLaunchEngine();
        bev_neck_p->syncAfterLaunchEngine();
        occ_head_p->waitSignalAndLaunchEngine();
        occ_head_p->syncAfterLaunchEngine();
        cudaEventRecord(end, test_stream);
        cudaEventSynchronize(end);
        float cost;
        cudaEventElapsedTime(&cost, start, end);
        total_cost += cost;
    }
    cudaStreamSynchronize(test_stream);
    std::cout<<"occ model test time ave in "<<repeat_times<<" rounds: "<<total_cost / static_cast<float>(repeat_times)<<"ms"<<std::endl;
}