#include "common.h"
#include "base_eng.h"

int main(int argc, char *argv[]){
    std::string cfg_path = argv[1];
    std::ifstream json_file(cfg_path);
    nlohmann::json config;
    json_file >> config;
    std::vector<nlohmann::json> engines = config.at("engines").get<std::vector<nlohmann::json>>();
    std::unordered_map<std::string, int> ele_type_size_table = {{"float", 4}, {"float16", 2}, {"int8", 1}};
    for (int engine_id = 0; engine_id < engines.size(); engine_id++){
        nlohmann::json engine_config = engines[engine_id];
        std::string engine_name = "engine_" + std::to_string(engine_id);
        std::cout<<engine_name<<std::endl;
        std::string input_net_path = engine_config.at("net_path").get<std::string>();
        std::string output_eng_path = engine_config.at("eng_path").get<std::string>();
        bool rebuild_flag = engine_config.at("rebuild").get<bool>();
        bool gpu_direct_io_flag = engine_config.at("gpu_direct_io").get<bool>();
        std::string build_type = engine_config.at("build_type").get<std::string>();
        std::string fallback_type = engine_config.at("fallback_type").get<std::string>();
        int gpu_id = engine_config.at("gpu").get<int>();
        int dla_id = engine_config.at("dla").get<int>();
        int sync_type = engine_config.at("sync_type").get<int>();
        bool on_dla = static_cast<bool>(sync_type);
        std::vector<char> serial_data = common::loadDataFromFile<char, char>(input_net_path);
        std::string engine_type = "TRTEngine";
        engine::BaseEnginePtr model_p = engine::EngineFactory::createEngineInstance(engine_type);
        std::cout<<"start build"<<std::endl;
        model_p->buildEngineModel(serial_data.data(), 0, output_eng_path, build_type, fallback_type, dla_id, rebuild_flag, gpu_direct_io_flag);
        std::cout<<"end build"<<std::endl;

        std::vector<nlohmann::json> inputs_config = engine_config.at("inputs").get<std::vector<nlohmann::json>>();
        std::vector<nlohmann::json> outputs_config = engine_config.at("outputs").get<std::vector<nlohmann::json>>();
        int inputs_num = inputs_config.size();
        int outputs_num = outputs_config.size();
        std::vector<std::vector<char>> inputs_data(inputs_num);
        std::vector<std::vector<char>> outputs_data(outputs_num);
        std::vector<memory::BaseBufferPtr> inputs_buffer_p(inputs_num, nullptr);
        std::vector<memory::BaseBufferPtr> outputs_buffer_p(outputs_num, nullptr);
        std::vector<std::vector<int64_t>> inputs_shape(inputs_num);
        std::vector<std::vector<int64_t>> outputs_shape(outputs_num);
        std::vector<std::string> inputs_name(inputs_num);
        std::vector<std::string> outputs_name(outputs_num);
        for (int i = 0; i < inputs_num; i++){
            std::string input_data_path = inputs_config[i].at("file_path").get<std::string>();
            inputs_shape[i] = inputs_config[i].at("shape").get<std::vector<int64_t>>();
            int input_byte_size = ele_type_size_table.at(inputs_config[i].at("type").get<std::string>());
            for (int j = 0; j < inputs_shape[i].size(); j++) input_byte_size *= inputs_shape[i][j];
            inputs_data[i] = common::loadDataFromFile<char, char>(input_data_path);
            if (input_byte_size != inputs_data[i].size()) std::cout<<"input file size invalid"<<std::endl;
            std::string buffer_name = inputs_config[i].at("name").get<std::string>();
            inputs_buffer_p[i] = std::make_shared<memory::GPUBuffer>(buffer_name, input_byte_size);
            inputs_buffer_p[i]->copyFromCPU(inputs_data[i].data(), input_byte_size);
            inputs_name[i] = buffer_name;
        }
        for (int i = 0; i < outputs_num; i++){
            outputs_shape[i] = outputs_config[i].at("shape").get<std::vector<int64_t>>();
            int output_byte_size = ele_type_size_table.at(outputs_config[i].at("type").get<std::string>());
            for (int j = 0; j < outputs_shape[i].size(); j++) output_byte_size *= outputs_shape[i][j];
            outputs_data[i].resize(output_byte_size);
            std::string buffer_name = outputs_config[i].at("name").get<std::string>();
            outputs_buffer_p[i] = std::make_shared<memory::GPUBuffer>(buffer_name, output_byte_size);
            outputs_buffer_p[i]->setZeros();
            outputs_name[i] = buffer_name;
        }

        cudaDeviceSynchronize();
        std::cout<<"start test infer"<<std::endl;
        model_p->setDeviceId(gpu_id);
        model_p->setEngineIONumber(inputs_num, outputs_num);
        model_p->setStreamInternal();
        model_p->setEngineName(engine_name);
        model_p->setInputsShape(inputs_shape);
        model_p->setOutputsShape(outputs_shape);
        model_p->setEngineIOBuffer(inputs_buffer_p, outputs_buffer_p);
        cudaDeviceSynchronize();
        std::cout<<"ready set"<<std::endl;
        model_p->loadEngineModel(output_eng_path, on_dla, sync_type, dla_id);
        cudaDeviceSynchronize();
        std::cout<<"ready load"<<std::endl;
        model_p->initEngineModel();
        cudaDeviceSynchronize();
        std::cout<<"ready init"<<std::endl;
        // model_p->inferEngineModel();
        model_p->waitSignalAndLaunchEngine();
        model_p->syncAfterLaunchEngine();
        cudaDeviceSynchronize();
        std::cout<<"end test infer"<<std::endl;

        for (int i = 0; i < outputs_num; i++){
            std::string output_data_path = outputs_config[i].at("file_path").get<std::string>();
            outputs_buffer_p[i]->copyToCPU(outputs_data[i].data(), outputs_data[i].size());
            std::ofstream outfile(output_data_path, std::ios::binary);
            outfile.write(outputs_data[i].data(), outputs_data[i].size());
            outfile.close();
        }

    }

    return 0;
}