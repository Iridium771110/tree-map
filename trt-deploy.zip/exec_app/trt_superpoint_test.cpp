#include "common.h"
#include "base_eng.h"

int main(int argc, char *argv[]){
    std::string cfg_path = argv[1];
    std::ifstream json_file(cfg_path);
    nlohmann::json config;
    json_file >> config;
    bool test_status = config.at("test_status").get<bool>();
    std::vector<nlohmann::json> engines = config.at("engines").get<std::vector<nlohmann::json>>();
    std::unordered_map<std::string, int> ele_type_size_table = {{"float", 4}, {"float16", 2}, {"int8", 1}};
    for (int engine_id = 0; engine_id < engines.size(); engine_id++){
        nlohmann::json engine_config = engines[engine_id];
        std::string engine_name = engine_config.at("eng_name").get<std::string>();
        std::string input_net_path = engine_config.at("net_path").get<std::string>();
        std::string output_eng_path = engine_config.at("eng_path").get<std::string>();
        bool rebuild_flag = engine_config.at("rebuild").get<bool>();
        bool gpu_direct_io_flag = engine_config.at("gpu_direct_io").get<bool>();
        std::string build_type = engine_config.at("build_type").get<std::string>();
        std::string fallback_type = engine_config.at("fallback_type").get<std::string>();
        int gpu_id = engine_config.at("gpu").get<int>();
        int dla_id = engine_config.at("dla").get<int>();
        int sync_type = engine_config.at("sync_type").get<int>();
        bool on_dla = static_cast<bool>(sync_type);
        std::vector<char> serial_data = common::loadDataFromFile<char, char>(input_net_path);
        std::string engine_type = "TRTEngine";
        engine::BaseEnginePtr model_p = engine::EngineFactory::createEngineInstance(engine_type);
        std::cout<<"start build"<<std::endl;
        model_p->buildEngineModel(serial_data.data(), 0, output_eng_path, build_type, fallback_type, dla_id, rebuild_flag, gpu_direct_io_flag);
        std::cout<<"end build"<<std::endl;

        std::vector<nlohmann::json> inputs_config = engine_config.at("inputs").get<std::vector<nlohmann::json>>();
        std::vector<nlohmann::json> outputs_config = engine_config.at("outputs").get<std::vector<nlohmann::json>>();
        int inputs_num = inputs_config.size();
        int outputs_num = outputs_config.size();
        std::vector<std::vector<char>> inputs_data(inputs_num);
        std::vector<std::vector<char>> outputs_ref_data(outputs_num);
        std::vector<memory::BaseBufferPtr> inputs_buffer_p(inputs_num, nullptr);
        std::vector<memory::BaseBufferPtr> outputs_buffer_p(outputs_num, nullptr);
        std::vector<std::vector<int64_t>> inputs_shape(inputs_num);
        std::vector<std::vector<int64_t>> outputs_shape(outputs_num);
        std::vector<std::string> inputs_name(inputs_num);
        std::vector<std::string> outputs_name(outputs_num);
        std::vector<float> inputs_amax(inputs_num);
        std::vector<float> outputs_amax(outputs_num);
        for (int i = 0; i < inputs_num; i++){
            std::string input_data_path = inputs_config[i].at("file_path").get<std::string>();
            inputs_shape[i] = inputs_config[i].at("shape").get<std::vector<int64_t>>();
            inputs_amax[i] = inputs_config[i].at("amax").get<float>();
            int input_byte_size;
            if (input_data_path == ""){
                input_byte_size = ele_type_size_table.at(inputs_config[i].at("type").get<std::string>());
                for (int j = 0; j < inputs_shape[i].size(); j++) input_byte_size *= inputs_shape[i][j];
                inputs_data[i].resize(input_byte_size);
            }
            else{
                inputs_data[i] = common::loadDataFromFile<char, char>(input_data_path);
                input_byte_size = inputs_data[i].size();
            }
            std::string buffer_name = inputs_config[i].at("name").get<std::string>();
            // float scale = inputs_amax[i] / 127.0f;
            // for (int j = 100; j < 110; j++) std::cout<<reinterpret_cast<float*>(inputs_data[i].data())[j]<<' ';
            // std::cout<<std::endl;
            // for (int j = 0; j < input_byte_size / 4; j++) 
            //     reinterpret_cast<float*>(inputs_data[i].data())[j] 
            //     = static_cast<float>(static_cast<int8_t>(reinterpret_cast<float*>(inputs_data[i].data())[j] / scale + 0.5f))*scale;
            // for (int j = 100; j < 110; j++) std::cout<<reinterpret_cast<float*>(inputs_data[i].data())[j]<<' ';
            // std::cout<<std::endl;
            // inputs_buffer_p[i] = std::make_shared<memory::GPUBuffer>(buffer_name, input_byte_size);
            // inputs_buffer_p[i]->copyFromCPU(inputs_data[i].data(), input_byte_size);
            inputs_buffer_p[i] = std::make_shared<memory::GPUBuffer>(buffer_name, input_byte_size / 4);
            std::vector<int8_t> data_s8(input_byte_size / 4);
            float scale = inputs_amax[i] / 127.0f;
            std::cout<<scale<<std::endl;//cast may cause error
            for (int j = 0; j < input_byte_size / 4; j++) data_s8[j] = static_cast<int8_t>(reinterpret_cast<float*>(inputs_data[i].data())[j] / scale + 0.5f);
            inputs_buffer_p[i]->copyFromCPU(data_s8.data(), input_byte_size / 4);
            inputs_name[i] = buffer_name;
        }
        for (int i = 0; i < outputs_num; i++){
            std::string output_data_path = outputs_config[i].at("file_path").get<std::string>();
            outputs_shape[i] = outputs_config[i].at("shape").get<std::vector<int64_t>>();
            outputs_amax[i] = outputs_config[i].at("amax").get<float>();
            int output_byte_size;
            if (output_data_path == ""){
                output_byte_size = ele_type_size_table.at(outputs_config[i].at("type").get<std::string>());
                for (int j = 0; j < outputs_shape[i].size(); j++) output_byte_size *= outputs_shape[i][j];
                outputs_ref_data[i].resize(output_byte_size);
            } 
            else{
                outputs_ref_data[i] = common::loadDataFromFile<char, char>(output_data_path);
                output_byte_size = outputs_ref_data[i].size();
            } 
            std::string buffer_name = outputs_config[i].at("name").get<std::string>();
            outputs_buffer_p[i] = std::make_shared<memory::GPUBuffer>(buffer_name, output_byte_size);
            outputs_buffer_p[i]->setZeros();
            outputs_name[i] = buffer_name;
        }
        cudaDeviceSynchronize();
        std::cout<<"start test infer"<<std::endl;
        model_p->setDeviceId(gpu_id);
        model_p->setEngineIONumber(inputs_num, outputs_num);
        model_p->setStreamInternal();
        model_p->setEngineName(engine_name);
        model_p->setInputsShape(inputs_shape);
        model_p->setOutputsShape(outputs_shape);
        model_p->setEngineIOBuffer(inputs_buffer_p, outputs_buffer_p);
        cudaDeviceSynchronize();
        std::cout<<"ready set"<<std::endl;
        model_p->loadEngineModel(output_eng_path, on_dla, sync_type, dla_id);
        cudaDeviceSynchronize();
        std::cout<<"ready load"<<std::endl;
        model_p->initEngineModel();
        cudaDeviceSynchronize();
        std::cout<<"ready init"<<std::endl;
        // model_p->inferEngineModel();
        model_p->waitSignalAndLaunchEngine();
        model_p->syncAfterLaunchEngine();
        cudaDeviceSynchronize();
        std::cout<<"end test infer"<<std::endl;
// while(1){
//     model_p->inferEngineModel();
// }
int least_priority, greatest_priority;
cudaDeviceGetStreamPriorityRange(&least_priority, &greatest_priority);
std::cout<<least_priority<<' '<<greatest_priority<<std::endl;
cudaStream_t test_stream;
cudaStreamCreateWithPriority(&test_stream, cudaStreamNonBlocking, -5);

        if (!test_status) continue;

        if (dla_id >= 0){
            std::vector<std::vector<int8_t>> input_data_s8(inputs_num);
            std::vector<void*> input_cpu_p_vec(inputs_num);
            std::vector<void*> input_gpu_p_vec(inputs_num);
            std::vector<uint64_t*> input_dla_p_vec(inputs_num);
            std::vector<int> input_size(inputs_num);
            std::vector<std::vector<int8_t>> output_ref_data_s8(outputs_num);
            std::vector<void*> output_cpu_p_vec(outputs_num);
            std::vector<void*> output_gpu_p_vec(outputs_num);
            std::vector<uint64_t*> output_dla_p_vec(outputs_num);
            std::vector<int> output_size(outputs_num);
            cudaStream_t stream = model_p->getStream();

            for (int i = 0; i < inputs_num; i++){std::cout<<inputs_name[i]<<std::endl;
                input_cpu_p_vec[i] = model_p->getCpuMemPtr(inputs_name[i]);
                input_gpu_p_vec[i] = model_p->getGpuMemPtr(inputs_name[i]);
                input_dla_p_vec[i] = model_p->getDlaMemPtr(inputs_name[i]);
                input_size[i] = model_p->getDlaMemSize(inputs_name[i]);
                std::cout<<input_size[i]<<std::endl;
                int last_dim = inputs_shape[i][inputs_shape[i].size() - 1];
                int dla_last_dim = (last_dim + 63) / 64 * 64;
                int same_dim = input_size[i] / dla_last_dim;
                input_data_s8[i].resize(input_size[i], 0);
                if (inputs_config[i].at("type").get<std::string>() == "float" || inputs_config[i].at("type").get<std::string>() == "float16"){
                    //should has a amax, default = 1.0
                    float scale = inputs_amax[i] / 127.0f;
                    for (int n = 0; n < same_dim; n++){
                        for (int w = 0; w < last_dim; w++){
                            input_data_s8[i][n*dla_last_dim + w] = static_cast<int8_t>(reinterpret_cast<float*>(inputs_data[i].data())[n*last_dim + w] / scale + 0.5f);
                        }
                    }
                    std::cout<<same_dim<<' '<<last_dim<<' '<<dla_last_dim<<std::endl;
                }
            }
            for (int i = 0; i < outputs_num; i++){std::cout<<outputs_name[i]<<std::endl;
                output_cpu_p_vec[i] = model_p->getCpuMemPtr(outputs_name[i]);
                output_gpu_p_vec[i] = model_p->getGpuMemPtr(outputs_name[i]);
                output_dla_p_vec[i] = model_p->getDlaMemPtr(outputs_name[i]);
                output_size[i] = model_p->getDlaMemSize(outputs_name[i]);
                std::cout<<output_size[i]<<std::endl;
                int last_dim = outputs_shape[i][outputs_shape[i].size() - 1];
                int dla_last_dim = (last_dim + 63) / 64 * 64;
                int same_dim = output_size[i] / dla_last_dim;
                output_ref_data_s8[i].resize(output_size[i], 0);
                if (outputs_config[i].at("type").get<std::string>() == "float" || outputs_config[i].at("type").get<std::string>() == "float16"){
                    //should has a amax, default = 1.0
                    float scale = outputs_amax[i] / 127.0f;
                    for (int n = 0; n < same_dim; n++){
                        for (int w = 0; w < last_dim; w++){
                            float ref = reinterpret_cast<float*>(outputs_ref_data[i].data())[n*last_dim + w];
                            ref = std::min(outputs_amax[i], std::max(ref, -outputs_amax[i] - scale));
                            if (ref > 0.0f) output_ref_data_s8[i][n*dla_last_dim + w] = static_cast<int8_t>(ref / scale + 0.5f);
                            else output_ref_data_s8[i][n*dla_last_dim + w] = static_cast<int8_t>(ref / scale - 0.5f);
                        }
                    }
                    std::cout<<same_dim<<' '<<last_dim<<' '<<dla_last_dim<<std::endl;
                }
            }

            if (sync_type == 1){}
            else if (sync_type == 2){
                for (int i = 0; i < outputs_num; i++) cudaMemsetAsync(output_gpu_p_vec[i], 0, output_size[i], stream);
                for (int i = 0; i < inputs_num; i++) cudaMemcpyAsync(input_gpu_p_vec[i], input_data_s8[i].data(), input_size[i], cudaMemcpyHostToDevice, stream);
                model_p->waitSignalAndLaunchEngine();
                model_p->syncAfterLaunchEngine();
                cudaStreamSynchronize(stream);

                for (int i = 0; i < 1; i++){
                //     int max_err = 0;
                //     int err_sum = 0;
                //     int rec_res = 0;
                //     int rec_ref = 0;
                //     int abs_sum = 0;
                //     for (int j = 0; j < output_size[i]; j++){
                //         int res = static_cast<int>(reinterpret_cast<int8_t*>(output_cpu_p_vec[i])[j]);
                //         int ref = static_cast<int>(output_ref_data_s8[i][j]);
                //         int err = std::abs(res - ref);
                //         err_sum += err;
                //         abs_sum += std::abs(ref);
                //         if (max_err < err){
                //             max_err = err;
                //             rec_ref = ref;
                //             rec_res = res;
                //         }
                //     }

                    float scale = outputs_amax[i] / 127.0f;
                    int8_t* res_p = reinterpret_cast<int8_t*>(output_cpu_p_vec[i]);
                    float* ref_p = reinterpret_cast<float*>(outputs_ref_data[i].data());
                    float max_err = 0;
                    float err_sum = 0;
                    float rec_res = 0;
                    float rec_ref = 0;
                    float abs_sum = 0;
                    for (int j = 0; j < 20; j++){
                        float res = static_cast<float>(res_p[j]) * scale;
                        // float res = res_p[j];
                        // res = std::min(outputs_amax[i], std::max(res, -outputs_amax[i] - scale));
                        // if (res >= 0) res = static_cast<float>(static_cast<int8_t>(res / scale + 0.5f)) * scale;
                        // else res = static_cast<float>(static_cast<int8_t>(res / scale - 0.5f)) * scale;
                        float ref = ref_p[j];
                        if (std::abs(ref) > outputs_amax[i]){
                            // std::cout<<ref<<' '<<res_p[j]<<' '
                            //     <<static_cast<int>(static_cast<int8_t>(res_p[j] / scale + 0.5f))<<' '<<static_cast<int>(static_cast<int8_t>(res_p[j] / scale - 0.5f))
                            //     <<' '<<static_cast<float>(static_cast<int8_t>(res_p[j] / scale - 0.5f)) * scale
                            //     <<' '<<static_cast<float>(static_cast<int8_t>(res_p[j] / scale + 0.5f)) * scale
                            //     <<std::endl;
                            continue;
                        } 
                        float err = std::abs(res - ref);
                        err_sum += err;
                        abs_sum += std::abs(ref);
                        if (max_err < err){
                            max_err = err;
                            rec_ref = ref;
                            rec_res = res;
                        }
                        std::cout<<ref<<" : "<<res<<" = "<<err<<std::endl;
                    }
                    std::cout<<outputs_name[i]<<": max err: "<<max_err<<", ref: "<<rec_ref<<", res: "<<rec_res<<", sum err: "<<err_sum<<", abs sum: "<<abs_sum<<std::endl;
                }
            }
            else{
                std::cout<< "for dla mode, sync type must set as 1 for sync with cpu, 2 for sync with gpu"<<std::endl;
            }
        }
        else{
            for (int i = 0; i < outputs_num; i++){
                std::vector<char> output_res(outputs_ref_data[i].size(), 0);
                outputs_buffer_p[i]->copyToCPU(output_res.data(), output_res.size());
                float scale = outputs_amax[i] / 127.0f;
                // int8_t* res_p = reinterpret_cast<int8_t*>(output_res.data());
                float* res_p = reinterpret_cast<float*>(output_res.data());
                float* ref_p = reinterpret_cast<float*>(outputs_ref_data[i].data());
                float max_err = 0;
                float err_sum = 0;
                float rec_res = 0;
                float rec_ref = 0;
                float abs_sum = 0;
                for (int j = 0; j < output_res.size()/4; j++){
                    // float res = static_cast<float>(res_p[j]) * scale;
                    float res = res_p[j];
                    res = std::min(outputs_amax[i], std::max(res, -outputs_amax[i] - scale));
                    if (res >= 0) res = static_cast<float>(static_cast<int8_t>(res / scale + 0.5f)) * scale;
                    else res = static_cast<float>(static_cast<int8_t>(res / scale - 0.5f)) * scale;
                    float ref = ref_p[j];
                    if (std::abs(ref) > outputs_amax[i]){
                        // std::cout<<ref<<' '<<res_p[j]<<' '
                        //     <<static_cast<int>(static_cast<int8_t>(res_p[j] / scale + 0.5f))<<' '<<static_cast<int>(static_cast<int8_t>(res_p[j] / scale - 0.5f))
                        //     <<' '<<static_cast<float>(static_cast<int8_t>(res_p[j] / scale - 0.5f)) * scale
                        //     <<' '<<static_cast<float>(static_cast<int8_t>(res_p[j] / scale + 0.5f)) * scale
                        //     <<std::endl;
                        continue;
                    } 
                    float err = std::abs(res - ref);
                    err_sum += err;
                    abs_sum += std::abs(ref);
                    if (max_err < err){
                        max_err = err;
                        rec_ref = ref;
                        rec_res = res;
                    }
                }
                std::cout<<outputs_name[i]<<": max err: "<<max_err<<", ref: "<<rec_ref<<", res: "<<rec_res<<", sum err: "<<err_sum<<", abs sum: "<<abs_sum<<std::endl;
            }
        }

    }

    return 0;
}