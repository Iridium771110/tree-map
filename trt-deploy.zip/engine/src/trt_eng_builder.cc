#include "trt_eng.h"

namespace engine{
    bool TRTEngine::saveEngineModel(const std::string& model_file_path){
        nvinfer1::IHostMemory* serializedModel = engine_->serialize();
        std::ofstream out_eng_file(model_file_path, std::ios::binary);
        if (!out_eng_file.good()){
            std::cout<<"failed to save engine file in path: "<<std::endl;
            return -2;
        }
        out_eng_file.write(reinterpret_cast<char*>(serializedModel->data()), serializedModel->size());
        out_eng_file.close();
        delete serializedModel;
        return true;
    }
    int64_t TRTEngine::buildEngineModel(const char* const data_p, int64_t start_byte, std::string engine_save_path,
                                    std::string build_type, std::string fallback_type, int dla_id, bool rebuild, bool gpu_direct_io){
        if (common::fileExist(engine_save_path)){
            std::cout<<"engine file "<<engine_save_path<<" exist"<<std::endl;
            if (!rebuild){
                std::cout<<"no rebuild required, skip the building phase"<<std::endl;
                return 1;
            }
        }
#ifndef JETSON_ORIN
        if (dla_id >= 0){
            std::cout<<"unsupport dla in this platform"<<std::endl;
            return -3;
        }
#endif
        const char* cur_data_p = data_p + start_byte;
        int eng_header_len;
        std::memcpy(&eng_header_len, cur_data_p, 4);
        cur_data_p += 4;
        std::string eng_header_str;
        eng_header_str.resize(eng_header_len);
        std::memcpy(eng_header_str.data(), cur_data_p, eng_header_len);
        cur_data_p += eng_header_len;
        nlohmann::json eng_header = nlohmann::json::parse(eng_header_str);
        int nodes_cfg_len = eng_header.at("node_cfg_len").get<int>();
        int tensors_cfg_len = eng_header.at("tensor_cfg_len").get<int>();
        int constant_data_len = eng_header.at("constant_data_len").get<int>();
std::cout<<"ready engine header"<<std::endl;
std::cout<<eng_header_str<<std::endl;
        std::string nodes_cfg_str;
        std::string tensors_cfg_str;
        std::vector<char> constant_data(constant_data_len);
        nodes_cfg_str.resize(nodes_cfg_len);
        tensors_cfg_str.resize(constant_data_len);
        std::memcpy(nodes_cfg_str.data(), cur_data_p, nodes_cfg_len);
        cur_data_p += nodes_cfg_len;
        std::memcpy(tensors_cfg_str.data(), cur_data_p, tensors_cfg_len);
        cur_data_p += tensors_cfg_len;
        std::vector<nlohmann::json> nodes_cfg = nlohmann::json::parse(nodes_cfg_str);

        std::memcpy(constant_data.data(), cur_data_p, constant_data_len);
        std::vector<nlohmann::json> tensors_cfg = nlohmann::json::parse(tensors_cfg_str);
std::cout<<"ready cfg header"<<std::endl;
std::cout<<cur_data_p + constant_data_len - data_p<<' '<<4 + eng_header_len + nodes_cfg_len + tensors_cfg_len<<std::endl;
std::cout<<constant_data.size()<<' '<<tensors_cfg.size()<<std::endl;
        char* constant_data_p = constant_data.data();
        std::cout<<reinterpret_cast<float*>(constant_data_p)[0]<<std::endl;
        for (int idx = 0; idx < tensors_cfg.size(); idx++){
            std::string name = tensors_cfg[idx].at("name").get<std::string>();
            // std::cout<<idx<<": "<<name<<std::endl;
            std::string data_type = tensors_cfg[idx].at("dtype").get<std::string>();
            std::vector<int> shape = tensors_cfg[idx].at("shape").get<std::vector<int>>();
            int64_t data_length = tensors_cfg[idx].at("byte_length").get<int64_t>();
            memory::CPUBufferPtr tensor_data_buffer_cpu = std::make_shared<memory::CPUBuffer>(name, data_length);
            tensor_data_buffer_cpu->copyFromCPU(constant_data_p, data_length);
            initializer_cpu_buffers_table_.emplace(name, tensor_data_buffer_cpu);
            initializer_tensors_table_.emplace(name, std::make_shared<memory::Tensor>(name, data_type, data_length, shape));
            constant_data_p += data_length;
        }
std::cout<<"ready initializer tensor"<<std::endl;
        nvinfer1::IBuilder* builder = nvinfer1::createInferBuilder(logger_);
        nvinfer1::IBuilderConfig* config = builder->createBuilderConfig();
        nvinfer1::INetworkDefinition* network = builder->createNetworkV2(1U);
        if (build_type == "int8"){
            config->setFlag(nvinfer1::BuilderFlag::kINT8);
            if (fallback_type == "float16"){
                config->setFlag(nvinfer1::BuilderFlag::kFP16);
            }
            else if (fallback_type != "float32"){
                std::cout << "trt engine fallback type must be float16 or float32, but get "<<fallback_type<<std::endl;
                return -3;
            }
        }
        else if (build_type == "float16"){
            config->setFlag(nvinfer1::BuilderFlag::kFP16);
        }
        else if (build_type != "float32"){
            std::cout << "trt engine build type must be int8, float16 or float32, but get "<<build_type<<std::endl;
            return -3;
        }
        if (dla_id == 0 || dla_id == 1){
            config->setDefaultDeviceType(nvinfer1::DeviceType::kDLA);
            config->setDLACore(dla_id);
            config->setEngineCapability(nvinfer1::EngineCapability::kDLA_STANDALONE);
            config->setFlag(nvinfer1::BuilderFlag::kDIRECT_IO);
        }
        tensors_cfg = eng_header.at("input").get<std::vector<nlohmann::json>>();
        std::vector<nvinfer1::ITensor*> inputs(tensors_cfg.size());
        //让输入输出强行是NCHW，图像标准形式，注意检查
        //其它情况下，若不足4维则仅取为前几维（2维则记为NC），若超出4维，则最前几维将被合并为N（6维如BNCHWD则被映射为NCHW，其中BNC->N，其它单体顺序映射）
        //注意输入格式对结果、对网络构建的影响
        for (int idx = 0; idx < inputs.size(); idx++){
            nlohmann::json tensor_cfg = tensors_cfg[idx];
            std::string name = tensor_cfg.at("name").get<std::string>();
            std::string dtype = tensor_cfg.at("dtype").get<std::string>();
            std::vector<int> shape = tensors_cfg[idx].at("shape").get<std::vector<int>>();
            nvinfer1::DataType data_type = nv_type_table_.at(dtype);
            // nvinfer1::Dims4 dims(shape[0], shape[1], shape[2], shape[3]);
            nvinfer1::Dims dims;
            dims.nbDims = std::min(static_cast<int>(shape.size()), 4);
            dims.d[0] = shape[0];
            for (int i = 1; i < static_cast<int>(shape.size()) - 3; i++) dims.d[0] *= shape[i];
            int offset = std::max(static_cast<int>(shape.size()) - 4, 0);
            for (int i = 1; i < dims.nbDims; i++) dims.d[i] = shape[i + offset];
            nvinfer1::ITensor* input = network->addInput(name.c_str(), data_type, dims);
            nv_tensor_table_.emplace(name, input);
            if (tensor_cfg.count("amax") != 0){
                float amax = tensor_cfg.at("amax").get<float>();
                // if (build_type == "int8") amax = 127.0f;
                if (amax > 0.0f) input->setDynamicRange(-amax, amax);
                tensor_amax_table_.emplace(name, amax);
            } 

            if (dla_id == 0 || dla_id == 1){
                input->setAllowedFormats(1U << int(nvinfer1::TensorFormat::kDLA_LINEAR));
                if (build_type == "int8") input->setType(nvinfer1::DataType::kINT8);
                else input->setType(nvinfer1::DataType::kHALF);
            } 
            else{
                input->setAllowedFormats(1U << int(nvinfer1::TensorFormat::kLINEAR));
                if (gpu_direct_io){
                    if (build_type == "int8") input->setType(nvinfer1::DataType::kINT8);
                    else input->setType(nvinfer1::DataType::kHALF);
                }
            } 
        }
std::cout<<"ready input tensor"<<std::endl;
        for (int idx = 0; idx < nodes_cfg.size(); idx++){
            nlohmann::json node_cfg = nodes_cfg[idx];
            if (node_cfg.count("amax") != 0){
                float amax = node_cfg.at("amax").get<float>();
                std::vector<std::string> node_outputs_name = node_cfg.at("output").get<std::vector<std::string>>();
                if (node_outputs_name.size() > 1) std::cout << node_cfg.at("name").get<std::string>()
                                                    <<": current only support 1 output for 1 node, otherwise may cause error"<<std::endl;
                for (int i = 0; i < node_outputs_name.size(); i++) tensor_amax_table_.emplace(node_outputs_name[i], amax);
                // if (node_outputs_name[0] == "/blocks.0/conv1/Conv_output_0"){
                //     std::string weight_name = node_cfg.at("attr").at("weight_name").get<std::string>();
                //     int weight_count = initializer_tensors_table_.at(weight_name)->getElementNum();
                //     float* weight_p = initializer_cpu_buffers_table_.at(weight_name)->getDataPtr<float>();
                //     int out_channel = initializer_tensors_table_.at(weight_name)->getShape()[0];
                //     std::cout<<weight_count<<' '<<out_channel<<std::endl;
                //     float channel_max = 0.0f;
                //     for (int i = 0; i < weight_count / out_channel; i++) channel_max = std::max(channel_max, weight_p[i]);
                //     tensor_amax_table_[node_outputs_name[0]] = channel_max;
                // }
            }
        }
std::cout<<"ready init tensor amax table"<<std::endl;
        for (int idx = 0; idx < nodes_cfg.size(); idx++){
            
            bool on_dla = false;
            if (dla_id >= 0) on_dla = true;
            nlohmann::json node_cfg = nodes_cfg[idx];
            addModule(network, node_cfg, on_dla);
            // if (node_cfg.at("name") == "/convDa/Conv") break;
        }
std::cout<<"ready add layer"<<std::endl;
        tensors_cfg = eng_header.at("output").get<std::vector<nlohmann::json>>();
        for (int idx = 0; idx < tensors_cfg.size(); idx++){
            nvinfer1::ITensor* output = nv_tensor_table_.at(tensors_cfg[idx].at("name").get<std::string>());
            if (dla_id == 0 || dla_id == 1){
                output->setAllowedFormats(1U << int(nvinfer1::TensorFormat::kDLA_LINEAR));
                if (build_type == "int8") output->setType(nvinfer1::DataType::kINT8);
                else output->setType(nvinfer1::DataType::kHALF);
            } 
            else{
                output->setAllowedFormats(1U << int(nvinfer1::TensorFormat::kLINEAR));
                if (gpu_direct_io){
                    if (build_type == "int8") output->setType(nvinfer1::DataType::kINT8);
                    else output->setType(nvinfer1::DataType::kHALF);
                }
            } 
            network->markOutput(*output);
        }
        // nvinfer1::ITensor* output = nv_tensor_table_.at("/upsampling_layer/conv/conv.1/InstanceNormalization_output_0");
        // network->markOutput(*output);
std::cout<<"ready output tensor"<<std::endl;
        if (build_type == "int8"){
            for (std::unordered_map<std::string, nvinfer1::ITensor*>::iterator iter = nv_tensor_table_.begin(); iter != nv_tensor_table_.end(); iter++){
                std::string tensor_name = iter->second->getName();
                if (tensor_amax_table_.count(tensor_name) != 0){
                    if (!iter->second->dynamicRangeIsSet()){
                        float amax = tensor_amax_table_.at(tensor_name);
                        if (amax > 0.0f) iter->second->setDynamicRange(-amax, amax);
                    } 
                    std::cout<<tensor_name<<' '<<tensor_amax_table_.at(tensor_name)<<std::endl;
                }
                else{
                    if (!iter->second->dynamicRangeIsSet()){
                        std::cout<<"tensor "<<tensor_name<<": no amax found, calc will cause error in int8 mode"<<std::endl;
                    }
                }
            }
        }
std::cout<<"ready check amax for all tensor in mode int8"<<std::endl;
        nvinfer1::IHostMemory* serializedModel = builder->buildSerializedNetwork(*network, *config);
std::cout<<"ready build serialized"<<std::endl;
        std::ofstream out_eng_file(engine_save_path, std::ios::binary);
        if (!out_eng_file.good()){
            std::cout<<"failed to save engine file in path: "<<std::endl;
            return -2;
        }
        out_eng_file.write(reinterpret_cast<char*>(serializedModel->data()), serializedModel->size());
        out_eng_file.close();

        delete serializedModel;
        delete network;
        delete config;
        delete builder;
        return 0;
    }
    bool TRTEngine::addConstantTensor(nvinfer1::INetworkDefinition* network, std::string tensor_name){
        std::string dtype = initializer_tensors_table_.at(tensor_name)->getElementType();
        std::vector<int> shape = initializer_tensors_table_.at(tensor_name)->getShape();
        nvinfer1::DataType data_type = nv_type_table_.at(dtype);
        int element_num = initializer_tensors_table_.at(tensor_name)->getElementNum();
        nvinfer1::Dims dim;
        dim.nbDims = shape.size();
        for (int i = 0; i < dim.nbDims; i++) dim.d[i] = shape[i];
        nvinfer1::Weights tensor_data{data_type, nullptr, 0};
        tensor_data.count = element_num;
        tensor_data.values = initializer_cpu_buffers_table_.at(tensor_name)->getDataPtr<void>();
        nvinfer1::IConstantLayer* const_layer_p = network->addConstant(dim, tensor_data);
        nvinfer1::ITensor* const_tensor_p = const_layer_p->getOutput(0);
        const_tensor_p->setName(tensor_name.c_str());
        nv_tensor_table_.emplace(tensor_name, const_tensor_p);
        if (dtype == "float"){
            float amax = 0.0f;
            for (int i = 0; i < element_num; i++){
                float cur = reinterpret_cast<const float*>(tensor_data.values)[i];
                amax = std::max(amax, std::abs(cur));
            }
            tensor_amax_table_.emplace(tensor_name, amax);
        }
        else if (dtype == "float16"){
            float amax = 0.0f;
            for (int i = 0; i < element_num; i++){
                float cur = static_cast<float>(reinterpret_cast<const half*>(tensor_data.values)[i]);
                amax = std::max(amax, std::abs(cur));
            }
            tensor_amax_table_.emplace(tensor_name, amax);
        }
        else if (dtype == "int8"){
            tensor_amax_table_.emplace(tensor_name, 127.0f);
        }
        else{
            std::cout<< tensor_name<<": "<<dtype<<" do not calc amax"<<std::endl;
        }
        float amax = tensor_amax_table_.at(tensor_name);
        if (amax > 0.0f) const_tensor_p->setDynamicRange(-amax, amax);
        // std::cout<<tensor_name<<' '<<tensor_data.values<<' '<<tensor_data.count<<' '<<dtype
        //         <<' '<<initializer_cpu_buffers_table_.at(tensor_name)->getDataByteSize()<<std::endl;
        return true;
    }
    nvinfer1::ITensor* TRTEngine::internBoardcastShuffle(nvinfer1::INetworkDefinition* network, nvinfer1::ITensor* tensor_p, int aim_rank, int start_dim,
                                            bool node_run_in_s8, float amax){
        //add dim use 1, start_dim -> first dim in res for input
        nvinfer1::Dims cur_shape = tensor_p->getDimensions();
        nvinfer1::IShuffleLayer* reshape_layer_p = network->addShuffle(*tensor_p);
        nvinfer1::Dims aim_shape;
        aim_shape.nbDims = aim_rank;
        for (int i = 0; i < aim_rank; i++) aim_shape.d[i] = 1;
        for (int i = 0; i < cur_shape.nbDims; i++) aim_shape.d[i + start_dim] = cur_shape.d[i];
        reshape_layer_p->setReshapeDimensions(aim_shape);
        nvinfer1::ITensor* output_tensor_p = reshape_layer_p->getOutput(0);
        if (amax > 0.0f) output_tensor_p->setDynamicRange(-amax, amax);
        // if (!node_run_in_s8) reshape_layer_p->setPrecision(nvinfer1::DataType::kHALF);
        return output_tensor_p;
    }

    int64_t TRTEngine::addModule(nvinfer1::INetworkDefinition* network, nlohmann::json node_cfg, bool on_dla){
        std::string node_name = node_cfg.at("name").get<std::string>();
        // std::cout<<"add layer "<<node_name<<std::endl;
        std::string node_type = node_cfg.at("type").get<std::string>();
        std::vector<std::string> node_inputs_name = node_cfg.at("input").get<std::vector<std::string>>();
        std::vector<std::string> node_outputs_name = node_cfg.at("output").get<std::vector<std::string>>();
        nlohmann::json node_attr = node_cfg.at("attr").get<nlohmann::json>();
        std::vector<nvinfer1::ITensor*> node_inputs(node_inputs_name.size());
        std::vector<nvinfer1::ITensor*> node_outputs(node_outputs_name.size());
        float amax = 1.0f;
        bool node_run_in_s8 = false;
        if (node_cfg.count("amax") != 0){
            amax = node_cfg.at("amax").get<float>();
            node_run_in_s8 = true;
        } 
        // nvinfer1::ILayer* cur_layer_p = nullptr;
        for (int i = 0; i < node_inputs_name.size(); i++){
            if ((initializer_tensors_table_.count(node_inputs_name[i]) != 0) && (nv_tensor_table_.count(node_inputs_name[i]) == 0)){
                addConstantTensor(network, node_inputs_name[i]);
            }
            node_inputs[i] = nv_tensor_table_.at(node_inputs_name[i]);
            // nvinfer1::Dims dims = node_inputs[i]->getDimensions();
            // for (int j = 0; j < dims.nbDims; j++) std::cout<<dims.d[j]<<' ';
            // std::cout<<std::endl;
        }
        if ((node_type == "Add") ||
                (node_type == "Sub") ||
                (node_type == "Mul") ||
                (node_type == "Div")){
            int dim0 = node_inputs[0]->getDimensions().nbDims;
            int dim1 = node_inputs[1]->getDimensions().nbDims;
            float amax0 = 1.0f;
            float amax1 = 1.0f;
            if (tensor_amax_table_.count(node_inputs_name[0]) != 0) amax0 = tensor_amax_table_.at(node_inputs_name[0]);
            if (tensor_amax_table_.count(node_inputs_name[1]) != 0) amax1 = tensor_amax_table_.at(node_inputs_name[1]);
            if (dim0 < dim1) node_inputs[0] = internBoardcastShuffle(network, node_inputs[0], dim1, dim1 - dim0, node_run_in_s8, amax0);
            else if (dim0 > dim1) node_inputs[1] = internBoardcastShuffle(network, node_inputs[1], dim0, dim0 - dim1, node_run_in_s8, amax1);
            else{
                nvinfer1::Dims dims0 = node_inputs[0]->getDimensions();
                nvinfer1::Dims dims1 = node_inputs[1]->getDimensions();
                for (int i = 0; i < dim0; i++){
                    if (dims0.d[i] != dims1.d[i] && dims0.d[i] != 1 && dims1.d[i] != 1){
                        std::cout<<"invalid input shapes for elementwise layer"<<std::endl;
                        return -1;
                    }
                }
            }
            nvinfer1::IElementWiseLayer* element_layer_p = network->addElementWise(*node_inputs[0], *node_inputs[1], nv_elem_op_table_.at(node_type));
            node_outputs[0] = element_layer_p->getOutput(0);
        }
        else if (node_type == "Sqrt"){
            nvinfer1::IUnaryLayer* sqrt_layer_p = network->addUnary(*node_inputs[0], nvinfer1::UnaryOperation::kSQRT);
            node_outputs[0] = sqrt_layer_p->getOutput(0);
        }
        else if (node_type == "Cast"){
#ifdef x86_64
            nvinfer1::ICastLayer* cast_layer_p = network->addCast(*node_inputs[0], nv_type_table_.at(node_attr.at("output_type").get<std::string>()));
            node_outputs[0] = cast_layer_p->getOutput(0);
#elif defined(JETSON_ORIN)
            nvinfer1::IPluginCreator* cast_plugin_creator = getPluginRegistry()->getPluginCreator("CastLayerPlugin_custom", "1");
            std::vector<nvinfer1::PluginField> cast_plugin_field;
            int32_t input_type_id = static_cast<int32_t>(node_inputs[0]->getType());
            std::string output_type_str = node_attr.at("output_type").get<std::string>();
            if (nv_type_table_.count(output_type_str) == 0){
                std::cout << "unsupported output type for cast layer " << output_type_str<<std::endl;
                return -1;
            }
            int32_t output_type_id = static_cast<int32_t>(nv_type_table_.at(output_type_str));
            cast_plugin_field.emplace_back(nvinfer1::PluginField("input_type", &input_type_id, nvinfer1::PluginFieldType::kINT32, 1));
            cast_plugin_field.emplace_back(nvinfer1::PluginField("output_type", &output_type_id, nvinfer1::PluginFieldType::kINT32, 1));
            nvinfer1::PluginFieldCollection cast_plugin_data;
            cast_plugin_data.nbFields = cast_plugin_field.size();
            cast_plugin_data.fields = cast_plugin_field.data();
            nvinfer1::IPluginV2* cast_plugin_obj_p = cast_plugin_creator->createPlugin(node_name.c_str(), &cast_plugin_data);
            nvinfer1::IPluginV2Layer* cast_plugin_layer_p = network->addPluginV2(&node_inputs[0], 1, *cast_plugin_obj_p);
            node_outputs[0] = cast_plugin_layer_p->getOutput(0);
#else
            std::cout<<"unsupported platform for cast layer"<<std::endl;
            return -2;
#endif
        }
        else if (node_type == "Concat"){
            nvinfer1::IConcatenationLayer* concat_layer_p = network->addConcatenation(node_inputs.data(), node_inputs.size());
            concat_layer_p->setAxis(node_attr.at("axis").get<int>());
            node_outputs[0] = concat_layer_p->getOutput(0);
        }
        else if (node_type == "Conv" || node_type == "ConvTranspose"){
            std::string weight_name = node_attr.at("weight_name").get<std::string>();
            std::string bias_name = node_attr.at("bias_name").get<std::string>();
            std::string weight_type = initializer_tensors_table_.at(weight_name)->getElementType();
            std::string bias_type = initializer_tensors_table_.at(bias_name)->getElementType();
            int out_channel = initializer_tensors_table_.at(weight_name)->getShape()[0];
            int in_channel = initializer_tensors_table_.at(weight_name)->getShape()[1];
            std::vector<int> kernel_size = node_attr.at("kernel_shape").get<std::vector<int>>();
            nvinfer1::Weights weight = {nv_type_table_.at(weight_type), nullptr, 0};
            weight.count = initializer_tensors_table_.at(weight_name)->getElementNum();
            // if (on_dla){
            //     int num_per_channel = weight.count / out_channel;
            //     float* weight_p = initializer_cpu_buffers_table_.at(weight_name)->getDataPtr<float>();
            //     for (int c = 0; c < out_channel; c++){
            //         float channel_max = 0.0f;
            //         int base_id = c*num_per_channel;
            //         for (int i = 0; i < num_per_channel; i++) channel_max = std::max(channel_max, std::abs(weight_p[base_id + i]));
            //         float scale = channel_max / 127.0f;
            //         for (int i = 0; i < num_per_channel; i++) weight_p[base_id + i] = std::min(channel_max, weight_p[base_id + i] - 0.0f * scale);
            //     }
            // }
            weight.values = initializer_cpu_buffers_table_.at(weight_name)->getDataPtr<void>();

            // std::vector<float> tmp = common::loadDataFromFile<float, float>("/home/dong/WS/FoundationPose/test_conv_weight.bin");
            // for (int i = 0; i < 8; i++) std::cout<<reinterpret_cast<const float*>(weight.values)[i]<<' ';
            // std::cout <<std::endl;
            // for (int i = 0; i < 8; i++) std::cout<<tmp[i]<<' ';
            // std::cout <<std::endl;
            // std::ofstream out_file;
            // out_file.open("../weights/" + weight_name + ".bin", std::ios::binary);
            // out_file.write(initializer_cpu_buffers_table_.at(weight_name)->getDataPtr<char>(), weight.count*sizeof(float));
            // out_file.close();

            nvinfer1::Weights bias = {nv_type_table_.at(bias_type), nullptr, 0};
            bias.count = initializer_tensors_table_.at(bias_name)->getElementNum();
            bias.values = initializer_cpu_buffers_table_.at(bias_name)->getDataPtr<void>();

            // std::vector<float> tmp_b = common::loadDataFromFile<float, float>("/home/dong/WS/FoundationPose/test_conv_bias.bin");
            // for (int i = 0; i < 8; i++) std::cout<<reinterpret_cast<const float*>(bias.values)[i]<<' ';
            // std::cout <<std::endl;
            // for (int i = 0; i < 8; i++) std::cout<<tmp_b[i]<<' ';
            // std::cout <<std::endl;

            std::vector<int> pads = node_attr.at("pads").get<std::vector<int>>();
            std::vector<int> dilations = node_attr.at("dilations").get<std::vector<int>>();
            std::vector<int> strides = node_attr.at("strides").get<std::vector<int>>();
            if (node_type == "Conv"){
                nvinfer1::IConvolutionLayer* conv_layer_p = network->addConvolutionNd(*node_inputs[0], out_channel,
                                                                                    nvinfer1::DimsHW{kernel_size[0], kernel_size[1]},
                                                                                    weight, bias);
                conv_layer_p->setDilationNd(nvinfer1::Dims2{dilations[0], dilations[1]});
                conv_layer_p->setStrideNd(nvinfer1::Dims2{strides[0], strides[1]});
                conv_layer_p->setPrePadding(nvinfer1::Dims2{pads[0], pads[2]});
                conv_layer_p->setPostPadding(nvinfer1::Dims2{pads[1], pads[3]});
                conv_layer_p->setNbGroups(node_attr.at("group").get<int>());
                node_outputs[0] = conv_layer_p->getOutput(0);
            }
            else{
                nvinfer1::IDeconvolutionLayer* deconv_layer_p = network->addDeconvolutionNd(*node_inputs[0], out_channel,
                                                                                    nvinfer1::DimsHW{kernel_size[0], kernel_size[1]},
                                                                                    weight, bias);
                deconv_layer_p->setDilationNd(nvinfer1::Dims2{dilations[0], dilations[1]});
                deconv_layer_p->setStrideNd(nvinfer1::Dims2{strides[0], strides[1]});
                deconv_layer_p->setPrePadding(nvinfer1::Dims2{pads[0], pads[2]});
                deconv_layer_p->setPostPadding(nvinfer1::Dims2{pads[1], pads[3]});
                deconv_layer_p->setNbGroups(node_attr.at("group").get<int>());
                node_outputs[0] = deconv_layer_p->getOutput(0);
            }
        }
        else if (node_type == "Relu" || node_type == "Sigmoid"){
            nvinfer1::IActivationLayer* relu_layer_p = network->addActivation(*node_inputs[0], nv_act_op_table_.at(node_type));
            node_outputs[0] = relu_layer_p->getOutput(0);
        }
        else if (node_type == "Slice"){
#if !defined x86_64 && !defined JETSON_ORIN
                std::cout<<"supporting problem in Slice layer for current trt version & paltform setting"<<std::endl;
                return -1;
#endif
            int axis = node_attr.at("axis").get<int>();
            int start = node_attr.at("start").get<int>();
            int stride = node_attr.at("step").get<int>();
            int size = node_attr.at("end").get<int>() - start;
#ifdef x86_64
            nvinfer1::ISliceLayer* slice_layer_p = network->addSlice(*node_inputs[0], nvinfer1::Dims{1,{start}}, nvinfer1::Dims{1,{size}},
                                                                    nvinfer1::Dims{1,{stride}});
            slice_layer_p->setAxes(nvinfer1::Dims{1,{axis}});
            node_outputs[0] = slice_layer_p->getOutput(0);
#endif
#ifdef JETSON_ORIN
            nvinfer1::Dims input_dim = node_inputs[0]->getDimensions();
            nvinfer1::Dims starts = input_dim;
            nvinfer1::Dims strides = input_dim;
            nvinfer1::Dims sizes = input_dim;
            for (int i = 0; i < input_dim.nbDims; i++){
                starts.d[i] = 0;
                strides.d[i] = 1;
            }
            starts.d[axis] = start;
            strides.d[axis] = stride;
            sizes.d[axis] = size;
            nvinfer1::ISliceLayer* slice_layer_p = network->addSlice(*node_inputs[0], starts, sizes, strides);
            node_outputs[0] = slice_layer_p->getOutput(0);
#endif
        }
        else if (node_type == "Reshape"){
            nvinfer1::IShuffleLayer* reshape_layer_p = network->addShuffle(*node_inputs[0]);
            std::vector<int> attr_shape = node_attr.at("shape").get<std::vector<int>>();
            nvinfer1::Dims shape;
            shape.nbDims = attr_shape.size();
            for (int i = 0; i < shape.nbDims; i++) shape.d[i] = attr_shape[i];
            reshape_layer_p->setReshapeDimensions(shape);
            node_outputs[0] = reshape_layer_p->getOutput(0);
        }
        else if (node_type == "Transpose"){
            nvinfer1::IShuffleLayer* tranpose_layer_p = network->addShuffle(*node_inputs[0]);
            std::vector<int> sequences = node_attr.at("sequences").get<std::vector<int>>();
            nvinfer1::Permutation seq;
            for (int i = 0; i < sequences.size(); i++) seq.order[i] = sequences[i];
            tranpose_layer_p->setFirstTranspose(seq);
            node_outputs[0] = tranpose_layer_p->getOutput(0);
        }
        else if (node_type == "MatMul"){
            int dim0 = node_inputs[0]->getDimensions().nbDims;
            int dim1 = node_inputs[1]->getDimensions().nbDims;
            float amax0 = 1.0f;
            float amax1 = 1.0f;
            if (tensor_amax_table_.count(node_inputs_name[0]) != 0) amax0 = tensor_amax_table_.at(node_inputs_name[0]);
            if (tensor_amax_table_.count(node_inputs_name[1]) != 0) amax1 = tensor_amax_table_.at(node_inputs_name[1]);
            if (dim0 < dim1) node_inputs[0] = internBoardcastShuffle(network, node_inputs[0], dim1, dim1 - dim0, node_run_in_s8, amax0);
            else if (dim0 > dim1) node_inputs[1] = internBoardcastShuffle(network, node_inputs[1], dim0, dim0 - dim1, node_run_in_s8, amax1);
            nvinfer1::IMatrixMultiplyLayer* matmul_layer_p = network->addMatrixMultiply(*node_inputs[0], nvinfer1::MatrixOperation::kNONE,
                                                                                        *node_inputs[1], nvinfer1::MatrixOperation::kNONE);
            node_outputs[0] = matmul_layer_p->getOutput(0);
        }
        else if (node_type == "Unsqueeze"){
            nvinfer1::IShuffleLayer* reshape_layer_p = network->addShuffle(*node_inputs[0]);
            int axis = node_attr.at("axis").get<int>();
            nvinfer1::Dims shape = node_inputs[0]->getDimensions();
            shape.nbDims += 1;
            for (int i = shape.nbDims - 1; i > axis; i--) shape.d[i] = shape.d[i - 1];
            shape.d[axis] = 1;
            reshape_layer_p->setReshapeDimensions(shape);
            node_outputs[0] = reshape_layer_p->getOutput(0);
        }
        else if (node_type == "Squeeze"){
            nvinfer1::IShuffleLayer* reshape_layer_p = network->addShuffle(*node_inputs[0]);
            std::vector<int> axes = node_attr.at("axes").get<std::vector<int>>();
            nvinfer1::Dims in_shape = node_inputs[0]->getDimensions();
            nvinfer1::Dims out_shape;
            out_shape.nbDims = in_shape.nbDims - axes.size();
            int out_shape_idx = 0;
            for (int i = 0; i < axes.size(); i++) in_shape.d[axes[i]] = -1;
            for (int i = 0; i < in_shape.nbDims; i++){
                if (in_shape.d[i] != -1){
                    out_shape.d[out_shape_idx] = in_shape.d[i];
                    out_shape_idx ++;
                }
            }
            reshape_layer_p->setReshapeDimensions(out_shape);
            node_outputs[0] = reshape_layer_p->getOutput(0);
        }
        else if (node_type == "Gather"){
            std::vector<int> indices = node_attr.at("indice").get<std::vector<int>>();
            int axis = node_attr.at("axis").get<int>();
            std::string name = node_name + "indices";
            std::string data_type = "int32";
            std::vector<int> shape = {int(indices.size())};
            int64_t data_length = sizeof(int) * indices.size();
            memory::CPUBufferPtr tensor_data_buffer_cpu = std::make_shared<memory::CPUBuffer>(name, data_length);
            tensor_data_buffer_cpu->copyFromCPU(indices.data(), data_length);
            initializer_cpu_buffers_table_.emplace(name, tensor_data_buffer_cpu);
            initializer_tensors_table_.emplace(name, std::make_shared<memory::Tensor>(name, data_type, data_length, shape));
            addConstantTensor(network, name);
            nvinfer1::IGatherLayer* gather_layer_p = network->addGather(*node_inputs[0], *nv_tensor_table_.at(name), axis);
            node_outputs[0] = gather_layer_p->getOutput(0);
        }
        else if (node_type == "Softmax"){
            int axis = node_attr.at("axis").get<int>();
            nvinfer1::ISoftMaxLayer* softmax_layer_p = network->addSoftMax(*node_inputs[0]);
            softmax_layer_p->setAxes(1U << axis);
            node_outputs[0] = softmax_layer_p->getOutput(0);
        }
        else if (node_type == "Gemm"){
            float alpha = node_attr.at("alpha").get<float>();
            float beta = node_attr.at("beta").get<float>();
            if (alpha > 1.0f + 1e-5 || alpha < 1.0f - 1e-5 || beta > 1.0f + 1e-5 || beta < 1.0f - 1e-5){
                std::cout<<"Gemm will be treated as conv1x1 layer, request alpha, beta = 1 in onnx file"<<std::endl;
                return -1;
            }
            //weight should transpose due to conv weight distr. is co ci k, but gemm weight is ci co, shall be done in onnx2net
            std::string weight_tensor_name = node_attr.at("weight_name").get<std::string>();
            std::string bias_tensor_name = node_attr.at("bias_name").get<std::string>();
            std::string weight_type = initializer_tensors_table_.at(weight_tensor_name)->getElementType();
            int out_channel = initializer_tensors_table_.at(weight_tensor_name)->getShape()[0];
            nvinfer1::Weights weight{nv_type_table_.at(weight_type), nullptr, 0};
            weight.count = initializer_tensors_table_.at(weight_tensor_name)->getElementNum();
            weight.values = initializer_cpu_buffers_table_.at(weight_tensor_name)->getDataPtr<void>();
            std::string bias_type = initializer_tensors_table_.at(bias_tensor_name)->getElementType();
            nvinfer1::Weights bias{nv_type_table_.at(bias_type), nullptr, 0};
            bias.count = initializer_tensors_table_.at(bias_tensor_name)->getElementNum();
            bias.values = initializer_cpu_buffers_table_.at(bias_tensor_name)->getDataPtr<void>();
            nvinfer1::Dims input_shape = node_inputs[0]->getDimensions();
            if (input_shape.nbDims != 2){
                std::cout<<"Gemm input should be M*K and treated as NC*1*1, but get dims is "<<input_shape.nbDims<<std::endl;
                return -1;
            }
            nvinfer1::IShuffleLayer* reshape_input_layer_p = network->addShuffle(*node_inputs[0]);
            reshape_input_layer_p->setReshapeDimensions(nvinfer1::Dims4{input_shape.d[0], input_shape.d[1], 1, 1});
            nvinfer1::ITensor* reshaped_input_p = reshape_input_layer_p->getOutput(0);
            nvinfer1::IConvolutionLayer* conv1x1_layer_p = network->addConvolutionNd(*reshaped_input_p, out_channel, nvinfer1::DimsHW{1,1}, weight, bias);
            nvinfer1::ITensor* conv_output_p = conv1x1_layer_p->getOutput(0);
            nvinfer1::IShuffleLayer* reshape_output_layer_p = network->addShuffle(*conv_output_p);
            reshape_output_layer_p->setReshapeDimensions(nvinfer1::Dims2{input_shape.d[0], out_channel});
            node_outputs[0] = reshape_output_layer_p->getOutput(0);
        }
        else if (node_type == "LayerNormalization"){
            std::string scale_name = node_attr.at("weight_name").get<std::string>();
            std::string bias_name = node_attr.at("bias_name").get<std::string>();
            float eps = node_attr.at("eps").get<float>();
            int axis = node_attr.at("axis").get<int>();
            nvinfer1::Dims in_shape = node_inputs[0]->getDimensions();
            int last_dim = in_shape.d[in_shape.nbDims - 1];
            if (axis == in_shape.nbDims - 1 && last_dim == 512){
                nvinfer1::IPluginCreator* layernorm_plugin_creator = getPluginRegistry()->getPluginCreator("LayerNormSeriesPlugin_custom", "1");
                std::vector<nvinfer1::PluginField> layernorm_plugin_field;
                int32_t input_type_id = static_cast<int32_t>(node_inputs[0]->getType());
                layernorm_plugin_field.emplace_back(nvinfer1::PluginField("data_type", &input_type_id, nvinfer1::PluginFieldType::kINT32, 1));
                layernorm_plugin_field.emplace_back(nvinfer1::PluginField("eps", &eps, nvinfer1::PluginFieldType::kFLOAT32, 1));
                int scale_ele_num = initializer_tensors_table_.at(scale_name)->getElementNum();
                int bias_ele_num = initializer_tensors_table_.at(bias_name)->getElementNum();
                void* scale_data_p = initializer_cpu_buffers_table_.at(scale_name)->getDataPtr<void>();
                void* bias_data_p = initializer_cpu_buffers_table_.at(bias_name)->getDataPtr<void>();
                layernorm_plugin_field.emplace_back(nvinfer1::PluginField("scales", scale_data_p, nvinfer1::PluginFieldType::kFLOAT32, scale_ele_num));
                layernorm_plugin_field.emplace_back(nvinfer1::PluginField("bias", bias_data_p, nvinfer1::PluginFieldType::kFLOAT32, bias_ele_num));
                nvinfer1::PluginFieldCollection layernorm_plugin_data;
                layernorm_plugin_data.nbFields = layernorm_plugin_field.size();
                layernorm_plugin_data.fields = layernorm_plugin_field.data();
                nvinfer1::IPluginV2* layernorm_plugin_obj_p = layernorm_plugin_creator->createPlugin(node_name.c_str(), &layernorm_plugin_data);
                nvinfer1::IPluginV2Layer* layernorm_plugin_layer_p = network->addPluginV2(&node_inputs[0], 1, *layernorm_plugin_obj_p);
                node_outputs[0] = layernorm_plugin_layer_p->getOutput(0);
            }
            else{
                uint32_t axes_mask = 1U << axis;
#ifdef x86_64            
                addConstantTensor(network, scale_name);
                addConstantTensor(network, bias_name);
                float amax0 = 1.0f;
                float amax1 = 1.0f;
                if (tensor_amax_table_.count(node_inputs_name[0]) != 0) amax0 = tensor_amax_table_.at(node_inputs_name[0]);
                if (tensor_amax_table_.count(node_inputs_name[1]) != 0) amax1 = tensor_amax_table_.at(node_inputs_name[1]);
                if (node_inputs[0]->getDimensions().nbDims > nv_tensor_table_.at(scale_name)->getDimensions().nbDims){
                    nv_tensor_table_.at(scale_name) = internBoardcastShuffle(network, nv_tensor_table_.at(scale_name), node_inputs[0]->getDimensions().nbDims,
                                                            node_inputs[0]->getDimensions().nbDims - nv_tensor_table_.at(scale_name)->getDimensions().nbDims,
                                                            node_run_in_s8, amax0);
                }
                if (node_inputs[0]->getDimensions().nbDims > nv_tensor_table_.at(bias_name)->getDimensions().nbDims){
                    nv_tensor_table_.at(bias_name) = internBoardcastShuffle(network, nv_tensor_table_.at(bias_name), node_inputs[0]->getDimensions().nbDims,
                                                            node_inputs[0]->getDimensions().nbDims - nv_tensor_table_.at(bias_name)->getDimensions().nbDims,
                                                            node_run_in_s8, amax1);
                }
                nvinfer1::INormalizationLayer* layernorm_layer_p = network->addNormalization(*node_inputs[0],
                                                                                            *nv_tensor_table_.at(scale_name),
                                                                                            *nv_tensor_table_.at(bias_name),
                                                                                            axes_mask);
                layernorm_layer_p->setEpsilon(eps);
                node_outputs[0] = layernorm_layer_p->getOutput(0);
#elif defined(JETSON_ORIN)
                nvinfer1::IPluginCreator* axes_norm_plugin_creator = getPluginRegistry()->getPluginCreator("AxesNormalizationPlugin_custom", "1");
                std::vector<nvinfer1::PluginField> axes_norm_plugin_field;
                int32_t input_type_id = static_cast<int32_t>(node_inputs[0]->getType());
                axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("data_type", &input_type_id, nvinfer1::PluginFieldType::kINT32, 1));
                axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("axes_mask", &axes_mask, nvinfer1::PluginFieldType::kINT32, 1));
                axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("eps", &eps, nvinfer1::PluginFieldType::kFLOAT32, 1));
                int scale_ele_num = initializer_tensors_table_.at(scale_name)->getElementNum();
                int bias_ele_num = initializer_tensors_table_.at(bias_name)->getElementNum();
                void* scale_data_p = initializer_cpu_buffers_table_.at(scale_name)->getDataPtr<void>();
                void* bias_data_p = initializer_cpu_buffers_table_.at(bias_name)->getDataPtr<void>();
                axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("scales", scale_data_p, nvinfer1::PluginFieldType::kFLOAT32, scale_ele_num));
                axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("bias", bias_data_p, nvinfer1::PluginFieldType::kFLOAT32, bias_ele_num));
                nvinfer1::PluginFieldCollection axes_norm_plugin_data;
                axes_norm_plugin_data.nbFields = axes_norm_plugin_field.size();
                axes_norm_plugin_data.fields = axes_norm_plugin_field.data();
                nvinfer1::IPluginV2* axes_norm_plugin_obj_p = axes_norm_plugin_creator->createPlugin(node_name.c_str(), &axes_norm_plugin_data);
                nvinfer1::IPluginV2Layer* layernorm_plugin_layer_p = network->addPluginV2(&node_inputs[0], 1, *axes_norm_plugin_obj_p);
                node_outputs[0] = layernorm_plugin_layer_p->getOutput(0);
#else
                std::cout<<"unsupported platform for cast layer"<<std::endl;
                return -2;
#endif
            }
        }
        else if (node_type == "ReduceMean"){
            std::vector<int> axes = node_attr.at("axes").get<std::vector<int>>();
            bool keep_dims = static_cast<bool>(node_attr.at("keepdims").get<int>());
            uint32_t axes_mask = 0x00000000;
            for (int i = 0; i < axes.size(); i++) axes_mask |= (1U << axes[i]);
            nvinfer1::IReduceLayer* reduce_mean_layer_p = network->addReduce(*node_inputs[0], nvinfer1::ReduceOperation::kAVG, axes_mask, keep_dims);
            node_outputs[0] = reduce_mean_layer_p->getOutput(0);
        }
        else if (node_type == "GlobalAveragePool"){
            bool keep_dims = true;
            uint32_t axes_mask = 0x00000000;
            int dim0 = node_inputs[0]->getDimensions().nbDims;
            std::cout<<"global average op has an input with dims "<<dim0
                    <<", the first 2 dim treated as BC will not be reduced, remained dim will reduce to 1, ndim will be kept"<<std::endl;
            for (int i = 2; i < dim0; i++) axes_mask |= (1U << i);
            nvinfer1::IReduceLayer* global_average_layer_p = network->addReduce(*node_inputs[0], nvinfer1::ReduceOperation::kAVG, axes_mask, keep_dims);
            node_outputs[0] = global_average_layer_p->getOutput(0);
        }
        else if (node_type == "MaxPool"){
            int ceil_mode = node_attr.at("ceil_mode").get<int>();
            std::vector<int> kernel_shape = node_attr.at("kernel_shape").get<std::vector<int>>();
            std::vector<int> pads = node_attr.at("pads").get<std::vector<int>>();
            std::vector<int> strides = node_attr.at("strides").get<std::vector<int>>();
            int dim = kernel_shape.size();
            nvinfer1::Dims kernel_shape_dim = {dim, {}};
            nvinfer1::Dims pre_pads_dim = {dim, {}};
            nvinfer1::Dims post_pads_dim = {dim, {}};
            nvinfer1::Dims strides_dim = {dim, {}};
            for (int i = 0; i < dim; i++){
                kernel_shape_dim.d[i] = kernel_shape[i];
                pre_pads_dim.d[i] = pads[i*2];
                post_pads_dim.d[i] = pads[i*2 + 1];
                strides_dim.d[i] = strides[i];
            }
            nvinfer1::PaddingMode nv_pad_mod;
            if (ceil_mode == 1) nv_pad_mod = nvinfer1::PaddingMode::kEXPLICIT_ROUND_UP;
            else if (ceil_mode == 0) nv_pad_mod = nvinfer1::PaddingMode::kEXPLICIT_ROUND_DOWN;
            else{
                std::cout<<"unknown ceil mode in pooling layer"<<std::endl;
                return -1;
            }
            nvinfer1::IPoolingLayer* max_pool_layer_p = network->addPoolingNd(*node_inputs[0], nvinfer1::PoolingType::kMAX, kernel_shape_dim);
            max_pool_layer_p->setPaddingMode(nv_pad_mod);
            max_pool_layer_p->setPrePadding(pre_pads_dim);
            max_pool_layer_p->setPostPadding(post_pads_dim);
            max_pool_layer_p->setStrideNd(strides_dim);
            node_outputs[0] = max_pool_layer_p->getOutput(0);
        }
        else if (node_type == "Resize"){
            std::string coord_trans_mode = node_attr.at("coordinate_transformation_mode").get<std::string>();
            std::string interpolation_mode = node_attr.at("mode").get<std::string>();
            std::string nearest_mode = node_attr.at("nearest_mode").get<std::string>();
            float cubic_coeff = node_attr.at("cubic_coeff_a").get<float>();
            std::vector<float> scales = node_attr.at("scales").get<std::vector<float>>();
            nvinfer1::IResizeLayer* resize_layer_p = network->addResize(*node_inputs[0]);
            nvinfer1::ResizeCoordinateTransformation nv_coord_trans_mode;
            if (coord_trans_mode == "half_pixel") nv_coord_trans_mode = nvinfer1::ResizeCoordinateTransformation::kHALF_PIXEL;
            else if (coord_trans_mode == "asymmetric") nv_coord_trans_mode = nvinfer1::ResizeCoordinateTransformation::kASYMMETRIC;
            else if (coord_trans_mode == "align_corners") nv_coord_trans_mode = nvinfer1::ResizeCoordinateTransformation::kALIGN_CORNERS;
            else{
                std::cout<<"unknown coordinate transformation mode for resize layer yet"<<std::endl;
                return -1;
            }
            nvinfer1::ResizeRoundMode nv_round_mode;
            if (nearest_mode == "floor") nv_round_mode = nvinfer1::ResizeRoundMode::kFLOOR;
            else{
                std::cout<<"unknown round mode for resize layer yet"<<std::endl;
                return -1;
            }
            nvinfer1::InterpolationMode nv_interpolation_mode;
            if (interpolation_mode == "linear") nv_interpolation_mode = nvinfer1::InterpolationMode::kLINEAR;
            else if (interpolation_mode == "nearest") nv_interpolation_mode = nvinfer1::InterpolationMode::kNEAREST;
            else if (interpolation_mode == "bicubic") nv_interpolation_mode = nvinfer1::InterpolationMode::kCUBIC;
            else{
                std::cout<<"unknown interpolation mode for resize layer yet"<<std::endl;
                return -1;
            }
            resize_layer_p->setCoordinateTransformation(nv_coord_trans_mode);
            resize_layer_p->setResizeMode(nv_interpolation_mode);
            resize_layer_p->setNearestRounding(nv_round_mode);
            resize_layer_p->setCubicCoeff(cubic_coeff);
            resize_layer_p->setScales(scales.data(), scales.size());
            node_outputs[0] = resize_layer_p->getOutput(0);
        }
        else if (node_type == "InstanceNormalization"){
            std::string scale_name = node_attr.at("weight_name").get<std::string>();
            std::string bias_name = node_attr.at("bias_name").get<std::string>();
            float eps = node_attr.at("eps").get<float>();
            uint32_t axes_mask = 0;
            //suppose is BC... 2-last dims will do norm
            int input_shape = node_inputs[0]->getDimensions().nbDims;
            for (int i = 2; i < input_shape; i++) axes_mask |= 1U << i;
#ifdef x86_64
            addConstantTensor(network, scale_name);
            addConstantTensor(network, bias_name);
            float amax0 = 1.0f;
            float amax1 = 1.0f;
            if (tensor_amax_table_.count(node_inputs_name[0]) != 0) amax0 = tensor_amax_table_.at(node_inputs_name[0]);
            if (tensor_amax_table_.count(node_inputs_name[1]) != 0) amax1 = tensor_amax_table_.at(node_inputs_name[1]);
            if (node_inputs[0]->getDimensions().nbDims > nv_tensor_table_.at(scale_name)->getDimensions().nbDims){
                nv_tensor_table_.at(scale_name) = internBoardcastShuffle(network, nv_tensor_table_.at(scale_name), node_inputs[0]->getDimensions().nbDims, 1,
                                                                        node_run_in_s8, amax0);
            }
            if (node_inputs[0]->getDimensions().nbDims > nv_tensor_table_.at(bias_name)->getDimensions().nbDims){
                nv_tensor_table_.at(bias_name) = internBoardcastShuffle(network, nv_tensor_table_.at(bias_name), node_inputs[0]->getDimensions().nbDims, 1,
                                                                        node_run_in_s8, amax1);
            }
            nvinfer1::INormalizationLayer* layernorm_layer_p = network->addNormalization(*node_inputs[0],
                                                                                        *nv_tensor_table_.at(scale_name),
                                                                                        *nv_tensor_table_.at(bias_name),
                                                                                        axes_mask);
            layernorm_layer_p->setEpsilon(eps);
            node_outputs[0] = layernorm_layer_p->getOutput(0);
#elif defined(JETSON_ORIN)
            nvinfer1::IPluginCreator* axes_norm_plugin_creator = getPluginRegistry()->getPluginCreator("AxesNormalizationPlugin_custom", "1");
            std::vector<nvinfer1::PluginField> axes_norm_plugin_field;
            int32_t input_type_id = static_cast<int32_t>(node_inputs[0]->getType());
            axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("data_type", &input_type_id, nvinfer1::PluginFieldType::kINT32, 1));
            axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("axes_mask", &axes_mask, nvinfer1::PluginFieldType::kINT32, 1));
            axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("eps", &eps, nvinfer1::PluginFieldType::kFLOAT32, 1));
            int scale_ele_num = initializer_tensors_table_.at(scale_name)->getElementNum();
            int bias_ele_num = initializer_tensors_table_.at(bias_name)->getElementNum();
            void* scale_data_p = initializer_cpu_buffers_table_.at(scale_name)->getDataPtr<void>();
            void* bias_data_p = initializer_cpu_buffers_table_.at(bias_name)->getDataPtr<void>();
            axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("scales", scale_data_p, nvinfer1::PluginFieldType::kFLOAT32, scale_ele_num));
            axes_norm_plugin_field.emplace_back(nvinfer1::PluginField("bias", bias_data_p, nvinfer1::PluginFieldType::kFLOAT32, bias_ele_num));
            nvinfer1::PluginFieldCollection axes_norm_plugin_data;
            axes_norm_plugin_data.nbFields = axes_norm_plugin_field.size();
            axes_norm_plugin_data.fields = axes_norm_plugin_field.data();
            nvinfer1::IPluginV2* axes_norm_plugin_obj_p = axes_norm_plugin_creator->createPlugin(node_name.c_str(), &axes_norm_plugin_data);
            nvinfer1::IPluginV2Layer* instance_norm_plugin_layer_p = network->addPluginV2(&node_inputs[0], 1, *axes_norm_plugin_obj_p);
            node_outputs[0] = instance_norm_plugin_layer_p->getOutput(0);
#else
            std::cout<<"unsupported platform for instance norm layer"<<std::endl;
            return -2;
#endif
        }
        else if (node_type == "Split"){
            std::cout<<"Split node will be regard as multi-slice-layers instead, steps must be 1"<<std::endl;
#if !defined x86_64 && !defined JETSON_ORIN
            std::cout<<"supporting problem in Slice layer for current trt version & platform setting"<<std::endl;
            return -1;
#endif
            int axis = node_attr.at("axis").get<int>();
            std::vector<int> start = node_attr.at("start").get<std::vector<int>>();
            std::vector<int> end = node_attr.at("end").get<std::vector<int>>();
            int stride = 1;
            std::vector<int> size(start.size());
            for (int i = 0; i < size.size(); i++) size[i] = end[i] - start[i];
#ifdef x86_64
            for (int i = 0; i < node_outputs.size(); i++){
                nvinfer1::ISliceLayer* slice_layer_p = network->addSlice(*node_inputs[0], nvinfer1::Dims{1,{start[i]}}, nvinfer1::Dims{1,{size[i]}},
                                                                        nvinfer1::Dims{1,{stride}});
                slice_layer_p->setAxes(nvinfer1::Dims{1,{axis}});
                node_outputs[i] = slice_layer_p->getOutput(0);
            }
#endif
#ifdef JETSON_ORIN
            nvinfer1::Dims input_dim = node_inputs[0]->getDimensions();
            nvinfer1::Dims starts = input_dim;
            nvinfer1::Dims strides = input_dim;
            nvinfer1::Dims sizes = input_dim;
            for (int i = 0; i < input_dim.nbDims; i++){
                starts.d[i] = 0;
                strides.d[i] = 1;
            }
            for (int i = 0; i < node_outputs.size(); i++){
                starts.d[axis] = start[i];
                strides.d[axis] = stride;
                sizes.d[axis] = size[i];
                nvinfer1::ISliceLayer* slice_layer_p = network->addSlice(*node_inputs[0], starts, sizes, strides);
                node_outputs[i] = slice_layer_p->getOutput(0);
            }
#endif
        }
        else if (node_type == "AttnBlock"){
            int32_t input_type_id = static_cast<int32_t>(node_inputs[0]->getType());
            std::string qkv_weight_name = node_attr.at("qkv_weight_name").get<std::string>();
            std::string qkv_bias_name = node_attr.at("qkv_bias_name").get<std::string>();
            std::string out_weight_name = node_attr.at("out_weight_name").get<std::string>();
            std::string out_bias_name = node_attr.at("out_bias_name").get<std::string>();
            std::string norm_scale_name = node_attr.at("norm_scale_name").get<std::string>();
            std::string norm_bias_name = node_attr.at("norm_bias_name").get<std::string>();
            int batch = node_attr.at("batch").get<int>();
            int seq_len = node_attr.at("seq_len").get<int>();
            int num_head = node_attr.at("num_head").get<int>();
            int head_dim = node_attr.at("head_dim").get<int>();
            int channel_input = node_attr.at("channel_input").get<int>();
            int channel_output = node_attr.at("channel_output").get<int>();
            float eps = node_attr.at("eps").get<float>();
            nvinfer1::IPluginCreator* attn_block_plugin_creator = getPluginRegistry()->getPluginCreator("AttentionBlockPlugin_custom", "1");
            std::vector<nvinfer1::PluginField> attn_block_plugin_field;
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("data_type", &input_type_id, nvinfer1::PluginFieldType::kINT32, 1));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("batch", &batch, nvinfer1::PluginFieldType::kINT32, 1));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("seq_len", &seq_len, nvinfer1::PluginFieldType::kINT32, 1));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("num_head", &num_head, nvinfer1::PluginFieldType::kINT32, 1));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("head_dim", &head_dim, nvinfer1::PluginFieldType::kINT32, 1));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("channel_input", &channel_input, nvinfer1::PluginFieldType::kINT32, 1));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("channel_output", &channel_output, nvinfer1::PluginFieldType::kINT32, 1));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("eps", &eps, nvinfer1::PluginFieldType::kFLOAT32, 1));
            int qkv_weight_ele_num = initializer_tensors_table_.at(qkv_weight_name)->getElementNum();
            int qkv_bias_ele_num = initializer_tensors_table_.at(qkv_bias_name)->getElementNum();
            int out_weight_ele_num = initializer_tensors_table_.at(out_weight_name)->getElementNum();
            int out_bias_ele_num = initializer_tensors_table_.at(out_bias_name)->getElementNum();
            int norm_scale_ele_num = initializer_tensors_table_.at(norm_scale_name)->getElementNum();
            int norm_bias_ele_num = initializer_tensors_table_.at(norm_bias_name)->getElementNum();
            void* qkv_weight_data_p = initializer_cpu_buffers_table_.at(qkv_weight_name)->getDataPtr<void>();
            void* qkv_bias_data_p = initializer_cpu_buffers_table_.at(qkv_bias_name)->getDataPtr<void>();
            void* out_weight_data_p = initializer_cpu_buffers_table_.at(out_weight_name)->getDataPtr<void>();
            void* out_bias_data_p = initializer_cpu_buffers_table_.at(out_bias_name)->getDataPtr<void>();
            void* norm_scale_data_p = initializer_cpu_buffers_table_.at(norm_scale_name)->getDataPtr<void>();
            void* norm_bias_data_p = initializer_cpu_buffers_table_.at(norm_bias_name)->getDataPtr<void>();
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("qkv_weight", qkv_weight_data_p, nvinfer1::PluginFieldType::kFLOAT32, qkv_weight_ele_num));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("qkv_bias", qkv_bias_data_p, nvinfer1::PluginFieldType::kFLOAT32, qkv_bias_ele_num));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("out_weight", out_weight_data_p, nvinfer1::PluginFieldType::kFLOAT32, out_weight_ele_num));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("out_bias", out_bias_data_p, nvinfer1::PluginFieldType::kFLOAT32, out_bias_ele_num));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("norm_scale", norm_scale_data_p, nvinfer1::PluginFieldType::kFLOAT32, norm_scale_ele_num));
            attn_block_plugin_field.emplace_back(nvinfer1::PluginField("norm_bias", norm_bias_data_p, nvinfer1::PluginFieldType::kFLOAT32, norm_bias_ele_num));
            nvinfer1::PluginFieldCollection attn_block_plugin_data;
            attn_block_plugin_data.nbFields = attn_block_plugin_field.size();
            attn_block_plugin_data.fields = attn_block_plugin_field.data();
            nvinfer1::IPluginV2* attn_block_plugin_obj_p = attn_block_plugin_creator->createPlugin(node_name.c_str(), &attn_block_plugin_data);
            nvinfer1::IPluginV2Layer* attn_block_plugin_layer_p = network->addPluginV2(&node_inputs[0], 1, *attn_block_plugin_obj_p);
            node_outputs[0] = attn_block_plugin_layer_p->getOutput(0);
        }
        else{
            std::cout<<"unsupported node type yet for "<<node_type<<std::endl;
            return -1;
        }
        for (int i = 0; i < node_outputs_name.size(); i++){
            //默认只有一个输出，多个输出情况需要重新考虑
            if (amax > 0.0f) node_outputs[i]->setDynamicRange(-amax, amax);
            node_outputs[i]->setName(node_outputs_name[i].c_str());
            nv_tensor_table_.emplace(node_outputs_name[i], node_outputs[i]);
            if (node_type == "ConvTranspose"){
                nvinfer1::Dims dim = node_outputs[i]->getDimensions();
                std::cout<<node_name<<", "<<node_outputs_name[i]<<": "<<dim.nbDims<<std::endl;
                for (int j = 0; j < dim.nbDims; j++) std::cout<<dim.d[j]<<' ';
                std::cout<<std::endl;
            }
        }
        // if (!node_run_in_s8) cur_layer_p->setPrecision(nvinfer1::DataType::kHALF);
        return 0;
    }
}