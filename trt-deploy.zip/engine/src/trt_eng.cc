#include "trt_eng.h"

namespace engine{

    TRTEngine::~TRTEngine(){
#ifdef JETSON_ORIN
        if (on_dla_){
            general_buffer_pool_.clearBufferPool(dev_handle_);
            general_sync_obj_pool_.clearSyncObjPool(dev_handle_);
        }
#endif
        if (use_cuda_graph_){
            cudaGraphDestroy(graph_);
            cudaGraphExecDestroy(graph_infer_);
            for (int i = 0; i < inputs_num_; i++) graph_input_fixed_p_vec_[i] = nullptr;
            for (int i = 0; i < outputs_num_; i++) graph_output_fixed_p_vec_[i] = nullptr;
        }
        std::cout<<"deconstruct trt eng"<<std::endl;
    }

    void TRTEngine::destroy(){
        //似乎智能指针之后调用的话会发生 double free
        delete this;
    }
    bool TRTEngine::enginePrepare(std::string net_file_path, std::string eng_file_path){
        return true;
    }
    bool TRTEngine::loadEngineModel(const std::string& model_file_path){
        std::ifstream eng_file(model_file_path, std::ios::binary);
        if (!eng_file.good()){
            std::cout<< "eng: " << engine_name_ <<" engine file path wrong: "<<model_file_path<<" no such file"<<std::endl;
            return false;
        }
        eng_file.seekg(0, eng_file.end);
        int64_t end_pos = eng_file.tellg();
        eng_file.seekg(0, eng_file.beg);
        int64_t beg_pos = eng_file.tellg();
        int64_t file_length = end_pos - beg_pos;
        engine_file_data_.resize(file_length);
        eng_file.read(engine_file_data_.data(), file_length);
        eng_file.close();
        return true;
    }
    bool TRTEngine::initEngineModel(){
        if (on_dla_){
#ifdef JETSON_ORIN
            dla_ret_ = cudlaCreateDevice(device_id_, &dev_handle_, CUDLA_STANDALONE);
            if (dla_ret_ != cudlaSuccess){
                std::cout<<"failed create dla device"<<std::endl;
                return false;
            }
            dla_ret_ = cudlaModuleLoadFromMemory(dev_handle_, reinterpret_cast<uint8_t*>(engine_file_data_.data()), engine_file_data_.size(), &module_handle_, 0);
            if (dla_ret_ != cudlaSuccess){
                std::cout<<"failed load dla into device"<<std::endl;
                return false;
            }
            dla_ret_ = cudlaModuleGetAttributes(module_handle_, CUDLA_NUM_INPUT_TENSORS, &dla_model_attr_);
            int dla_input_num = dla_model_attr_.numInputTensors;
            std::cout<<"dla input num: "<<inputs_num_<<' '<<dla_input_num<<std::endl;
            dla_ret_ = cudlaModuleGetAttributes(module_handle_, CUDLA_NUM_OUTPUT_TENSORS, &dla_model_attr_);
            int dla_output_num = dla_model_attr_.numOutputTensors;
            std::cout<<"dla output num: "<<outputs_num_<<' '<<dla_output_num<<std::endl;
            if (inputs_num_ != dla_input_num || outputs_num_ != dla_output_num){
                std::cout<<"dla input num or output num not consistent"<<std::endl;
                return false;
            }
            std::vector<cudlaModuleTensorDescriptor> dla_input_tensor_desc(inputs_num_);
            std::vector<cudlaModuleTensorDescriptor> dla_output_tensor_desc(outputs_num_);
            dla_model_attr_.inputTensorDesc = dla_input_tensor_desc.data();
            dla_ret_ = cudlaModuleGetAttributes(module_handle_, CUDLA_INPUT_TENSOR_DESCRIPTORS, &dla_model_attr_); 
            dla_model_attr_.outputTensorDesc = dla_output_tensor_desc.data();
            dla_ret_ = cudlaModuleGetAttributes(module_handle_, CUDLA_OUTPUT_TENSOR_DESCRIPTORS, &dla_model_attr_);
            dla_inputs_p_vec_.resize(inputs_num_);
            dla_outputs_p_vec_.resize(outputs_num_);
            dla_inputs_name_vec_.resize(inputs_num_);
            dla_outputs_name_vec_.resize(outputs_num_);
            for (int i = 0; i < inputs_num_; i++){
                std::string name = dla_input_tensor_desc[i].name;
                uint64_t size = dla_input_tensor_desc[i].size;
                general_buffer_pool_.createBuffer(dev_handle_, name, size);
                nvscibuffer::GeneralBufferPtr tmp_buffer_p = general_buffer_pool_.getBufferPtr(name);
                dla_mem_map_.emplace(name, tmp_buffer_p->getDlaPtr());
                gpu_mem_map_.emplace(name, tmp_buffer_p->getGpuPtr());
                cpu_mem_map_.emplace(name, tmp_buffer_p->getCpuPtr());
                dla_mem_size_map_.emplace(name, size);
                dla_inputs_p_vec_[i] = tmp_buffer_p->getDlaPtr();
                dla_inputs_name_vec_[i] = name;
                std::cout<<name<<std::endl;
            }
            for (int i = 0; i < outputs_num_; i++){
                std::string name = dla_output_tensor_desc[i].name;
                uint64_t size = dla_output_tensor_desc[i].size;
                general_buffer_pool_.createBuffer(dev_handle_, name, size);
                nvscibuffer::GeneralBufferPtr tmp_buffer_p = general_buffer_pool_.getBufferPtr(name);
                dla_mem_map_.emplace(name, tmp_buffer_p->getDlaPtr());
                gpu_mem_map_.emplace(name, tmp_buffer_p->getGpuPtr());
                cpu_mem_map_.emplace(name, tmp_buffer_p->getCpuPtr());
                dla_mem_size_map_.emplace(name, size);
                dla_outputs_p_vec_[i] = tmp_buffer_p->getDlaPtr();
                dla_outputs_name_vec_[i] = name;
                std::cout<<name<<std::endl;
            }
            general_sync_obj_pool_.createSyncObj(dev_handle_, engine_name_ + "sync_obj");
            nvscisync::GeneralSyncObjPtr tmp_sync_obj_p = general_sync_obj_pool_.getSyncObjPtr(engine_name_ + "sync_obj");
            dla_wait_cpu_events_p_ = tmp_sync_obj_p->getDlaWaitCpuEventPtr();
            dla_signal_cpu_events_p_ = tmp_sync_obj_p->getDlaSignalCpuEventPtr();
            dla_wait_cuda_events_p_ = tmp_sync_obj_p->getDlaWaitGpuEventPtr();
            dla_signal_cuda_events_p_ = tmp_sync_obj_p->getDlaSignalGpuEventPtr();
            dla_wait_cpu_event_obj_p_ = tmp_sync_obj_p->getDlaWaitCpuEventObjPtr();
            dla_signal_cpu_event_context_p_ = tmp_sync_obj_p->getDlaSignalCpuEventContextPtr();
            cuda_signal_dla_sema_p_ = tmp_sync_obj_p->getCudaSignalDlaSemaPtr();
            cuda_wait_dla_sema_p_ = tmp_sync_obj_p->getCudaWaitDlaSemaPtr();
            cuda_signal_dla_sema_param_p_ = tmp_sync_obj_p->getCudaSignalDlaSemaParamPtr();
            cuda_wait_dla_sema_param_p_ = tmp_sync_obj_p->getCudaWaitDlaSemaParamPtr();

            dla_sync_cpu_task_.moduleHandle = module_handle_;
            dla_sync_cpu_task_.outputTensor = dla_outputs_p_vec_.data(); //should a ** -- theoretically is an array of buffer
            dla_sync_cpu_task_.numOutputTensors = outputs_num_;
            dla_sync_cpu_task_.numInputTensors = inputs_num_;
            dla_sync_cpu_task_.inputTensor = dla_inputs_p_vec_.data(); //should a ** -- theoretically is an array of buffer
            dla_sync_cpu_task_.waitEvents = dla_wait_cpu_events_p_;
            dla_sync_cpu_task_.signalEvents = dla_signal_cpu_events_p_;

            dla_sync_gpu_task_.moduleHandle = module_handle_;
            dla_sync_gpu_task_.outputTensor = dla_outputs_p_vec_.data(); //should a ** -- theoretically is an array of buffer
            dla_sync_gpu_task_.numOutputTensors = outputs_num_;
            dla_sync_gpu_task_.numInputTensors = inputs_num_;
            dla_sync_gpu_task_.inputTensor = dla_inputs_p_vec_.data(); //should a ** -- theoretically is an array of buffer
            dla_sync_gpu_task_.waitEvents = dla_wait_cuda_events_p_;
            dla_sync_gpu_task_.signalEvents = dla_signal_cuda_events_p_;
#endif
        }
        else{
            runtime_ = std::unique_ptr<nvinfer1::IRuntime>(nvinfer1::createInferRuntime(logger_));
            engine_ = std::shared_ptr<nvinfer1::ICudaEngine>(runtime_->deserializeCudaEngine(engine_file_data_.data(), engine_file_data_.size()));
            if (engine_ == nullptr){
                std::cout<< "eng: " << engine_name_ <<" failed to deserialize nv tensorRT engine"<<std::endl;
                return false;
            }
            context_ = std::shared_ptr<nvinfer1::IExecutionContext>(engine_->createExecutionContext());
            if (context_ == nullptr){
                std::cout<< "eng: " << engine_name_ <<" failed to create nv TensorRT context"<<std::endl;
                return false;
            }
            engine_file_data_.resize(0);

            if (inputs_num_ != input_buffers_.size()){
                std::cout<< "eng: " << engine_name_ <<" has "<<inputs_num_<<" input tensors but get "<<input_buffers_.size()<<std::endl;
                return false;
            }
            if (outputs_num_ != output_buffers_.size()){
                std::cout<< "eng: " << engine_name_ <<" has "<<outputs_num_<<" output tensors but get "<<output_buffers_.size()<<std::endl;
                return false;
            }
            if (inputs_num_ + outputs_num_ != engine_->getNbIOTensors()){
                std::cout<< "eng: " << engine_name_ <<" inconsist for IO tensor number "<<std::endl;
                return false;
            }
            for (int i = 0; i < inputs_num_; i++) context_->setInputTensorAddress(engine_->getIOTensorName(i),
                                                                getBufferPtr(engine_->getIOTensorName(i))->getDataPtr<void>());
#ifdef x86_64
            for (int i = 0; i < outputs_num_; i++) context_->setOutputTensorAddress(engine_->getIOTensorName(i + inputs_num_), 
                                                                getBufferPtr(engine_->getIOTensorName(i + inputs_num_))->getDataPtr<void>());
#elif defined(JETSON_ORIN)
            for (int i = 0; i < outputs_num_; i++) context_->setTensorAddress(engine_->getIOTensorName(i + inputs_num_), 
                                                                getBufferPtr(engine_->getIOTensorName(i + inputs_num_))->getDataPtr<void>());
#else
            std::cout<<"unsupported platform for current"<<std::endl;
            return -2;
#endif        
            if (use_cuda_graph_){
                std::cout<<"graph init setting"<<std::endl;
                graph_input_fixed_p_vec_.resize(inputs_num_, nullptr);
                graph_output_fixed_p_vec_.resize(outputs_num_, nullptr);
                graph_input_name_vec_.resize(inputs_num_);
                graph_output_name_vec_.resize(outputs_num_);
                for (int i = 0; i < inputs_num_; i++){
                    graph_input_fixed_p_vec_[i] = getBufferPtr(engine_->getIOTensorName(i))->getDataPtr<void>();
                    graph_input_name_vec_[i] = engine_->getIOTensorName(i);
                } 
                for (int i = 0; i < outputs_num_; i++){
                    graph_output_fixed_p_vec_[i] = getBufferPtr(engine_->getIOTensorName(i + inputs_num_))->getDataPtr<void>();
                    graph_output_name_vec_[i] = engine_->getIOTensorName(i + inputs_num_);
                }
                std::cout<<"graph init start"<<std::endl;
                context_->enqueueV3(stream_);
                cudaStreamSynchronize(stream_);
                std::cout<<cudaStreamBeginCapture(stream_, cudaStreamCaptureModeGlobal)<<std::endl;
                context_->enqueueV3(stream_);
                std::cout<<cudaStreamEndCapture(stream_, &graph_)<<std::endl;
#ifdef JETSON_ORIN
                std::cout<<cudaGraphInstantiate(&graph_infer_, graph_, nullptr, nullptr, 0)<<std::endl;
#else
                std::cout<<cudaGraphInstantiate(&graph_infer_, graph_, 0)<<std::endl;
#endif
                cudaStreamSynchronize(stream_);
                std::cout<<"graph init done"<<std::endl;
            }
        }
        return true;
    }
    bool TRTEngine::inferEngineModel(){
        if (on_dla_){
#ifdef JETSON_ORIN
            if (sync_type_ == 1){
                dla_ret_ = cudlaSubmitTask(dev_handle_, &dla_sync_cpu_task_, 1, NULL, 0);
                sci_ret_ = NvSciSyncObjSignal(*dla_wait_cpu_event_obj_p_);
                sci_ret_ = NvSciSyncFenceWait(reinterpret_cast<NvSciSyncFence*>(dla_signal_cpu_events_p_->eofFences[0].fence), *dla_signal_cpu_event_context_p_, -1);
            }
            else{
                cuda_ret_ = cudaSignalExternalSemaphoresAsync(cuda_signal_dla_sema_p_, cuda_signal_dla_sema_param_p_, 1, stream_);
                dla_ret_ = cudlaSubmitTask(dev_handle_, &dla_sync_gpu_task_, 1, NULL, 0);
                cuda_ret_ = cudaWaitExternalSemaphoresAsync(cuda_wait_dla_sema_p_, cuda_wait_dla_sema_param_p_, 1, stream_);
            }
#endif
        }
        else{
            if (use_cuda_graph_) cudaGraphLaunch(graph_infer_, stream_);
            else context_->enqueueV3(stream_);
            cudaStreamSynchronize(stream_);
        }
        return true;
    }
    bool TRTEngine::testModelInferTime(int repeat_times){
        float total_cost = 0.0f;
        cudaEvent_t start, end;
        cudaEventCreate(&start);
        cudaEventCreate(&end);
        for (int i = 0; i < repeat_times; i++){
            cudaEventRecord(start, stream_);
            if (on_dla_){
#ifdef JETSON_ORIN
                if (sync_type_ == 1){
                    dla_ret_ = cudlaSubmitTask(dev_handle_, &dla_sync_cpu_task_, 1, NULL, 0);
                    sci_ret_ = NvSciSyncObjSignal(*dla_wait_cpu_event_obj_p_);
                    sci_ret_ = NvSciSyncFenceWait(reinterpret_cast<NvSciSyncFence*>(dla_signal_cpu_events_p_->eofFences[0].fence), *dla_signal_cpu_event_context_p_, -1);
                }
                else{
                    cuda_ret_ = cudaSignalExternalSemaphoresAsync(cuda_signal_dla_sema_p_, cuda_signal_dla_sema_param_p_, 1, stream_);
                    dla_ret_ = cudlaSubmitTask(dev_handle_, &dla_sync_gpu_task_, 1, NULL, 0);
                    cuda_ret_ = cudaWaitExternalSemaphoresAsync(cuda_wait_dla_sema_p_, cuda_wait_dla_sema_param_p_, 1, stream_);
                }
#endif
            }
            else{
                if (use_cuda_graph_) cudaGraphLaunch(graph_infer_, stream_);
                else context_->enqueueV3(stream_);
            }
            cudaEventRecord(end, stream_);
            cudaEventSynchronize(end);
            float cost;
            cudaEventElapsedTime(&cost, start, end);
            total_cost += cost;
        }
        cudaStreamSynchronize(stream_);
        std::cout<<"trt model test time ave in "<<repeat_times<<" rounds: "<<total_cost / static_cast<float>(repeat_times)<<"ms"<<std::endl;
        return true;
    }

    bool TRTEngine::setInputsShape(std::vector<std::vector<int64_t>> &inputs_shape){
        inputs_shape_ = inputs_shape;
        return true;
    }
    bool TRTEngine::setOutputsShape(std::vector<std::vector<int64_t>> &outputs_shape){
        outputs_shape_ = outputs_shape;
        return true;
    }

    bool TRTEngine::loadEngineModel(const std::string &model_file_path, 
                                    const bool &on_dla, const char &sync_type, const int &device_id, const bool &use_cuda_graph){
        on_dla_ = on_dla;
        sync_type_ = sync_type;
        device_id_ = device_id;
        use_cuda_graph_ = use_cuda_graph;
#ifndef JETSON_ORIN
        if (on_dla_){
            std::cout<<"unsupport dla in this platform"<<std::endl;
            return -3;
        }
#endif
        if (on_dla_ && use_cuda_graph) std::cout<<"engine on dla not support cuda-graph mode"<<std::endl;
        if (on_dla_ && sync_type_ == 0) std::cout<<"engine on gpu only support sync type 0(gpu-cpu)"<<std::endl;
        if (!on_dla_ && (sync_type_ == 1 || sync_type_ == 2)) std::cout<<"engine on dla only support sync type 1(dla-cpu) or 2(dla-gpu)"<<std::endl;
        std::ifstream eng_file(model_file_path, std::ios::binary);
        if (!eng_file.good()){
            std::cout<< "eng: " << engine_name_ <<" engine file path wrong: "<<model_file_path<<" no such file"<<std::endl;
            return false;
        }
        eng_file.seekg(0, eng_file.end);
        int64_t end_pos = eng_file.tellg();
        eng_file.seekg(0, eng_file.beg);
        int64_t beg_pos = eng_file.tellg();
        int64_t file_length = end_pos - beg_pos;
        engine_file_data_.resize(file_length);
        eng_file.read(engine_file_data_.data(), file_length);
        eng_file.close();
        return true;
    }
    bool TRTEngine::waitSignalAndLaunchEngine(){
        if (on_dla_){
#ifdef JETSON_ORIN
            if (sync_type_ == 1){
                dla_ret_ = cudlaSubmitTask(dev_handle_, &dla_sync_cpu_task_, 1, NULL, 0);
                sci_ret_ = NvSciSyncObjSignal(*dla_wait_cpu_event_obj_p_);
            }
            else{
                cuda_ret_ = cudaSignalExternalSemaphoresAsync(cuda_signal_dla_sema_p_, cuda_signal_dla_sema_param_p_, 1, stream_);
                dla_ret_ = cudlaSubmitTask(dev_handle_, &dla_sync_gpu_task_, 1, NULL, 0);
            }
#endif
        }
        else{
            if (use_cuda_graph_) cudaGraphLaunch(graph_infer_, stream_);
            else context_->enqueueV3(stream_);
        }
        return true;
    }
    bool TRTEngine::syncAfterLaunchEngine(){
        if (on_dla_){
#ifdef JETSON_ORIN
            if (sync_type_ == 1){
                sci_ret_ = NvSciSyncFenceWait(reinterpret_cast<NvSciSyncFence*>(dla_signal_cpu_events_p_->eofFences[0].fence), 
                                            *dla_signal_cpu_event_context_p_, -1);
            }
            else{
                cuda_ret_ = cudaWaitExternalSemaphoresAsync(cuda_wait_dla_sema_p_, cuda_wait_dla_sema_param_p_, 1, stream_);
            }
#endif
        }
        else{
            cudaStreamSynchronize(stream_);
        }
        return true;
    }

    bool TRTEngine::updateIOMemPtrDLAEngine(const std::string &name, void* mem_p){
#ifdef JETSON_ORIN
        //谨慎使用，仅会改变dla-task执行部分的dla mem p，其它的相关p均未改变，需要注意对应关系
        for (int i = 0; i < inputs_num_; i++){
            if (dla_inputs_name_vec_[i] == name){
                dla_inputs_p_vec_[i] = reinterpret_cast<uint64_t*>(mem_p);
                return true;
            }
        }
        for (int i = 0; i < outputs_num_; i++){
            if (dla_outputs_name_vec_[i] == name){
                dla_outputs_p_vec_[i] = reinterpret_cast<uint64_t*>(mem_p);
                return true;
            }
        }
#endif
        return true;
    }

    bool TRTEngine::updateIOBufferCudaEngine(std::vector<memory::BaseBufferPtr> &input_buffers, std::vector<memory::BaseBufferPtr> &output_buffers){
        if (use_cuda_graph_){
            std::cout<<"cuda-graph mode use fixed io mem addr, please use memcpy instead"<<std::endl;
            return false;
        }
        bool ret = true;
        for (int i = 0; i < inputs_num_; i++){
            if (input_buffers[i]->getBufferName() != input_buffers_[i]->getBufferName()){
                ret = false;
                break;
            }
        }
        for (int i = 0; i < outputs_num_; i++){
            if (output_buffers[i]->getBufferName() != output_buffers_[i]->getBufferName()){
                ret = false;
                break;
            }
        }
        if (ret){
            input_buffers_ = input_buffers;
            output_buffers_ = output_buffers;
            for (int i = 0; i < inputs_num_; i++){
                context_->setTensorAddress(input_buffers[i]->getBufferName().c_str(), input_buffers[i]->getDataPtr<void>());
                refreshIOBufferTable(input_buffers[i]->getBufferName(), input_buffers[i]);
            }
            for (int i = 0; i < outputs_num_; i++){
                context_->setTensorAddress(output_buffers[i]->getBufferName().c_str(), output_buffers[i]->getDataPtr<void>());
                refreshIOBufferTable(output_buffers[i]->getBufferName(), output_buffers[i]);
            }
        } 
        else std::cout<<"invalid updating buffers, check whether correct"<<std::endl;
        return ret;
    }

    bool TRTEngine::registed_ = [](){
        std::string type_name = "TRTEngine";
        EngineFactory::registEngineCreator(type_name, 
                                            [](){return BaseEnginePtr(std::make_shared<TRTEngine>());});
        return true;
    }();

}