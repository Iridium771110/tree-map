//目前按照固定BNLD的长度，需要考虑各方向（NLD）上的灵活度，或许部分已经存在（？，to do)
//从pos-embed的输出开始，到layernorm的输出结束，包含了整个attn的过程，注意分叉路问题，需要网络文件配合
//pos-embed输出应为BLND，layernorm输出应为BLC，一般情况下C=ND
//目前仅支持half类型输入输出
#ifndef TRT_ATTENTIONBLOCK_PLUGIN_H
#define TRT_ATTENTIONBLOCK_PLUGIN_H

#include "plugin.h"
#include <cuda_runtime_api.h>
#include <stdint.h>
#include <vector>
#include <cuda.h>
#include "cuda_fp16.h"

#include "checkMacrosPlugin.h"

#include "NvInfer.h"
#include "NvInferPlugin.h"

#include <unordered_map>
//从pos_embed之后的结果开始
//输入 pos_embed=BLND, mat_weight=(3*ND)*ND, mat_bias=3*ND, theoretically pos_embed can be BLC, mat_weight can be (3*ND)*C
// out_weight = dst_channel*ND, out_bias = dst_channel
// norm_bias = C, norm_scale = C
//最终输出 data = BLC
// pos -> mma,trans = qkv -> attn = mha -> mma,trans,add pos,norm = res
//目前仅支持L400N4D128
//通用性需要重新考虑
//其它特定格式需要调整各参数，应按照标记快速重写
//注意内部有两个参数，它们的来源是dk放缩，在一般的版本中应当直接一层根号，等于这里设置其中一个为平方，另一个为1。二者的结果理论上是等价的，但是对积的和的放缩效应（体现在误差和溢出上）可能是不同的

namespace custom_plugin_kernel{
    int attnBlockPosEmbed2NormResExecutor(const half* pos_embed_p, const half* mat_weight_p, const half* mat_bias_p, 
                                        const half* out_weight_p, const half* out_bias_p,
                                        const half* norm_sclale_p, const half* norm_bias_p,
                                        half* res_data_p,
                                        half* intern_q_p, half* intern_k_p, half* intern_v_p, half* intern_mha_p,
                                        int batch, int num_head, int seq_len, int head_dim, int dst_channel, float eps, cudaStream_t stream);
}

namespace nvinfer1
{
namespace plugin
{

class AttentionBlockPlugin : public IPluginV2DynamicExt
{
public:
    AttentionBlockPlugin() = delete;
    AttentionBlockPlugin(std::string const& name, DataType data_type, Weights qkv_weight, Weights qkv_bias,
                        Weights out_weight, Weights out_bias,
                        Weights norm_scale, Weights norm_bias,
                        int batch, int seq_len, int num_head, int head_dim, int channel_input, int channel_output, float eps);//正常malloc使用
    AttentionBlockPlugin(DataType data_type, Weights qkv_weight, Weights qkv_bias,
                        Weights out_weight, Weights out_bias,
                        Weights norm_scale, Weights norm_bias,
                        void* qkv_weight_p, void* qkv_bias_p, void* out_weight_p, void* out_bias_p, void* norm_scale_p, void* norm_bias_p,
                        int batch, int seq_len, int num_head, int head_dim, int channel_input, int channel_output, float eps, bool initialed); // clone使用，应当避免新的malloc
    AttentionBlockPlugin(std::string const& name, void const* buffer, size_t length);//正常malloc使用
    ~AttentionBlockPlugin() override;

    // Method inherited from IPluginV2
    char const* getPluginType() const noexcept override;
    char const* getPluginVersion() const noexcept override;
    int32_t getNbOutputs() const noexcept override;
    int32_t initialize() noexcept override;
    void terminate() noexcept override;
    size_t getSerializationSize() const noexcept override;
    void serialize(void* buffer) const noexcept override;
    void destroy() noexcept override;
    void setPluginNamespace(char const* pluginNamespace) noexcept override;
    char const* getPluginNamespace() const noexcept override;

    // Method inherited from IPluginV2Ext
    DataType getOutputDataType(int32_t index, DataType const* inputTypes, int32_t nbInputs) const noexcept override;
    using IPluginV2Ext::getOutputDimensions;
    using IPluginV2Ext::configurePlugin;
    using IPluginV2Ext::getWorkspaceSize;
    using IPluginV2Ext::enqueue;
    
    // Method inherited from IPluginV2DynamicExt
    IPluginV2DynamicExt* clone() const noexcept override;
    DimsExprs getOutputDimensions(
        int32_t outputIndex, DimsExprs const* inputs, int32_t nbInputs, IExprBuilder& exprBuilder) noexcept override;
    bool supportsFormatCombination(
        int32_t pos, PluginTensorDesc const* inOut, int32_t nbInputs, int32_t nbOutputs) noexcept override;
    void configurePlugin(DynamicPluginTensorDesc const* in, int32_t nbInputs, DynamicPluginTensorDesc const* out,
        int32_t nbOutputs) noexcept override;
    size_t getWorkspaceSize(PluginTensorDesc const* inputs, int32_t nbInputs, PluginTensorDesc const* outputs,
        int32_t nbOutputs) const noexcept override;
    int32_t enqueue(PluginTensorDesc const* inputDesc, PluginTensorDesc const* outputDesc, void const* const* inputs,
        void* const* outputs, void* workspace, cudaStream_t stream) noexcept override;

    //self defined
    bool setEpsFactor(float eps);
    bool setName(std::string name);
private:
    std::string name_;
    std::string nameSpace_;
    DataType data_type_;
    Weights qkv_weight_;
    Weights qkv_bias_;
    Weights out_weight_;
    Weights out_bias_;
    Weights norm_scale_;
    Weights norm_bias_;
    void* qkv_weight_p_ = nullptr;
    void* qkv_bias_p_ = nullptr;
    void* out_weight_p_ = nullptr;
    void* out_bias_p_ = nullptr;
    void* norm_scale_p_ = nullptr;
    void* norm_bias_p_ = nullptr;
    half* intern_q_p_ = nullptr; 
    half* intern_k_p_ = nullptr; 
    half* intern_v_p_ = nullptr; 
    half* intern_mha_p_ = nullptr;
    float eps_ = 1e-5f;
    int batch_;
    int seq_len_;
    int num_head_;
    int head_dim_;
    int channel_input_;
    int channel_output_;
    bool initialed_ = false;

    std::vector<char> qkv_weight_data_zone_;
    std::vector<char> qkv_bias_data_zone_;
    std::vector<char> out_weight_data_zone_;
    std::vector<char> out_bias_data_zone_;
    std::vector<char> norm_scale_data_zone_;
    std::vector<char> norm_bias_data_zone_;

    // static std::unordered_map<DataType, std::string> trt_type_string_table_;
};

class AttentionBlockPluginCreator : public nvinfer1::pluginInternal::BaseCreator
{
public:
    AttentionBlockPluginCreator();
    ~AttentionBlockPluginCreator();
    char const* getPluginName() const noexcept override;
    char const* getPluginVersion() const noexcept override;
    PluginFieldCollection const* getFieldNames() noexcept override;
    IPluginV2* createPlugin(char const* name, PluginFieldCollection const* fc) noexcept override;
    IPluginV2* deserializePlugin(char const* name, void const* serialData, size_t serialLength) noexcept override;

private:
    //这两似乎没啥卵用
    static PluginFieldCollection mFC_;
    static std::vector<PluginField> mPluginAttributes_;
    static std::unordered_map<int32_t, DataType> nv_type_table_;
};

}}


#endif