#include "attentionBlockPlugins.h"
//从pos_embed之后的结果开始
//输入 pos_embed=BLND, mat_weight=(3*ND)*ND, mat_bias=3*ND, theoretically pos_embed can be BLC, mat_weight can be (3*ND)*C
//最终输出 data = BLC

using namespace nvinfer1;
using namespace plugin;

using nvinfer1::plugin::AttentionBlockPlugin;
using nvinfer1::plugin::AttentionBlockPluginCreator;

namespace
{
char const* kATTENTION_BLOCK_PLUGIN_NAME{"AttentionBlockPlugin_custom"};
char const* kATTENTION_BLOCK_PLUGIN_VERSION{"1"};
size_t constexpr kATTENTION_BLOCK_SERIALIZATION_SIZE{sizeof(DataType) + 6*sizeof(Weights) + 6*sizeof(int) + sizeof(float)};
} // namespace

AttentionBlockPlugin::AttentionBlockPlugin(std::string const& name, DataType data_type, Weights qkv_weight, Weights qkv_bias,
                        Weights out_weight, Weights out_bias,
                        Weights norm_scale, Weights norm_bias,
                        int batch, int seq_len, int num_head, int head_dim, int channel_input, int channel_output, float eps)
    : name_(name)
    , data_type_(data_type)
    , qkv_weight_(qkv_weight)
    , qkv_bias_(qkv_bias)
    , out_weight_(out_weight)
    , out_bias_(out_bias)
    , norm_scale_(norm_scale)
    , norm_bias_(norm_bias)
    , batch_(batch)
    , seq_len_(seq_len)
    , num_head_(num_head)
    , head_dim_(head_dim)
    , channel_input_(channel_input)
    , channel_output_(channel_output)
    , eps_(eps)
{
    int elements_byte_len = 1;
    if (data_type_ == DataType::kFLOAT) elements_byte_len *= sizeof(float);
    else if (data_type_ == DataType::kHALF) elements_byte_len *= sizeof(half);
    else std::cout << "in AttentionBlock " << name << " data type unsupported, use kHALF or kFLOAT instead" << std::endl;
    qkv_weight_data_zone_.resize(elements_byte_len*qkv_weight_.count);
    qkv_bias_data_zone_.resize(elements_byte_len*qkv_bias_.count);
    out_weight_data_zone_.resize(elements_byte_len*out_weight_.count);
    out_bias_data_zone_.resize(elements_byte_len*out_bias_.count);
    norm_scale_data_zone_.resize(elements_byte_len*norm_scale_.count);
    norm_bias_data_zone_.resize(elements_byte_len*norm_bias_.count);
    std::memcpy(qkv_weight_data_zone_.data(), qkv_weight_.values, elements_byte_len*qkv_weight_.count);
    std::memcpy(qkv_bias_data_zone_.data(), qkv_bias_.values, elements_byte_len*qkv_bias_.count);
    std::memcpy(out_weight_data_zone_.data(), out_weight_.values, elements_byte_len*out_weight_.count);
    std::memcpy(out_bias_data_zone_.data(), out_bias_.values, elements_byte_len*out_bias_.count);
    std::memcpy(norm_scale_data_zone_.data(), norm_scale_.values, elements_byte_len*norm_scale_.count);
    std::memcpy(norm_bias_data_zone_.data(), norm_bias_.values, elements_byte_len*norm_bias_.count);
    qkv_weight_.values = reinterpret_cast<const void*>(qkv_weight_data_zone_.data());
    qkv_bias_.values = reinterpret_cast<const void*>(qkv_bias_data_zone_.data());
    out_weight_.values = reinterpret_cast<const void*>(out_weight_data_zone_.data());
    out_bias_.values = reinterpret_cast<const void*>(out_bias_data_zone_.data());
    norm_scale_.values = reinterpret_cast<const void*>(norm_scale_data_zone_.data());
    norm_bias_.values = reinterpret_cast<const void*>(norm_bias_data_zone_.data());
}
AttentionBlockPlugin::AttentionBlockPlugin(DataType data_type, Weights qkv_weight, Weights qkv_bias,
                        Weights out_weight, Weights out_bias,
                        Weights norm_scale, Weights norm_bias,
                        void* qkv_weight_p, void* qkv_bias_p, void* out_weight_p, void* out_bias_p, void* norm_scale_p, void* norm_bias_p,
                        int batch, int seq_len, int num_head, int head_dim, int channel_input, int channel_output, float eps, bool initialed)
    : data_type_(data_type)
    , qkv_weight_(qkv_weight)
    , qkv_bias_(qkv_bias)
    , out_weight_(out_weight)
    , out_bias_(out_bias)
    , norm_scale_(norm_scale)
    , norm_bias_(norm_bias)
    , qkv_weight_p_(qkv_weight_p)
    , qkv_bias_p_(qkv_bias_p)
    , out_weight_p_(out_weight_p)
    , out_bias_p_(out_bias_p)
    , norm_scale_p_(norm_scale_p)
    , norm_bias_p_(norm_bias_p)
    , batch_(batch)
    , seq_len_(seq_len)
    , num_head_(num_head)
    , head_dim_(head_dim)
    , channel_input_(channel_input)
    , channel_output_(channel_output)
    , eps_(eps)
    , initialed_(initialed)
{
}
AttentionBlockPlugin::AttentionBlockPlugin(std::string const& name, void const* buffer, size_t length)
    : name_(name)
{
    PLUGIN_VALIDATE(buffer != nullptr);
    
    char const* d = static_cast<char const*>(buffer);
    char const* a = d;
    data_type_ = read<DataType>(d);
    qkv_weight_ = read<Weights>(d);
    qkv_bias_ = read<Weights>(d);
    out_weight_ = read<Weights>(d);
    out_bias_ = read<Weights>(d);
    norm_scale_ = read<Weights>(d);
    norm_bias_ = read<Weights>(d);
    batch_ = read<int>(d);
    seq_len_ = read<int>(d);
    num_head_ = read<int>(d);
    head_dim_ = read<int>(d);
    channel_input_ = read<int>(d);
    channel_output_ = read<int>(d);
    eps_ = read<float>(d);

    int elements_byte_len = 1;
    if (data_type_ == DataType::kFLOAT) elements_byte_len *= sizeof(float);
    else if (data_type_ == DataType::kHALF) elements_byte_len *= sizeof(half);
    else std::cout << "in AttentionBlock " << name << " data type unsupported, use kHALF or kFLOAT instead" << std::endl;
    qkv_weight_data_zone_.resize(elements_byte_len*qkv_weight_.count);
    qkv_bias_data_zone_.resize(elements_byte_len*qkv_bias_.count);
    out_weight_data_zone_.resize(elements_byte_len*out_weight_.count);
    out_bias_data_zone_.resize(elements_byte_len*out_bias_.count);
    norm_scale_data_zone_.resize(elements_byte_len*norm_scale_.count);
    norm_bias_data_zone_.resize(elements_byte_len*norm_bias_.count);
    std::memcpy(qkv_weight_data_zone_.data(), d, elements_byte_len*qkv_weight_.count);
    d += elements_byte_len*qkv_weight_.count;
    std::memcpy(qkv_bias_data_zone_.data(), d, elements_byte_len*qkv_bias_.count);
    d += elements_byte_len*qkv_bias_.count;
    std::memcpy(out_weight_data_zone_.data(), d, elements_byte_len*out_weight_.count);
    d += elements_byte_len*out_weight_.count;
    std::memcpy(out_bias_data_zone_.data(), d, elements_byte_len*out_bias_.count);
    d += elements_byte_len*out_bias_.count;
    std::memcpy(norm_scale_data_zone_.data(), d, elements_byte_len*norm_scale_.count);
    d += elements_byte_len*norm_scale_.count;
    std::memcpy(norm_bias_data_zone_.data(), d, elements_byte_len*norm_bias_.count);
    d += elements_byte_len*norm_bias_.count;
    qkv_weight_.values = reinterpret_cast<const void*>(qkv_weight_data_zone_.data());
    qkv_bias_.values = reinterpret_cast<const void*>(qkv_bias_data_zone_.data());
    out_weight_.values = reinterpret_cast<const void*>(out_weight_data_zone_.data());
    out_bias_.values = reinterpret_cast<const void*>(out_bias_data_zone_.data());
    norm_scale_.values = reinterpret_cast<const void*>(norm_scale_data_zone_.data());
    norm_bias_.values = reinterpret_cast<const void*>(norm_bias_data_zone_.data());
    
    PLUGIN_VALIDATE(length == kATTENTION_BLOCK_SERIALIZATION_SIZE + elements_byte_len*(qkv_weight_.count + qkv_bias_.count
                                                                                        + out_weight_.count + out_bias_.count
                                                                                        + norm_scale_.count + norm_bias_.count));
    PLUGIN_VALIDATE(d == a + length);
}
AttentionBlockPlugin::~AttentionBlockPlugin(){
    terminate();
}

IPluginV2DynamicExt* AttentionBlockPlugin::clone() const noexcept{
    //将这个plugin对象克隆一份给TensorRT的builder、network或者engine，注意如果涉及指针空间可能需要新的构造函数等
    try{
        cudaDeviceSynchronize();
        auto plugin = new AttentionBlockPlugin(this->data_type_, 
                                                this->qkv_weight_, this->qkv_bias_, this->out_weight_, this->out_bias_,
                                                this->norm_scale_, this->norm_bias_,
                                                this->qkv_weight_p_, this->qkv_bias_p_, this->out_weight_p_, this->out_bias_p_,
                                                this->norm_scale_p_, this->norm_bias_p_,
                                                this->batch_, this->seq_len_, this->num_head_, this->head_dim_, 
                                                this->channel_input_, this->channel_output_,
                                                this->eps_, false);
        plugin->setPluginNamespace(nameSpace_.c_str());
        return plugin;
    }
    catch (std::exception const& e){
        caughtError(e);
    }
    return nullptr;
}
void AttentionBlockPlugin::serialize(void* buffer) const noexcept{
    PLUGIN_ASSERT(buffer != nullptr);
    char* d = static_cast<char*>(buffer);
    char* a = d;
    write<DataType>(d, data_type_);
    write<Weights>(d, qkv_weight_);
    write<Weights>(d, qkv_bias_);
    write<Weights>(d, out_weight_);
    write<Weights>(d, out_bias_);
    write<Weights>(d, norm_scale_);
    write<Weights>(d, norm_bias_);
    write<int>(d, batch_);
    write<int>(d, seq_len_);
    write<int>(d, num_head_);
    write<int>(d, head_dim_);
    write<int>(d, channel_input_);
    write<int>(d, channel_output_);
    write<float>(d, eps_);
    int elements_byte_len = 1;
    if (data_type_ == DataType::kFLOAT) elements_byte_len *= sizeof(float);
    else if (data_type_ == DataType::kHALF) elements_byte_len *= sizeof(half);
    else std::cout << "in AttentionBlock " << name_ << " data type unsupported, use kHALF or kFLOAT instead" << std::endl;
    std::memcpy(d, qkv_weight_.values, elements_byte_len*qkv_weight_.count);
    d += elements_byte_len*qkv_weight_.count;
    std::memcpy(d, qkv_bias_.values, elements_byte_len*qkv_bias_.count);
    d += elements_byte_len*qkv_bias_.count;
    std::memcpy(d, out_weight_.values, elements_byte_len*out_weight_.count);
    d += elements_byte_len*out_weight_.count;
    std::memcpy(d, out_bias_.values, elements_byte_len*out_bias_.count);
    d += elements_byte_len*out_bias_.count;
    std::memcpy(d, norm_scale_.values, elements_byte_len*norm_scale_.count);
    d += elements_byte_len*norm_scale_.count;
    std::memcpy(d, norm_bias_.values, elements_byte_len*norm_bias_.count);
    d += elements_byte_len*norm_bias_.count;

    PLUGIN_ASSERT(d == a + getSerializationSize());
}
void AttentionBlockPlugin::configurePlugin(
    DynamicPluginTensorDesc const* in, int32_t nbInputs, DynamicPluginTensorDesc const* out, int32_t nbOutputs) noexcept{
        //本处配置可以部分用于运行时检查
    if (nbInputs != 1 || nbOutputs != 1){
        std::cout << "AttentionBlockPlugin aquire 1 input & 1 output, but get " << nbInputs << "input and " << nbOutputs << " output" << std::endl;
    }
    if (in->desc.format != nvinfer1::TensorFormat::kLINEAR){ //klinear 应当注意各维度实际意义
        std::cout<<"invalid input format "<<std::endl;
    }
}
int32_t AttentionBlockPlugin::initialize() noexcept{
    //初始化函数，在这个插件准备开始run之前执行。
    // 主要初始化一些提前开辟空间的参数，一般是一些cuda操作需要的参数(例如conv操作需要执行卷积操作，我们就需要提前开辟weight和bias的显存)
    int elements_byte_len = 1;
    // if (qkv_weight_.type == DataType::kFLOAT && qkv_bias_.type == DataType::kFLOAT 
    //     && out_weight_.type == DataType::kFLOAT && out_bias_.type == DataType::kFLOAT 
    //     && norm_scale_.type == DataType::kFLOAT && norm_bias_.type == DataType::kFLOAT 
    //     && data_type_ == DataType::kFLOAT){
    //     elements_byte_len *= sizeof(float);
    // }
    // else if (qkv_weight_.type == DataType::kHALF && qkv_bias_.type == DataType::kHALF 
    //         && out_weight_.type == DataType::kHALF && out_bias_.type == DataType::kHALF 
    //         && norm_scale_.type == DataType::kHALF && norm_bias_.type == DataType::kHALF 
    //         && data_type_ == DataType::kHALF){
    //     elements_byte_len *= sizeof(half);
    // }
    // else{
    //     std::cout << "AttentionBlock " << name_ << " in&out/scale/bias type should be float or half" << std::endl;
    // }
    if (qkv_weight_.type == DataType::kHALF && qkv_bias_.type == DataType::kHALF 
        && out_weight_.type == DataType::kHALF && out_bias_.type == DataType::kHALF 
        && norm_scale_.type == DataType::kHALF && norm_bias_.type == DataType::kHALF){
        elements_byte_len *= sizeof(half);
    }
    else{
        std::cout << "AttentionBlock " << name_ << " in&out/scale/bias type should be half" << std::endl;
    }
    std::cout << "AttentionBlock " << name_ << " using half precision instead of float" << std::endl;

    if (norm_scale_.count != channel_output_ || norm_bias_.count != channel_output_){
        std::cout << "AttentionBlock " << name_ << " norm scale/bias length should be " << channel_output_ << std::endl;
    }
    if (qkv_weight_.count != 3*num_head_*head_dim_*channel_input_ || qkv_bias_.count != 3*num_head_*head_dim_){
        std::cout << "AttentionBlock " << name_ << " qkv weight/bias shape should be " << 3 << 'x' << num_head_ << 'x' << head_dim_ 
                << 'x' << channel_input_ << '&' << 3 << 'x' << num_head_ << 'x' << head_dim_ << std::endl;
    }
    if (out_weight_.count != channel_output_*num_head_*head_dim_ || out_bias_.count != channel_output_){
        std::cout << "AttentionBlock " << name_ << " out weight/bias length should be " << channel_output_ << 'x' << num_head_ 
                << 'x' << head_dim_ << '&' << channel_output_ << std::endl;
    }
    
    cudaMalloc(reinterpret_cast<void**>(&qkv_weight_p_), elements_byte_len*qkv_weight_.count);
    cudaMalloc(reinterpret_cast<void**>(&qkv_bias_p_), elements_byte_len*qkv_bias_.count);
    cudaMalloc(reinterpret_cast<void**>(&out_weight_p_), elements_byte_len*out_weight_.count);
    cudaMalloc(reinterpret_cast<void**>(&out_bias_p_), elements_byte_len*out_bias_.count);
    cudaMalloc(reinterpret_cast<void**>(&norm_scale_p_), elements_byte_len*norm_scale_.count);
    cudaMalloc(reinterpret_cast<void**>(&norm_bias_p_), elements_byte_len*norm_bias_.count);
    std::vector<half> tmp_qkv_weight(qkv_weight_.count);
    std::vector<half> tmp_qkv_bias(qkv_bias_.count);
    std::vector<half> tmp_out_weight(out_weight_.count);
    std::vector<half> tmp_out_bias(out_bias_.count);
    std::vector<half> tmp_norm_scale(norm_scale_.count);
    std::vector<half> tmp_norm_bias(norm_bias_.count);
    for (int i = 0; i < qkv_weight_.count; i++) tmp_qkv_weight[i] = static_cast<half>(reinterpret_cast<const float*>(qkv_weight_.values)[i]);
    for (int i = 0; i < qkv_bias_.count; i++) tmp_qkv_bias[i] = static_cast<half>(reinterpret_cast<const float*>(qkv_bias_.values)[i]);
    for (int i = 0; i < out_weight_.count; i++) tmp_out_weight[i] = static_cast<half>(reinterpret_cast<const float*>(out_weight_.values)[i]);
    for (int i = 0; i < out_bias_.count; i++) tmp_out_bias[i] = static_cast<half>(reinterpret_cast<const float*>(out_bias_.values)[i]);
    for (int i = 0; i < norm_scale_.count; i++) tmp_norm_scale[i] = static_cast<half>(reinterpret_cast<const float*>(norm_scale_.values)[i]);
    for (int i = 0; i < norm_bias_.count; i++) tmp_norm_bias[i] = static_cast<half>(reinterpret_cast<const float*>(norm_bias_.values)[i]);
    cudaMemcpy(qkv_weight_p_, tmp_qkv_weight.data(), elements_byte_len*qkv_weight_.count, cudaMemcpyHostToDevice);
    cudaMemcpy(qkv_bias_p_, tmp_qkv_bias.data(), elements_byte_len*qkv_bias_.count, cudaMemcpyHostToDevice);
    cudaMemcpy(out_weight_p_, tmp_out_weight.data(), elements_byte_len*out_weight_.count, cudaMemcpyHostToDevice);
    cudaMemcpy(out_bias_p_, tmp_out_bias.data(), elements_byte_len*out_bias_.count, cudaMemcpyHostToDevice);
    cudaMemcpy(norm_scale_p_, tmp_norm_scale.data(), elements_byte_len*norm_scale_.count, cudaMemcpyHostToDevice);
    cudaMemcpy(norm_bias_p_, tmp_norm_bias.data(), elements_byte_len*norm_bias_.count, cudaMemcpyHostToDevice);

    cudaMalloc(reinterpret_cast<void**>(&intern_q_p_), elements_byte_len*batch_*seq_len_*num_head_*head_dim_);
    cudaMalloc(reinterpret_cast<void**>(&intern_k_p_), elements_byte_len*batch_*seq_len_*num_head_*head_dim_);
    cudaMalloc(reinterpret_cast<void**>(&intern_v_p_), elements_byte_len*batch_*seq_len_*num_head_*head_dim_);
    cudaMalloc(reinterpret_cast<void**>(&intern_mha_p_), elements_byte_len*batch_*seq_len_*num_head_*head_dim_);
    return 0;
}
void AttentionBlockPlugin::terminate() noexcept {
    // 析构函数则需要执行terminate，terminate函数就是释放这个op之前开辟的一些显存空间
    if (!initialed_){
        qkv_weight_p_ = nullptr;
        qkv_bias_p_ = nullptr;
        out_weight_p_ = nullptr;
        out_bias_p_ = nullptr;
        norm_scale_p_ = nullptr;
        norm_bias_p_ = nullptr;
        intern_q_p_ = nullptr;
        intern_k_p_ = nullptr;
        intern_v_p_ = nullptr;
        intern_mha_p_ = nullptr;
        return;
    }
    if (qkv_weight_p_) cudaFree(qkv_weight_p_);
    if (qkv_bias_p_) cudaFree(qkv_bias_p_);
    if (out_weight_p_) cudaFree(out_weight_p_);
    if (out_bias_p_) cudaFree(out_bias_p_);
    if (norm_scale_p_) cudaFree(norm_scale_p_);
    if (norm_bias_p_) cudaFree(norm_bias_p_);
    if (intern_q_p_) cudaFree(intern_q_p_);
    if (intern_k_p_) cudaFree(intern_k_p_);
    if (intern_v_p_) cudaFree(intern_v_p_);
    if (intern_mha_p_) cudaFree(intern_mha_p_);
    qkv_weight_p_ = nullptr;
    qkv_bias_p_ = nullptr;
    out_weight_p_ = nullptr;
    out_bias_p_ = nullptr;
    norm_scale_p_ = nullptr;
    norm_bias_p_ = nullptr;
    intern_q_p_ = nullptr;
    intern_k_p_ = nullptr;
    intern_v_p_ = nullptr;
    intern_mha_p_ = nullptr;
}
void AttentionBlockPlugin::destroy() noexcept{
    delete this;
}
bool AttentionBlockPlugin::supportsFormatCombination(
        int32_t pos, PluginTensorDesc const* inOut, int32_t nbInputs, int32_t nbOutputs) noexcept{
    //TensorRT调用此方法以判断pos索引的输入/输出是否支持inOut[pos].format和inOut[pos].type指定的格式/数据类型。
    //在build engine时的核选择等处中，依此来获得可用的那些进行比较选择
    //也以此可以指定中间内部变量可以选用的格式类型等
    //本处仅有1in-1out
    if (pos < 0 || pos >= 2){
        std::cout << "AttentionBlockPlugin acquire 1 input & 1 output, but get index " << pos << ", which is out of inout range" << std::endl;
        return false;
    }
    const PluginTensorDesc* in = inOut;
    const PluginTensorDesc* out = inOut + nbInputs;
    switch (pos){
        case 0:
        // return (in[0].type == DataType::kFLOAT || in[0].type == DataType::kHALF) 
        return (in[0].type == DataType::kHALF)
                && (in[0].format == nvinfer1::TensorFormat::kLINEAR)
                && ((in[0].dims.nbDims == 4 && in[0].dims.d[0] == batch_ && in[0].dims.d[1] == seq_len_ && in[0].dims.d[2]*in[0].dims.d[3] == channel_input_)
                    ||(in[0].dims.nbDims == 3 && in[0].dims.d[0] == batch_ && in[0].dims.d[1] == seq_len_ && in[0].dims.d[2] == channel_input_));
        case 1:
        // return (out[0].type == DataType::kFLOAT || out[0].type == DataType::kHALF) 
        return (out[0].type == DataType::kHALF)
                && (out[0].format == nvinfer1::TensorFormat::kLINEAR)
                && (out[0].dims.nbDims == 3 && out[0].dims.d[0] == batch_ && out[0].dims.d[1] == seq_len_ && out[0].dims.d[2] == channel_output_);
    }
    return false;
}

int32_t AttentionBlockPlugin::enqueue(PluginTensorDesc const* inputDesc, PluginTensorDesc const* outputDesc, void const* const* inputs,
        void* const* outputs, void* workspace, cudaStream_t stream) noexcept{
    const void* input_p = inputs[0];
    void* output_p = outputs[0];
    Dims input_dim = inputDesc[0].dims;
    Dims output_dim = outputDesc[0].dims;
    int in_channels;
    int out_channels;
    int in_batch;
    int in_seq_len;
    int out_batch;
    int out_seq_len;
    if (input_dim.nbDims == 3){
        in_batch = input_dim.d[0];
        in_seq_len = input_dim.d[1];
        in_channels = input_dim.d[2];
    }
    else if (input_dim.nbDims == 4){
        in_batch = input_dim.d[0];
        in_seq_len = input_dim.d[1];
        in_channels = input_dim.d[2]*input_dim.d[3];
    }
    else{
        std::cout << "AttentionBlock " << name_ << "invalid dimensions of input, except 3(BLC) or 4(BLND) but get " << input_dim.nbDims << std::endl;
        return -2;
    }
    if (output_dim.nbDims == 3){
        out_batch = output_dim.d[0];
        out_seq_len = output_dim.d[1];
        out_channels = output_dim.d[2];
    }
    else if (output_dim.nbDims == 4){
        out_batch = output_dim.d[0];
        out_seq_len = output_dim.d[1];
        out_channels = output_dim.d[2]*output_dim.d[3];
    }
    else{
        std::cout << "AttentionBlock " << name_ << "invalid dimensions of output, except 3(BLC) or 4(BLND) but get " << output_dim.nbDims << std::endl;
        return -2;
    }
    // if (data_type_ != inputDesc[0].type || inputDesc[0].type != outputDesc[0].type){
    if (DataType::kHALF != inputDesc[0].type || inputDesc[0].type != outputDesc[0].type){
        std::cout << "AttentionBlock " << name_ << "invalid input/output data type, need be half" << std::endl;
        return -2;
    }
    if (in_batch != out_batch || in_batch != batch_ || in_channels != channel_input_ 
        || in_seq_len != out_seq_len || in_seq_len != seq_len_ || out_channels != channel_output_){
        std::cout << "AttentionBlock " << name_ << "invalid input/output shape, incompatiable with plugin setting" << std::endl;
        return -2;
    }
    if (seq_len_ == 400 && num_head_ == 4 && head_dim_ == 128 && channel_input_ == 512 && channel_output_ == 512){
        custom_plugin_kernel::attnBlockPosEmbed2NormResExecutor(reinterpret_cast<const half*>(input_p), 
                                        reinterpret_cast<const half*>(qkv_weight_p_), reinterpret_cast<const half*>(qkv_bias_p_), 
                                        reinterpret_cast<const half*>(out_weight_p_), reinterpret_cast<const half*>(out_bias_p_),
                                        reinterpret_cast<const half*>(norm_scale_p_), reinterpret_cast<const half*>(norm_bias_p_),
                                        reinterpret_cast<half*>(output_p),
                                        intern_q_p_, intern_k_p_, intern_v_p_, intern_mha_p_,
                                        batch_, num_head_, seq_len_, head_dim_, channel_output_, eps_, stream);
    }
    else{
        std::cout << "AttentionBlock " << name_ << "invalid dimensions of setting" << std::endl;
        std::cout << "only support seq_len = 400, num_head = 4, head_dim = 128 channel_in = channel_out = 512 yet" << std::endl;
        return -2;
    }
    return 0;
}

char const* AttentionBlockPlugin::getPluginType() const noexcept{
    return kATTENTION_BLOCK_PLUGIN_NAME;
}
char const* AttentionBlockPlugin::getPluginVersion() const noexcept{
    return kATTENTION_BLOCK_PLUGIN_VERSION;
}
int32_t AttentionBlockPlugin::getNbOutputs() const noexcept{
    return 1;
}
size_t AttentionBlockPlugin::getSerializationSize() const noexcept{
    int elements_byte_len = qkv_weight_.count + qkv_bias_.count + out_weight_.count + out_bias_.count + norm_scale_.count + norm_bias_.count;
    if (qkv_weight_.type == DataType::kFLOAT && qkv_bias_.type == DataType::kFLOAT 
        && out_weight_.type == DataType::kFLOAT && out_bias_.type == DataType::kFLOAT
        && norm_scale_.type == DataType::kFLOAT && norm_bias_.type == DataType::kFLOAT
        && data_type_ == DataType::kFLOAT){
        elements_byte_len *= sizeof(float);
    }
    else if (qkv_weight_.type == DataType::kHALF && qkv_bias_.type == DataType::kHALF 
        && out_weight_.type == DataType::kHALF && out_bias_.type == DataType::kHALF
        && norm_scale_.type == DataType::kHALF && norm_bias_.type == DataType::kHALF
        && data_type_ == DataType::kHALF){
        elements_byte_len *= sizeof(half);
    }
    else{
        std::cout << "AttentionBlock " << name_ << " in&out/scale/bias type should be float or half" << std::endl;
    }
    return kATTENTION_BLOCK_SERIALIZATION_SIZE + elements_byte_len;
}
char const* AttentionBlockPlugin::getPluginNamespace() const noexcept{
    return nameSpace_.c_str();
}
DataType AttentionBlockPlugin::getOutputDataType(int32_t index, DataType const* inputTypes, int32_t nbInputs) const noexcept{
    return data_type_;
}
DimsExprs AttentionBlockPlugin::getOutputDimensions(
        int32_t outputIndex, DimsExprs const* inputs, int32_t nbInputs, IExprBuilder& exprBuilder) noexcept{
            std::cout<<"AttentionBlock " << name_ << " checking x-th output dims "<<outputIndex << std::endl;
    return inputs[0];
}
size_t AttentionBlockPlugin::getWorkspaceSize(PluginTensorDesc const* inputs, int32_t nbInputs, PluginTensorDesc const* outputs,
        int32_t nbOutputs) const noexcept{
    return 0;
}
void AttentionBlockPlugin::setPluginNamespace(char const* pluginNamespace) noexcept{
    nameSpace_ = pluginNamespace;
}
bool AttentionBlockPlugin::setEpsFactor(float eps){
    eps_ = eps;
    return true;
}
bool AttentionBlockPlugin::setName(std::string name){
    name_ = name;
    return true;
}

PluginFieldCollection AttentionBlockPluginCreator::mFC_{};
std::vector<PluginField> AttentionBlockPluginCreator::mPluginAttributes_;
std::unordered_map<int32_t, DataType> AttentionBlockPluginCreator::nv_type_table_ = {
                                                                        {static_cast<int32_t>(DataType::kFLOAT), DataType::kFLOAT}, //{0, DataType::kFLOAT},
                                                                        {static_cast<int32_t>(DataType::kHALF), DataType::kHALF}, //{1, DataType::kHALF},
};

AttentionBlockPluginCreator::AttentionBlockPluginCreator(){
    mPluginAttributes_.clear();
    mPluginAttributes_.emplace_back(PluginField("data_type", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes_.emplace_back(PluginField("qkv_weight", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes_.emplace_back(PluginField("qkv_bias", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes_.emplace_back(PluginField("out_weight", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes_.emplace_back(PluginField("out_bias", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes_.emplace_back(PluginField("norm_scale", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes_.emplace_back(PluginField("norm_bias", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes_.emplace_back(PluginField("batch", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes_.emplace_back(PluginField("seq_len", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes_.emplace_back(PluginField("num_head", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes_.emplace_back(PluginField("head_dim", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes_.emplace_back(PluginField("channel_input", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes_.emplace_back(PluginField("channel_output", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes_.emplace_back(PluginField("eps", nullptr, PluginFieldType::kFLOAT32, 1));
    mFC_.nbFields = mPluginAttributes_.size();
    mFC_.fields = mPluginAttributes_.data();
}
AttentionBlockPluginCreator::~AttentionBlockPluginCreator(){}
// seems data_type must be f32 ?
IPluginV2* AttentionBlockPluginCreator::createPlugin(char const* name, PluginFieldCollection const* fc) noexcept{
    try{
        PLUGIN_VALIDATE(fc != nullptr);
        PluginField const* fields = fc->fields;
        DataType data_type;
        Weights qkv_weight, qkv_bias, out_weight, out_bias, norm_scale, norm_bias;
        int batch, seq_len, num_head, head_dim, channel_input, channel_output;
        std::unordered_map<std::string, Weights*> weights_table = {{"qkv_weight", &qkv_weight}, {"qkv_bias", &qkv_bias}
                                                                    , {"out_weight", &out_weight}, {"out_bias", &out_bias}
                                                                    , {"norm_scale", &norm_scale}, {"norm_bias", &norm_bias}};
        std::unordered_map<std::string, int*> int_args_table = {{"batch", &batch}, {"seq_len", &seq_len}
                                                                , {"num_head", &num_head}, {"head_dim", &head_dim}
                                                                , {"channel_input", &channel_input}, {"channel_output", &channel_output}};
        float eps;
        int complete_check = 0;
        for (int32_t i = 0; i < fc->nbFields; ++i){
            char const* attrName = fields[i].name;
            if (!strcmp(attrName, "data_type")){
                complete_check ++;
                PLUGIN_VALIDATE(fields[i].type == PluginFieldType::kINT32);
                int32_t type_id = static_cast<int32_t>(*(static_cast<int32_t const*>(fields[i].data)));
                if (nv_type_table_.count(type_id) == 0){
                    std::cout << "unsupported type id " << type_id << "use 0 for DataType::kFLOAT or 1 for DataType::kHALF" << std::endl;
                    return nullptr;
                }
                data_type = nv_type_table_.at(type_id);
            }
            else if (!strcmp(attrName, "qkv_weight") || !strcmp(attrName, "qkv_bias")
                    || !strcmp(attrName, "out_weight") || !strcmp(attrName, "out_bias")
                    || !strcmp(attrName, "norm_scale") || !strcmp(attrName, "norm_bias")){
                complete_check ++;
                Weights* tmp_p = weights_table.at(attrName);
                tmp_p->type = DataType::kFLOAT;
                tmp_p->count = fields[i].length;
                tmp_p->values = fields[i].data;
            }
            else if (!strcmp(attrName, "batch") || !strcmp(attrName, "seq_len")
                    || !strcmp(attrName, "num_head") || !strcmp(attrName, "head_dim")
                    || !strcmp(attrName, "channel_input") || !strcmp(attrName, "channel_output")){
                complete_check ++;
                PLUGIN_VALIDATE(fields[i].type == PluginFieldType::kINT32);
                int* tmp_p = int_args_table.at(attrName);
                *tmp_p = reinterpret_cast<const int*>(fields[i].data)[0];
            }
            else if (!strcmp(attrName, "eps")){
                complete_check ++;
                PLUGIN_VALIDATE(fields[i].type == PluginFieldType::kFLOAT32);
                eps = reinterpret_cast<const float*>(fields[i].data)[0];
            }
        }
        if (data_type != qkv_weight.type || data_type != qkv_bias.type
            || data_type != out_weight.type || data_type != out_bias.type
            || data_type != norm_scale.type || data_type != norm_bias.type){
            std::cout << "uncompatible AttentionBlock plugin creation, data type for plugin/weight/scale/bias should be the same" << std::endl;
            return nullptr;
        }
        if (complete_check != 14){
            std::cout << "uncompatible AttentionBlock plugin creation, need 14 attributes but get " << complete_check << std::endl;
            return nullptr;
        }
        if (qkv_weight.count != 3*num_head*head_dim*channel_input || qkv_bias.count != 3*num_head*head_dim
            || out_weight.count != channel_output*num_head*head_dim || out_bias.count != channel_output
            || norm_scale.count != channel_output || norm_bias.count != channel_output){
            std::cout << "uncompatible AttentionBlock plugin creation for inconsist weight/scale/bias count " << std::endl;
            return nullptr;
        }
        return new AttentionBlockPlugin(name, data_type, qkv_weight, qkv_bias, out_weight, out_bias, norm_scale, norm_bias,
                                        batch, seq_len, num_head, head_dim, channel_input, channel_output, eps);
    }
    catch (std::exception const& e){
        caughtError(e);
    }
    return nullptr;
}

IPluginV2* AttentionBlockPluginCreator::deserializePlugin(
    char const* name, void const* serialData, size_t serialLength) noexcept{
    try{
        PLUGIN_VALIDATE(serialData != nullptr);
        return new AttentionBlockPlugin(name, serialData, serialLength);
    }
    catch (std::exception const& e){
        caughtError(e);
    }
    return nullptr;
}

char const* AttentionBlockPluginCreator::getPluginName() const noexcept{
    return kATTENTION_BLOCK_PLUGIN_NAME;
}
char const* AttentionBlockPluginCreator::getPluginVersion() const noexcept{
    return kATTENTION_BLOCK_PLUGIN_VERSION;
}
PluginFieldCollection const* AttentionBlockPluginCreator::getFieldNames() noexcept{
    return &mFC_;
}

REGISTER_TENSORRT_PLUGIN(AttentionBlockPluginCreator);