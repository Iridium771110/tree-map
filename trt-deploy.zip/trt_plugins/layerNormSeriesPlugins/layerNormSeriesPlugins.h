
#ifndef TRT_LAYERNORMSERIES_PLUGIN_H
#define TRT_LAYERNORMSERIES_PLUGIN_H

#include "plugin.h"
#include <cuda_runtime_api.h>
#include <stdint.h>
#include <vector>
#include <cuda.h>
#include "cuda_fp16.h"

#include "checkMacrosPlugin.h"

#include "NvInfer.h"
#include "NvInferPlugin.h"

#include <unordered_map>
//仅支持对最后一维度进行操作
//在某些情况下支持前后序的点对点加减乘除操作
//目前按照固定维度长进行定义（to do 非固定维度长度）
//目前仅支持half类型输入输出
//默认scale和bias的长度一致，均为最后一维长度
//设置为klinear，因为实质上各维表意并不重要，在这里应当认为末尾为C

namespace custom_plugin_kernel{
    int lastDimNormalizationKernelExecutor(const half* src_p, const half* scale_p, const half* bias_p, half* dst_p,
                                        const float eps, const int batch, const int seq_len, cudaStream_t stream);
    int lastDimNormalizationWithEleopKernelExector(const void* input_p, void* output_p, const float* scale_p, const float* bias_p, float eps,
                                            std::vector<int> &shape, std::string &data_type, int scale_dim_id, cudaStream_t stream);// to do
}

namespace nvinfer1
{
namespace plugin
{

class LayerNormSeriesPlugin : public IPluginV2DynamicExt
{
public:
    LayerNormSeriesPlugin() = delete;
    LayerNormSeriesPlugin(std::string const& name, DataType data_type, Weights scales, Weights bias, float eps);//正常malloc使用
    LayerNormSeriesPlugin(DataType data_type, Weights scales, Weights bias,
                            void* scales_p, void* bias_p, std::vector<int> run_shape_, float eps, bool initialed); // clone使用，应当避免新的malloc
    LayerNormSeriesPlugin(std::string const& name, void const* buffer, size_t length);//正常malloc使用
    ~LayerNormSeriesPlugin() override;

    // Method inherited from IPluginV2
    char const* getPluginType() const noexcept override;
    char const* getPluginVersion() const noexcept override;
    int32_t getNbOutputs() const noexcept override;
    int32_t initialize() noexcept override;
    void terminate() noexcept override;
    size_t getSerializationSize() const noexcept override;
    void serialize(void* buffer) const noexcept override;
    void destroy() noexcept override;
    void setPluginNamespace(char const* pluginNamespace) noexcept override;
    char const* getPluginNamespace() const noexcept override;

    // Method inherited from IPluginV2Ext
    DataType getOutputDataType(int32_t index, DataType const* inputTypes, int32_t nbInputs) const noexcept override;

    // Method inherited from IPluginV2DynamicExt
    IPluginV2DynamicExt* clone() const noexcept override;
    DimsExprs getOutputDimensions(
        int32_t outputIndex, DimsExprs const* inputs, int32_t nbInputs, IExprBuilder& exprBuilder) noexcept override;
    bool supportsFormatCombination(
        int32_t pos, PluginTensorDesc const* inOut, int32_t nbInputs, int32_t nbOutputs) noexcept override;
    void configurePlugin(DynamicPluginTensorDesc const* in, int32_t nbInputs, DynamicPluginTensorDesc const* out,
        int32_t nbOutputs) noexcept override;
    size_t getWorkspaceSize(PluginTensorDesc const* inputs, int32_t nbInputs, PluginTensorDesc const* outputs,
        int32_t nbOutputs) const noexcept override;
    int32_t enqueue(PluginTensorDesc const* inputDesc, PluginTensorDesc const* outputDesc, void const* const* inputs,
        void* const* outputs, void* workspace, cudaStream_t stream) noexcept override;

    //self defined
    bool setEpsFactor(float eps);
    bool setName(std::string name);
private:
    std::string name_;
    std::string nameSpace_;
    DataType data_type_;
    Weights scales_;
    Weights bias_;
    void* scales_p_ = nullptr;
    void* bias_p_ = nullptr;
    std::vector<int> run_shape_ = {1, 1, 1};
    float eps_ = 1e-5f;
    bool initialed_ = false;

    std::vector<char> bias_data_zone_;
    std::vector<char> scales_data_zone_;

    // static std::unordered_map<DataType, std::string> trt_type_string_table_;
};

class LayerNormSeriesPluginCreator : public nvinfer1::pluginInternal::BaseCreator
{
public:
    LayerNormSeriesPluginCreator();
    ~LayerNormSeriesPluginCreator();
    char const* getPluginName() const noexcept override;
    char const* getPluginVersion() const noexcept override;
    PluginFieldCollection const* getFieldNames() noexcept override;
    IPluginV2* createPlugin(char const* name, PluginFieldCollection const* fc) noexcept override;
    IPluginV2* deserializePlugin(char const* name, void const* serialData, size_t serialLength) noexcept override;

private:
    //这两似乎没啥卵用
    static PluginFieldCollection mFC_;
    static std::vector<PluginField> mPluginAttributes_;
    static std::unordered_map<int32_t, DataType> nv_type_table_;
};

}}

#endif