#include "layerNormSeriesPlugins.h"

using namespace nvinfer1;
using namespace plugin;

using nvinfer1::plugin::LayerNormSeriesPlugin;
using nvinfer1::plugin::LayerNormSeriesPluginCreator;

namespace
{
char const* kLAYERNORM_SERIES_PLUGIN_NAME{"LayerNormSeriesPlugin_custom"};
char const* kLAYERNORM_SERIES_PLUGIN_VERSION{"1"};
size_t constexpr kLAYERNORM_SERIES_SERIALIZATION_SIZE{sizeof(DataType) + 2*sizeof(Weights) + sizeof(float)};
} // namespace

LayerNormSeriesPlugin::LayerNormSeriesPlugin(std::string const& name, DataType data_type, Weights scales, Weights bias, float eps)
    : name_(name)
    , data_type_(data_type)
    , scales_(scales)
    , bias_(bias)
    , eps_(eps)
{
    int elements_byte_len = scales_.count;
    if (data_type_ == DataType::kFLOAT) elements_byte_len *= 4;
    else if (data_type_ == DataType::kHALF) elements_byte_len *= 2;
    else std::cout << "in LayerNormSeries " << name << " data type unsupported, use kHALF instead" << std::endl;
    scales_data_zone_.resize(elements_byte_len);
    bias_data_zone_.resize(elements_byte_len);
    std::memcpy(scales_data_zone_.data(), scales_.values, elements_byte_len);
    std::memcpy(bias_data_zone_.data(), bias_.values, elements_byte_len);
    scales_.values = reinterpret_cast<const void*>(scales_data_zone_.data());
    bias_.values = reinterpret_cast<const void*>(bias_data_zone_.data());
}
LayerNormSeriesPlugin::LayerNormSeriesPlugin(DataType data_type, Weights scales, Weights bias,
                            void* scales_p, void* bias_p, std::vector<int> run_shape_, float eps, bool initialed)
    : data_type_(data_type)
    , scales_(scales)
    , bias_(bias)
    , scales_p_(scales_p)
    , bias_p_(bias_p)
    , eps_(eps)
    , initialed_(initialed)
{
}
LayerNormSeriesPlugin::LayerNormSeriesPlugin(std::string const& name, void const* buffer, size_t length)
    : name_(name)
{
    PLUGIN_VALIDATE(buffer != nullptr);
    
    char const* d = static_cast<char const*>(buffer);
    char const* a = d;
    data_type_ = read<DataType>(d);
    scales_ = read<Weights>(d);
    bias_ = read<Weights>(d);
    eps_ = read<float>(d);
    int elements_byte_len = scales_.count;
    if (data_type_ == DataType::kFLOAT) elements_byte_len *= 4;
    else if (data_type_ == DataType::kHALF) elements_byte_len *= 2;
    else std::cout << "in LayerNormSeries " << name << " data type unsupported, use kHALF instead" << std::endl;
    scales_data_zone_.resize(elements_byte_len);
    bias_data_zone_.resize(elements_byte_len);
    std::memcpy(scales_data_zone_.data(), d, elements_byte_len);
    d += elements_byte_len;
    std::memcpy(bias_data_zone_.data(), d, elements_byte_len);
    d += elements_byte_len;
    scales_.values = reinterpret_cast<const void*>(scales_data_zone_.data());
    bias_.values = reinterpret_cast<const void*>(bias_data_zone_.data());
    
    PLUGIN_VALIDATE(length == kLAYERNORM_SERIES_SERIALIZATION_SIZE + 2*elements_byte_len);
    PLUGIN_VALIDATE(d == a + length);
}
LayerNormSeriesPlugin::~LayerNormSeriesPlugin(){
    terminate();
}

IPluginV2DynamicExt* LayerNormSeriesPlugin::clone() const noexcept{
    //将这个plugin对象克隆一份给TensorRT的builder、network或者engine，注意如果涉及指针空间可能需要新的构造函数等
    try{
        cudaDeviceSynchronize();
        auto plugin = new LayerNormSeriesPlugin(this->data_type_, this->scales_, this->bias_, 
                                                this->scales_p_, this->bias_p_, this->run_shape_, this->eps_, false);
        plugin->setPluginNamespace(nameSpace_.c_str());
        return plugin;
    }
    catch (std::exception const& e){
        caughtError(e);
    }
    return nullptr;
}
void LayerNormSeriesPlugin::serialize(void* buffer) const noexcept{
    PLUGIN_ASSERT(buffer != nullptr);
    char* d = static_cast<char*>(buffer);
    char* a = d;
    write<DataType>(d, data_type_);
    write<Weights>(d, scales_);
    write<Weights>(d, bias_);
    write<float>(d, eps_);
    int elements_byte_len = scales_.count;
    if (data_type_ == DataType::kFLOAT) elements_byte_len *= 4;
    else if (data_type_ == DataType::kHALF) elements_byte_len *= 2;
    else std::cout << "in LayerNormSeries " << name_ << " data type unsupported, use kHALF instead" << std::endl;
    std::memcpy(d, scales_.values, elements_byte_len);
    d += elements_byte_len;
    std::memcpy(d, bias_.values, elements_byte_len);
    d += elements_byte_len;
    // for (int i = 0; i < scales_.count; i++) write<float>(d, reinterpret_cast<const float*>(scales_.values)[i]);
    // for (int i = 0; i < bias_.count; i++) write<float>(d, reinterpret_cast<const float*>(bias_.values)[i]);

    PLUGIN_ASSERT(d == a + getSerializationSize());
}
void LayerNormSeriesPlugin::configurePlugin(
    DynamicPluginTensorDesc const* in, int32_t nbInputs, DynamicPluginTensorDesc const* out, int32_t nbOutputs) noexcept{
        //本处配置可以部分用于运行时检查
    if (nbInputs != 1 || nbOutputs != 1){
        std::cout << "LayerNormSeriesPlugin aquire 1 input & 1 output, but get " << nbInputs << "input and " << nbOutputs << " output" << std::endl;
    }
    if (in->desc.format != nvinfer1::TensorFormat::kLINEAR){
        std::cout<<"invalid input format "<<std::endl;
    }
}
int32_t LayerNormSeriesPlugin::initialize() noexcept{
    //初始化函数，在这个插件准备开始run之前执行。
    // 主要初始化一些提前开辟空间的参数，一般是一些cuda操作需要的参数(例如conv操作需要执行卷积操作，我们就需要提前开辟weight和bias的显存)
    int elements_byte_len;
    if (scales_.count == bias_.count){
        elements_byte_len = scales_.count;
    }
    else{
        std::cout << "LayerNormSeries " << name_ << " in compatible scale/bias length " << scales_.count << ' ' << bias_.count << std::endl;
    }
    // if (scales_.type == DataType::kFLOAT && bias_.type == DataType::kFLOAT && data_type_ == DataType::kFLOAT){
    //     elements_byte_len *= sizeof(float);
    // }
    // else if (scales_.type == DataType::kHALF && bias_.type == DataType::kHALF && data_type_ == DataType::kHALF){
    //     elements_byte_len *= sizeof(half);
    // }
    // else{
    //     std::cout << "LayerNormSeries " << name_ << " in&out/scale/bias type should be float or half" << std::endl;
    // }
    std::cout<< "LayerNormSeries " << name_ << " will use half precision instead of float"<<std::endl;
    std::vector<half> tmp_scale(elements_byte_len);
    std::vector<half> tmp_bias(elements_byte_len);
    for (int i = 0; i < elements_byte_len; i++) tmp_scale[i] = static_cast<half>(reinterpret_cast<const float*>(scales_.values)[i]);
    for (int i = 0; i < elements_byte_len; i++) tmp_bias[i] = static_cast<half>(reinterpret_cast<const float*>(bias_.values)[i]);
    elements_byte_len *= sizeof(half);
    cudaMalloc(reinterpret_cast<void**>(&scales_p_), elements_byte_len);
    cudaMalloc(reinterpret_cast<void**>(&bias_p_), elements_byte_len);
    cudaMemcpy(scales_p_, tmp_scale.data(), elements_byte_len, cudaMemcpyHostToDevice);
    cudaMemcpy(bias_p_, tmp_bias.data(), elements_byte_len, cudaMemcpyHostToDevice);
    return 0;
}
void LayerNormSeriesPlugin::terminate() noexcept {
    // 析构函数则需要执行terminate，terminate函数就是释放这个op之前开辟的一些显存空间
    if (!initialed_){
        scales_p_ = nullptr;
        bias_p_ = nullptr;
        return;
    }
    if (scales_p_) cudaFree(scales_p_);
    if (bias_p_) cudaFree(bias_p_);
    scales_p_ = nullptr;
    bias_p_ = nullptr;
}
void LayerNormSeriesPlugin::destroy() noexcept{
    delete this;
}
bool LayerNormSeriesPlugin::supportsFormatCombination(
        int32_t pos, PluginTensorDesc const* inOut, int32_t nbInputs, int32_t nbOutputs) noexcept{
    //TensorRT调用此方法以判断pos索引的输入/输出是否支持inOut[pos].format和inOut[pos].type指定的格式/数据类型。
    //在build engine时的核选择等处中，依此来获得可用的那些进行比较选择
    //也以此可以指定中间内部变量可以选用的格式类型等
    //本处仅有1in-1out
    if (pos < 0 || pos >= 2){
        std::cout << "LayerNormSeriesPlugin acquire 1 input & 1 output, but get index " << pos << ", which is out of inout range" << std::endl;
        return false;
    }
    const PluginTensorDesc* in = inOut;
    const PluginTensorDesc* out = inOut + nbInputs;
    if (in[0].format != nvinfer1::TensorFormat::kLINEAR) return false;
    switch (pos){
        case 0:
        // return in[0].type == DataType::kFLOAT || in[0].type == DataType::kHALF;
        return in[0].type == DataType::kHALF;
        case 1:
        // return (out[0].format == in[0].format) && (out[0].type == in[0].type);
        return (out[0].format == in[0].format) && (out[0].type == DataType::kHALF);
    }
    return false;
}

int32_t LayerNormSeriesPlugin::enqueue(PluginTensorDesc const* inputDesc, PluginTensorDesc const* outputDesc, void const* const* inputs,
        void* const* outputs, void* workspace, cudaStream_t stream) noexcept{
    const void* input_p = inputs[0];
    void* output_p = outputs[0];
    Dims input_dim = inputDesc[0].dims;
    int channels = input_dim.d[input_dim.nbDims - 1];
    int batch = 1;
    int seq_len = 1;
    if (input_dim.nbDims < 2){
        std::cout << "LayerNormSeries " << name_ << "invalid dimensions of input, except >=2 but get " << input_dim.nbDims << std::endl;
        return -2;
    }
    else if (input_dim.nbDims == 2){
        seq_len = input_dim.d[0];
    }
    else{
        batch = input_dim.d[0];
        for (int i = 1; i < input_dim.nbDims - 1; i++) seq_len *= input_dim.d[i];
    }
    // if (data_type_ != inputDesc[0].type || inputDesc[0].type != outputDesc[0].type){
    if (DataType::kHALF != inputDesc[0].type || inputDesc[0].type != outputDesc[0].type){
        std::cout << "LayerNormSeries " << name_ << "invalid input/output data type, need be half" << std::endl;
        return -2;
    }
    run_shape_[0] = batch;
    run_shape_[1] = seq_len;
    run_shape_[2] = channels;
    if (channels == 512){
        custom_plugin_kernel::lastDimNormalizationKernelExecutor(reinterpret_cast<const half*>(input_p), reinterpret_cast<half*>(scales_p_), 
                                            reinterpret_cast<half*>(bias_p_), reinterpret_cast<half*>(output_p),
                                            eps_, batch, seq_len, stream);
    }
    else{
        std::cout << "LayerNormSeries " << name_ << "invalid dimensions of input" << std::endl;
        std::cout << "only support last dim(c) = 512 yet" << std::endl;
        return -2;
    }
    return 0;
}

char const* LayerNormSeriesPlugin::getPluginType() const noexcept{
    return kLAYERNORM_SERIES_PLUGIN_NAME;
}
char const* LayerNormSeriesPlugin::getPluginVersion() const noexcept{
    return kLAYERNORM_SERIES_PLUGIN_VERSION;
}
int32_t LayerNormSeriesPlugin::getNbOutputs() const noexcept{
    return 1;
}
size_t LayerNormSeriesPlugin::getSerializationSize() const noexcept{
    int elements_byte_len = scales_.count + bias_.count;
    if (scales_.type == DataType::kFLOAT && bias_.type == DataType::kFLOAT && data_type_ == DataType::kFLOAT){
        elements_byte_len *= sizeof(float);
    }
    else if (scales_.type == DataType::kHALF && bias_.type == DataType::kHALF && data_type_ == DataType::kHALF){
        elements_byte_len *= sizeof(half);
    }
    else{
        std::cout << "LayerNormSeries " << name_ << " in&out/scale/bias type should be float or half" << std::endl;
    }
    return kLAYERNORM_SERIES_SERIALIZATION_SIZE + elements_byte_len;
}
char const* LayerNormSeriesPlugin::getPluginNamespace() const noexcept{
    return nameSpace_.c_str();
}
DataType LayerNormSeriesPlugin::getOutputDataType(int32_t index, DataType const* inputTypes, int32_t nbInputs) const noexcept{
    return data_type_;
}
DimsExprs LayerNormSeriesPlugin::getOutputDimensions(
        int32_t outputIndex, DimsExprs const* inputs, int32_t nbInputs, IExprBuilder& exprBuilder) noexcept{
    return inputs[0];
}
size_t LayerNormSeriesPlugin::getWorkspaceSize(PluginTensorDesc const* inputs, int32_t nbInputs, PluginTensorDesc const* outputs,
        int32_t nbOutputs) const noexcept{
    return 0;
}

void LayerNormSeriesPlugin::setPluginNamespace(char const* pluginNamespace) noexcept{
    nameSpace_ = pluginNamespace;
}
bool LayerNormSeriesPlugin::setEpsFactor(float eps){
    eps_ = eps;
    return true;
}
bool LayerNormSeriesPlugin::setName(std::string name){
    name_ = name;
    return true;
}

PluginFieldCollection LayerNormSeriesPluginCreator::mFC_{};
std::vector<PluginField> LayerNormSeriesPluginCreator::mPluginAttributes_;
std::unordered_map<int32_t, DataType> LayerNormSeriesPluginCreator::nv_type_table_ = {
                                                                        {static_cast<int32_t>(DataType::kFLOAT), DataType::kFLOAT}, //{0, DataType::kFLOAT},
                                                                        {static_cast<int32_t>(DataType::kHALF), DataType::kHALF}, //{1, DataType::kHALF},
};

LayerNormSeriesPluginCreator::LayerNormSeriesPluginCreator(){
    mPluginAttributes_.clear();
    mPluginAttributes_.emplace_back(PluginField("data_type", nullptr, PluginFieldType::kINT32, 1));
    mPluginAttributes_.emplace_back(PluginField("scales", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes_.emplace_back(PluginField("bias", nullptr, PluginFieldType::kFLOAT32, 1));
    mPluginAttributes_.emplace_back(PluginField("eps", nullptr, PluginFieldType::kFLOAT32, 1));
    mFC_.nbFields = mPluginAttributes_.size();
    mFC_.fields = mPluginAttributes_.data();
}
LayerNormSeriesPluginCreator::~LayerNormSeriesPluginCreator(){}

IPluginV2* LayerNormSeriesPluginCreator::createPlugin(char const* name, PluginFieldCollection const* fc) noexcept{
    try{
        PLUGIN_VALIDATE(fc != nullptr);
        PluginField const* fields = fc->fields;
        DataType data_type;
        Weights scales, bias;
        float eps;
        int complete_check = 0;
        for (int32_t i = 0; i < fc->nbFields; ++i){
            char const* attrName = fields[i].name;
            if (!strcmp(attrName, "data_type")){
                complete_check ++;
                PLUGIN_VALIDATE(fields[i].type == PluginFieldType::kINT32);
                int32_t type_id = static_cast<int32_t>(*(static_cast<int32_t const*>(fields[i].data)));
                if (nv_type_table_.count(type_id) == 0){
                    std::cout << "unsupported type id " << type_id << "use 0 for DataType::kFLOAT or 1 for DataType::kHALF" << std::endl;
                    return nullptr;
                }
                data_type = nv_type_table_.at(type_id);
            }
            else if (!strcmp(attrName, "scales")){
                complete_check ++;
                scales.type = DataType::kFLOAT;
                scales.count = fields[i].length;
                scales.values = fields[i].data;
            }
            else if (!strcmp(attrName, "bias")){
                complete_check ++;
                bias.type = DataType::kFLOAT;
                bias.count = fields[i].length;
                bias.values = fields[i].data;
            }
            else if (!strcmp(attrName, "eps")){
                complete_check ++;
                PLUGIN_VALIDATE(fields[i].type == PluginFieldType::kFLOAT32);
                eps = reinterpret_cast<const float*>(fields[i].data)[0];
            }
        }
        if (data_type != scales.type || data_type != bias.type){
            std::cout << "uncompatible LayerNormSeries plugin creation, data type for plugin/scale/bias should be the same" << std::endl;
            return nullptr;
        }
        if (complete_check != 4){
            std::cout << "uncompatible LayerNormSeries plugin creation, need 4 attributes but get " << complete_check << std::endl;
            return nullptr;
        }
        if (scales.count != bias.count){
            std::cout << "uncompatible LayerNormSeries plugin creation for scales number not equal to bias number " << std::endl;
            return nullptr;
        }
        return new LayerNormSeriesPlugin(name, data_type, scales, bias, eps);
    }
    catch (std::exception const& e){
        caughtError(e);
    }
    return nullptr;
}

IPluginV2* LayerNormSeriesPluginCreator::deserializePlugin(
    char const* name, void const* serialData, size_t serialLength) noexcept{
    try{
        PLUGIN_VALIDATE(serialData != nullptr);
        return new LayerNormSeriesPlugin(name, serialData, serialLength);
    }
    catch (std::exception const& e){
        caughtError(e);
    }
    return nullptr;
}

char const* LayerNormSeriesPluginCreator::getPluginName() const noexcept{
    return kLAYERNORM_SERIES_PLUGIN_NAME;
}
char const* LayerNormSeriesPluginCreator::getPluginVersion() const noexcept{
    return kLAYERNORM_SERIES_PLUGIN_VERSION;
}
PluginFieldCollection const* LayerNormSeriesPluginCreator::getFieldNames() noexcept{
    return &mFC_;
}

REGISTER_TENSORRT_PLUGIN(LayerNormSeriesPluginCreator);