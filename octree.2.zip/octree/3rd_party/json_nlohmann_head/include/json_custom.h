#ifndef JSON_NLOHMANN_HEAD_JSON_CUSTOM_H
#define JSON_NLOHMANN_HEAD_JSON_CUSTOM_H

#include "json.hpp"
#include <string>

namespace json{
namespace customfunc{

void getJsonFromFile(const std::string file_path, nlohmann::json &json_cfg);

}
}

#endif