cloned from nlohmann json, added some functions for custom-defined requirements. continue to append
## list of functions
```
void json::customfunc::getJsonFromFile(const std::string file_path, nlohmann::json &json_cfg)

get nlohmann json object from file
if failed, reference object remain unchanged
```