#include "json_custom.h"
#include <fstream>
#include <iostream>

namespace json{
namespace customfunc{

void getJsonFromFile(const std::string file_path, nlohmann::json &json_cfg){
    std::ifstream json_file(file_path);
    if (!json_file.good()){
        std::cout << file_path << " not a valid file" << std::endl;
        return;
    }
    json_file >> json_cfg;
    std::cout << "warning: json from file " << file_path << " was not checked whether a valid json format" << std::endl;
}

}
}
