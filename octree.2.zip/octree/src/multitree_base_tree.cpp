#include "multitree_base_tree.h"

namespace multitree{

TreeLeaf::TreeLeaf(){
    status_ = 0;
}

void TreeLeaf::setLeafInfo(){
    data_ = 0;
}
void TreeLeaf::updateLeafInfo(){
    // if (status_ == 0){ 
    //     this->initLeaf();
    // }
    data_ = 0;
}
void TreeLeaf::updateLeafStatus(char status){
    status_ = status;
}
char TreeLeaf::getLeafStatus(){
    return status_;
}

inline int TreeLeaf::accumulateInfo(){
    return ++data_;
}

// void TreeLeaf::initLeaf(){
//     status_ = 1;
// }
// void TreeLeaf::resetLeaf(){
//     status_ = 0;
// }


TreeBranch::TreeBranch(const int &log_leaf_level)
    :log_leaf_level_(log_leaf_level)
{
    branch_leaf_num_ = 1 << (log_leaf_level_ * 3);
    leafs_pp_ = new TreeLeaf*[branch_leaf_num_];
    for (int i = 0; i < branch_leaf_num_; i++) leafs_pp_[i] = nullptr;
    valid_leaf_num_ = 0;
}

TreeBranch::~TreeBranch(){
    for (int i = 0; i < branch_leaf_num_; i++){
        if (leafs_pp_[i] != nullptr){
            delete leafs_pp_[i];
            leafs_pp_[i] = nullptr;
        }
    }
    delete[] leafs_pp_;
    leafs_pp_ = nullptr;
}

int TreeBranch::resetBranch(){
    if (status_ == 0) return 0;
    int ret = 0;
    for (int i = 0; i < branch_leaf_num_; i++){
        if (leafs_pp_[i] != nullptr){
            delete leafs_pp_[i];
            leafs_pp_[i] = nullptr;
            ret++;
        }
    }
    status_ = 0;
    valid_leaf_num_ = 0;
    return ret;
}

BaseBiLayerCubicTree::BaseBiLayerCubicTree(const int &log_level_branch, const int &log_level_leaf, const float &resolution, const int &single_mode)
    :log_level_branch_(log_level_branch),
    log_level_leaf_(log_level_leaf),
    resolution_(resolution),
    single_mode_(single_mode)
{
    tree_branch_num_ = 1 << (log_level_branch_ * 3);
    branches_pp_ = new TreeBranch*[tree_branch_num_];
    for (int i = 0; i < tree_branch_num_; i++) branches_pp_[i] = nullptr;
    valid_leaf_num_ = 0;
    total_log_level_ = log_level_branch_ + log_level_leaf_;
    direction_max_coord_ = (1 << total_log_level_) - 1;
    coord_mask_branch_ = (1 << log_level_branch_) - 1;
    coord_mask_leaf_ = (1 << log_level_leaf_) - 1;
}

BaseBiLayerCubicTree::~BaseBiLayerCubicTree(){
    // std::cout<<"tree deconstruct"<<std::endl;
    for (int i = 0; i < tree_branch_num_; i++){
        if (branches_pp_[i] != nullptr){
            delete branches_pp_[i];
            branches_pp_[i] = nullptr;
        }
    }
    delete[] branches_pp_;
    branches_pp_ = nullptr;
}

bool BaseBiLayerCubicTree::resetTree(){
    if (valid_leaf_num_ == 0) return true;
    for (int i = 0; i < tree_branch_num_; i++){
        if (branches_pp_[i] != nullptr){
            delete branches_pp_[i];
            branches_pp_[i] = nullptr;
        }
    }
    valid_leaf_num_ = 0;
    return true;
}

bool BaseBiLayerCubicTree::addPoint(const float &x, const float &y, const float &z){
    //x,y,z为内部相对坐标，根节点原点默认为0,0,0
    int coord_x = std::min(std::max(static_cast<int>(x / resolution_), 0), direction_max_coord_);
    int coord_y = std::min(std::max(static_cast<int>(y / resolution_), 0), direction_max_coord_);
    int coord_z = std::min(std::max(static_cast<int>(z / resolution_), 0), direction_max_coord_);
    //为了防止精度问题导致坐标溢出
    int coord_branch = ((coord_x >> log_level_leaf_) & coord_mask_branch_) << log_level_branch_;
    coord_branch |= ((coord_y >> log_level_leaf_) & coord_mask_branch_);
    coord_branch <<= log_level_branch_;
    coord_branch |= ((coord_z >> log_level_leaf_) & coord_mask_branch_);
    int coord_leaf = (coord_x & coord_mask_leaf_) << log_level_leaf_;
    coord_leaf |= (coord_y & coord_mask_leaf_);
    coord_leaf <<= log_level_leaf_;
    coord_leaf |= (coord_z & coord_mask_leaf_);
    TreeBranch* tmp_branch_p = branches_pp_[coord_branch];
    if (tmp_branch_p == nullptr){
        tmp_branch_p = new TreeBranch(log_level_leaf_);
        branches_pp_[coord_branch] = tmp_branch_p;
        TreeLeaf* tmp_leaf_p = new TreeLeaf;
        tmp_branch_p->getLeafPtrPtr()[coord_leaf] = tmp_leaf_p;
        tmp_branch_p->accumulateValidLeafNum(1);
        tmp_leaf_p->setLeafInfo();
        valid_leaf_num_ ++;
        tmp_leaf_p = nullptr;
    }
    else{
        TreeLeaf* tmp_leaf_p = tmp_branch_p->getLeafPtrPtr()[coord_leaf];
        if (tmp_leaf_p == nullptr){
            tmp_leaf_p = new TreeLeaf;
            tmp_branch_p->getLeafPtrPtr()[coord_leaf] = tmp_leaf_p;
            tmp_branch_p->accumulateValidLeafNum(1);
            tmp_leaf_p->setLeafInfo();
            valid_leaf_num_ ++;
        }
        else{
            tmp_leaf_p->updateLeafInfo();
        }
        tmp_leaf_p = nullptr;
    }
    tmp_branch_p->updateBranchStatus(char(1));
    tmp_branch_p = nullptr;
    return true;
}

TreeLeaf* BaseBiLayerCubicTree::searchPoint(const float &x, const float &y, const float &z){
    //x,y,z为内部相对坐标，根节点原点默认为0,0,0
    int coord_x = std::min(std::max(static_cast<int>(x / resolution_), 0), direction_max_coord_);
    int coord_y = std::min(std::max(static_cast<int>(y / resolution_), 0), direction_max_coord_);
    int coord_z = std::min(std::max(static_cast<int>(z / resolution_), 0), direction_max_coord_);
    //为了防止精度问题导致坐标溢出
    int coord_branch = ((coord_x >> log_level_leaf_) & coord_mask_branch_) << log_level_branch_;
    coord_branch |= ((coord_y >> log_level_leaf_) & coord_mask_branch_);
    coord_branch <<= log_level_branch_;
    coord_branch |= ((coord_z >> log_level_leaf_) & coord_mask_branch_);
    int coord_leaf = (coord_x & coord_mask_leaf_) << log_level_leaf_;
    coord_leaf |= (coord_y & coord_mask_leaf_);
    coord_leaf <<= log_level_leaf_;
    coord_leaf |= (coord_z & coord_mask_leaf_);
    TreeLeaf* ret = nullptr;
    TreeBranch* tmp_branch_p = branches_pp_[coord_branch];
    if (tmp_branch_p != nullptr){
        if (tmp_branch_p->getBranchStatus() == 0) return ret;
        TreeLeaf* tmp_leaf_p = tmp_branch_p->getLeafPtrPtr()[coord_leaf];
        if (tmp_leaf_p != nullptr) ret = tmp_leaf_p;
        tmp_leaf_p = nullptr;
    }
    tmp_branch_p = nullptr;
    return ret;
}

TreeLeaf* BaseBiLayerCubicTree::addPointAndDynamicStatus(const float &x, const float &y, const float &z, const char &status){
    //x,y,z为内部相对坐标，根节点原点默认为0,0,0
    int coord_x = std::min(std::max(static_cast<int>(x / resolution_), 0), direction_max_coord_);
    int coord_y = std::min(std::max(static_cast<int>(y / resolution_), 0), direction_max_coord_);
    int coord_z = std::min(std::max(static_cast<int>(z / resolution_), 0), direction_max_coord_);
    //为了防止精度问题导致坐标溢出
    int coord_branch = ((coord_x >> log_level_leaf_) & coord_mask_branch_) << log_level_branch_;
    coord_branch |= ((coord_y >> log_level_leaf_) & coord_mask_branch_);
    coord_branch <<= log_level_branch_;
    coord_branch |= ((coord_z >> log_level_leaf_) & coord_mask_branch_);
    int coord_leaf = (coord_x & coord_mask_leaf_) << log_level_leaf_;
    coord_leaf |= (coord_y & coord_mask_leaf_);
    coord_leaf <<= log_level_leaf_;
    coord_leaf |= (coord_z & coord_mask_leaf_);
    TreeLeaf* ret = nullptr;
    TreeBranch* tmp_branch_p = branches_pp_[coord_branch];
    if (tmp_branch_p == nullptr){
        tmp_branch_p = new TreeBranch(log_level_leaf_);
        branches_pp_[coord_branch] = tmp_branch_p;
        TreeLeaf* tmp_leaf_p = new TreeLeaf;
        tmp_branch_p->getLeafPtrPtr()[coord_leaf] = tmp_leaf_p;
        tmp_branch_p->accumulateValidLeafNum(1);
        tmp_leaf_p->setLeafInfo();
        valid_leaf_num_ ++;
        if (status == 1) tmp_leaf_p->updateLeafStatus(status);
        ret = tmp_leaf_p;
        tmp_leaf_p = nullptr;
    }
    else{
        TreeLeaf* tmp_leaf_p = tmp_branch_p->getLeafPtrPtr()[coord_leaf];
        if (tmp_leaf_p == nullptr){
            tmp_leaf_p = new TreeLeaf;
            tmp_branch_p->getLeafPtrPtr()[coord_leaf] = tmp_leaf_p;
            tmp_branch_p->accumulateValidLeafNum(1);
            tmp_leaf_p->setLeafInfo();
            valid_leaf_num_ ++;
            ret = tmp_leaf_p;
        }
        else{
            tmp_leaf_p->updateLeafInfo();
        }
        if (status == 1) tmp_leaf_p->updateLeafStatus(status);
        tmp_leaf_p = nullptr;
    }
    tmp_branch_p->updateBranchStatus(char(1));
    tmp_branch_p = nullptr;
    return ret;
}

int BaseBiLayerCubicTree::getIntCoord(const float &x, const float &y, const float &z){
    //x,y,z为内部相对坐标，根节点原点默认为0,0,0
    int coord_x = std::min(std::max(static_cast<int>(x / resolution_), 0), direction_max_coord_);
    int coord_y = std::min(std::max(static_cast<int>(y / resolution_), 0), direction_max_coord_);
    int coord_z = std::min(std::max(static_cast<int>(z / resolution_), 0), direction_max_coord_);
    //为了防止精度问题导致坐标溢出
    int coord = coord_x << total_log_level_;
    coord |= coord_y;
    coord <<= total_log_level_;
    coord |= coord_z;
    return coord;
}
float BaseBiLayerCubicTree::getResolution(){return resolution_;}
int BaseBiLayerCubicTree::getValidLeafNum(){return valid_leaf_num_;}

bool BaseBiLayerCubicTree::checkCoordRangeConstrain(const int &max_x, const int &max_y, const int &max_z, const int &min_x, const int &min_y, const int &min_z){
    //直接删格子,仅包括叶子，分支需要标志位标识是否已经全空
    //输入均是相对坐标, max != min
    if (max_x <= 0 || max_y <= 0 || max_z <= 0 || min_x > direction_max_coord_ || min_y > direction_max_coord_ || min_z > direction_max_coord_){
        return this->resetTree();
    }
    int max_branch_x = ((max_x - 1) >> log_level_leaf_) & coord_mask_branch_;
    int max_branch_y = ((max_y - 1) >> log_level_leaf_) & coord_mask_branch_;
    int max_branch_z = ((max_z - 1) >> log_level_leaf_) & coord_mask_branch_;
    int max_leaf_x = (max_x - 1) & coord_mask_leaf_;
    int max_leaf_y = (max_y - 1) & coord_mask_leaf_;
    int max_leaf_z = (max_z - 1) & coord_mask_leaf_;
    int min_branch_x = (min_x >> log_level_leaf_) & coord_mask_branch_;
    int min_branch_y = (min_y >> log_level_leaf_) & coord_mask_branch_;
    int min_branch_z = (min_z >> log_level_leaf_) & coord_mask_branch_;
    int min_leaf_x = min_x & coord_mask_leaf_;
    int min_leaf_y = min_y & coord_mask_leaf_;
    int min_leaf_z = min_z & coord_mask_leaf_;
    for (int i = 0; i < tree_branch_num_; i++){
        TreeBranch* tmp_branch_p = branches_pp_[i];
        if (tmp_branch_p == nullptr) continue;
        if (tmp_branch_p->getBranchStatus() == 0) continue;
        int branch_x = (i >> (2*log_level_branch_)) & coord_mask_branch_;
        int branch_y = (i >> log_level_branch_) & coord_mask_branch_;
        int branch_z = i & coord_mask_branch_;
        if (branch_x < max_branch_x && branch_x > min_branch_x &&
            branch_y < max_branch_y && branch_y > min_branch_y &&
            branch_z < max_branch_z && branch_z > min_branch_z) continue;
        if (branch_x > max_branch_x || branch_x < min_branch_x ||
            branch_y > max_branch_y || branch_y < min_branch_y ||
            branch_z > max_branch_z || branch_z < min_branch_z){
            valid_leaf_num_ -= tmp_branch_p->resetBranch();
            continue;
        }
        int leaf_num = tmp_branch_p->getBranchLeafNum();
        for (int j = 0; j < leaf_num; j++){
            if (tmp_branch_p->getLeafPtrPtr()[j] == nullptr) continue;
            int leaf_x = (j >> (2*log_level_leaf_)) & coord_mask_leaf_;
            int leaf_y = (j >> log_level_leaf_) & coord_mask_leaf_;
            int leaf_z = j & coord_mask_leaf_;
            int x = (branch_x << log_level_leaf_) | leaf_x;
            int y = (branch_y << log_level_leaf_) | leaf_y;
            int z = (branch_z << log_level_leaf_) | leaf_z;
            if (x >= max_x || x < min_x ||
                y >= max_y || y < min_y ||
                z >= max_z || z < min_z){
                delete tmp_branch_p->getLeafPtrPtr()[j];
                tmp_branch_p->getLeafPtrPtr()[j] = nullptr;
                tmp_branch_p->accumulateValidLeafNum(-1);
                valid_leaf_num_ --;
            }
        }
        if (tmp_branch_p->getBranchValidLeafNum() == 0) tmp_branch_p->updateBranchStatus(char(0));
        tmp_branch_p = nullptr;
    }
    return true;
}



std::vector<int> BaseBiLayerCubicTree::checkLeafIntCoord(){
    std::vector<int> ret(valid_leaf_num_);
    int idx = 0;
    for (int i = 0; i < tree_branch_num_; i++){
        TreeBranch* tmp_branch_p = branches_pp_[i];
        if (tmp_branch_p == nullptr) continue;
        if (tmp_branch_p->getBranchStatus() == 0) continue;
        int branch_coord_x = (i >> (2*log_level_branch_)) & coord_mask_branch_;
        int branch_coord_y = (i >> log_level_branch_) & coord_mask_branch_;
        int branch_coord_z = i & coord_mask_branch_;
        int leaf_num = tmp_branch_p->getBranchLeafNum();
        for (int j = 0; j < leaf_num; j++){
            TreeLeaf* tmp_leaf_p = tmp_branch_p->getLeafPtrPtr()[j];
            if (tmp_leaf_p != nullptr){
                int leaf_coord_x = (j >> (2*log_level_leaf_)) & coord_mask_leaf_;
                int leaf_coord_y = (j >> log_level_leaf_) & coord_mask_leaf_;
                int leaf_coord_z = j & coord_mask_leaf_;
                int coord_x = (branch_coord_x << log_level_leaf_) | leaf_coord_x;
                int coord_y = (branch_coord_y << log_level_leaf_) | leaf_coord_y;
                int coord_z = (branch_coord_z << log_level_leaf_) | leaf_coord_z;
                int coord = (coord_x << (2*total_log_level_)) | (coord_y << total_log_level_) | coord_z;
                ret[idx] = coord;
                idx ++;
            }
            tmp_leaf_p = nullptr;
        }
        tmp_branch_p = nullptr;
    }
    return ret;
}

bool BaseBiLayerCubicTree::checkLeafSeqLen(int frame_seq_thres){
    for (int i = 0; i < tree_branch_num_; i++){
        TreeBranch* tmp_branch_p = branches_pp_[i];
        if (tmp_branch_p == nullptr) continue;
        if (tmp_branch_p->getBranchStatus() == 0) continue;
        int branch_coord_x = (i >> (2*log_level_branch_)) & coord_mask_branch_;
        int branch_coord_y = (i >> log_level_branch_) & coord_mask_branch_;
        int branch_coord_z = i & coord_mask_branch_;
        int leaf_num = tmp_branch_p->getBranchLeafNum();
        for (int j = 0; j < leaf_num; j++){
            TreeLeaf* tmp_leaf_p = tmp_branch_p->getLeafPtrPtr()[j];
            if (tmp_leaf_p != nullptr){
                if (frame_seq_thres < tmp_leaf_p->accumulateInfo()){
                    delete tmp_leaf_p;
                    valid_leaf_num_ --;
                    tmp_branch_p->getLeafPtrPtr()[j] = nullptr;
                    tmp_branch_p->accumulateValidLeafNum(-1);
                    continue;
                }
            }
            tmp_leaf_p = nullptr;
        }
        if (tmp_branch_p->getBranchValidLeafNum() == 0) tmp_branch_p->updateBranchStatus(char(0));
        tmp_branch_p = nullptr;
    }
    return true;
}

bool BaseBiLayerCubicTree::checkLeafAbsolutePosition(const float &origin_x, const float &origin_y, const float &origin_z, float* leaf_p){
    //leaf coord align to 4
    int idx = 0;
    for (int i = 0; i < tree_branch_num_; i++){
        TreeBranch* tmp_branch_p = branches_pp_[i];
        if (tmp_branch_p == nullptr) continue;
        if (tmp_branch_p->getBranchStatus() == 0) continue;
        int branch_coord_x = (i >> (2*log_level_branch_)) & coord_mask_branch_;
        int branch_coord_y = (i >> log_level_branch_) & coord_mask_branch_;
        int branch_coord_z = i & coord_mask_branch_;
        int leaf_num = tmp_branch_p->getBranchLeafNum();
        for (int j = 0; j < leaf_num; j++){
            TreeLeaf* tmp_leaf_p = tmp_branch_p->getLeafPtrPtr()[j];
            if (tmp_leaf_p != nullptr){
                int leaf_coord_x = (j >> (2*log_level_leaf_)) & coord_mask_leaf_;
                int leaf_coord_y = (j >> log_level_leaf_) & coord_mask_leaf_;
                int leaf_coord_z = j & coord_mask_leaf_;
                int coord_x = (branch_coord_x << log_level_leaf_) | leaf_coord_x;
                int coord_y = (branch_coord_y << log_level_leaf_) | leaf_coord_y;
                int coord_z = (branch_coord_z << log_level_leaf_) | leaf_coord_z;
                leaf_p[idx*4] = static_cast<float>(coord_x) * resolution_ + resolution_ / 2.0f + origin_x;
                leaf_p[idx*4 + 1] = static_cast<float>(coord_y) * resolution_ + resolution_ / 2.0f + origin_y;
                leaf_p[idx*4 + 2] = static_cast<float>(coord_z) * resolution_ + resolution_ / 2.0f + origin_z;
                idx ++;
            }
            tmp_leaf_p = nullptr;
        }
        tmp_branch_p = nullptr;
    }
    // if (idx != valid_leaf_num_) {std::cout<<"check leaf num failed "<<idx<<"!="<<valid_leaf_num_<<std::endl; abort();}
    return true;
}

bool BaseBiLayerCubicTree::deleteVoxel(const float &x, const float &y, const float &z){
    //x,y,z为内部相对坐标，根节点原点默认为0,0,0
    int coord_x = std::min(std::max(static_cast<int>(x / resolution_), 0), direction_max_coord_);
    int coord_y = std::min(std::max(static_cast<int>(y / resolution_), 0), direction_max_coord_);
    int coord_z = std::min(std::max(static_cast<int>(z / resolution_), 0), direction_max_coord_);
    //为了防止精度问题导致坐标溢出
    int coord_branch = ((coord_x >> log_level_leaf_) & coord_mask_branch_) << log_level_branch_;
    coord_branch |= ((coord_y >> log_level_leaf_) & coord_mask_branch_);
    coord_branch <<= log_level_branch_;
    coord_branch |= ((coord_z >> log_level_leaf_) & coord_mask_branch_);
    int coord_leaf = (coord_x & coord_mask_leaf_) << log_level_leaf_;
    coord_leaf |= (coord_y & coord_mask_leaf_);
    coord_leaf <<= log_level_leaf_;
    coord_leaf |= (coord_z & coord_mask_leaf_);
    TreeBranch* tmp_branch_p = branches_pp_[coord_branch];
    if (tmp_branch_p != nullptr){
        TreeLeaf* tmp_leaf_p = tmp_branch_p->getLeafPtrPtr()[coord_leaf];
        if (tmp_leaf_p != nullptr){
            delete tmp_leaf_p;
            tmp_branch_p->getLeafPtrPtr()[coord_leaf] = nullptr;
            tmp_branch_p->accumulateValidLeafNum(-1);
            if (tmp_branch_p->getBranchValidLeafNum() == 0) tmp_branch_p->updateBranchStatus(char(0));
            valid_leaf_num_--;
            return true;
        }
        tmp_leaf_p = nullptr;
    }
    tmp_branch_p = nullptr;
    return false;
}

}



// void deleteVoxelByPreFrameDynamic(){}

// void addVoxelByCurFrame(){}