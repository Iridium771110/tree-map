#include "multitree_common.h"

namespace multitree{

    void tmpRot2Quaternion(const float* rot_p, float* quaternion_p){
    float q0 = sqrt(1.0f + rot_p[0] + rot_p[4] + rot_p[8]) / 2.0f;
    float q1 = (rot_p[5] - rot_p[7]) / (4.0f * q0);
    float q2 = (rot_p[6] - rot_p[2]) / (4.0f * q0);
    float q3 = (rot_p[1] - rot_p[3]) / (4.0f * q0);
    quaternion_p[0] = q0;
    quaternion_p[1] = -q1;
    quaternion_p[2] = -q2;
    quaternion_p[3] = -q3;
    }
    
    void quaternion2Rotation(const float* quaternion_p, float* rotation_p){
        // quarternion = w, x, y, z; rotation = 3x3
        float q0 = quaternion_p[0];
        float q1 = quaternion_p[1];
        float q2 = quaternion_p[2];
        float q3 = quaternion_p[3];
        float d_sqr_q1 = 2.0f * q1 * q1;
        float d_sqr_q2 = 2.0f * q2 * q2;
        float d_sqr_q3 = 2.0f * q3 * q3;
        float d_q0_q1 = 2.0f * q0 * q1;
        float d_q0_q2 = 2.0f * q0 * q2;
        float d_q0_q3 = 2.0f * q0 * q3;
        float d_q1_q2 = 2.0f * q1 * q2;
        float d_q1_q3 = 2.0f * q1 * q3;
        float d_q2_q3 = 2.0f * q2 * q3;
        rotation_p[0] = 1.0f - d_sqr_q2 - d_sqr_q3;
        rotation_p[1] = d_q1_q2 - d_q0_q3;
        rotation_p[2] = d_q1_q3 + d_q0_q2;
        rotation_p[3] = d_q1_q2 + d_q0_q3;
        rotation_p[4] = 1.0f - d_sqr_q1 - d_sqr_q3;
        rotation_p[5] = d_q2_q3 - d_q0_q1;
        rotation_p[6] = d_q1_q3 - d_q0_q2;
        rotation_p[7] = d_q2_q3 + d_q0_q1;
        rotation_p[8] = 1.0f - d_sqr_q1 - d_sqr_q2;
    }

    void ptsTransform(const float* quaternion_p, const float* trans_p, float* xyzi_p, int pts_num, bool inverse){
        //testing, not guaranteed
        std::vector<float> rot_mat(9);
        std::vector<float> trans_mat(3);
        quaternion2Rotation(quaternion_p, rot_mat.data());
        trans_mat[0] = trans_p[0]; trans_mat[1] = trans_p[1]; trans_mat[2] = trans_p[2];
        if (inverse){
            float tmp;
            tmp = rot_mat[1]; rot_mat[1] = rot_mat[3]; rot_mat[3] = tmp;
            tmp = rot_mat[2]; rot_mat[2] = rot_mat[6]; rot_mat[6] = tmp;
            tmp = rot_mat[5]; rot_mat[5] = rot_mat[7]; rot_mat[7] = tmp;
            trans_mat[0] = rot_mat[0]*trans_p[0] + rot_mat[1]*trans_p[1] + rot_mat[2]*trans_p[2];
            trans_mat[1] = rot_mat[3]*trans_p[0] + rot_mat[4]*trans_p[1] + rot_mat[5]*trans_p[2];
            trans_mat[2] = rot_mat[6]*trans_p[0] + rot_mat[7]*trans_p[1] + rot_mat[8]*trans_p[2];
            trans_mat[0] = - trans_mat[0];
            trans_mat[1] = - trans_mat[1];
            trans_mat[2] = - trans_mat[2];
        }
        for (int i = 0; i < pts_num; i++){
            float x = xyzi_p[i*4];
            float y = xyzi_p[i*4 + 1];
            float z = xyzi_p[i*4 + 2];
            xyzi_p[i*4] = rot_mat[0]*x + rot_mat[1]*y + rot_mat[2]*z + trans_mat[0];
            xyzi_p[i*4 + 1] = rot_mat[3]*x + rot_mat[4]*y + rot_mat[5]*z + trans_mat[1];
            xyzi_p[i*4 + 2] = rot_mat[6]*x + rot_mat[7]*y + rot_mat[8]*z + trans_mat[2];
        }
    }
}