#include "multitree_forest.h"
#include <chrono>
namespace multitree
{

BiLayerCubicTreeForest::BiLayerCubicTreeForest(const int &log_root_level_x, const int &log_root_level_y, const int &log_root_level_z, 
                        const int &log_level_branch, const int &log_level_leaf, const int &estimate_pts_num, const int &estimate_voxel_num,
                        const float &resolution, const float &angle_resolution, const int &single_mode,
                        const float &extern_defined_range_x, const float &extern_defined_range_y, const float &extern_defined_range_z)
    :log_root_level_x_(log_root_level_x),
    log_root_level_y_(log_root_level_y),
    log_root_level_z_(log_root_level_z),
    log_level_branch_(log_level_branch),
    log_level_leaf_(log_level_leaf),
    resolution_(resolution),
    single_mode_(single_mode),
    angle_resolution_(angle_resolution){
    roots_num_ = ((1 << log_root_level_x_) << log_root_level_y_) << log_root_level_z_;
    roots_x_num_ = 1 << log_root_level_x_;
    roots_y_num_ = 1 << log_root_level_y_;
    roots_z_num_ = 1 << log_root_level_z_;
    roots_x_mask_ = roots_x_num_ - 1;
    roots_y_mask_ = roots_y_num_ - 1;
    roots_z_mask_ = roots_z_num_ - 1;
    roots_pp_ = new BaseBiLayerCubicTree*[roots_num_];
    for (int i = 0; i < roots_num_; i++) roots_pp_[i] = new BaseBiLayerCubicTree(log_level_branch_, log_level_leaf_, resolution_, single_mode_);
    move_roots_pp_ = new BaseBiLayerCubicTree*[roots_num_];
    for (int i = 0; i < roots_num_; i++) move_roots_pp_[i] = nullptr;
    forest_center_x_ = 0.0f;
    forest_center_y_ = 0.0f;
    forest_center_z_ = 0.0f;
    pre_center_x_ = 0.0f;
    pre_center_y_ = 0.0f;
    pre_center_z_ = 0.0f;
    int root_log_level = log_level_branch_ + log_level_leaf_;
    root_range_ = static_cast<float>(1 << root_log_level) * resolution_;
    range_x_ = root_range_ * static_cast<float>((1 << log_root_level_x_) - 2) / 2.0f;
    range_y_ = root_range_ * static_cast<float>((1 << log_root_level_y_) - 2) / 2.0f;
    range_z_ = root_range_ * static_cast<float>((1 << log_root_level_z_) - 2) / 2.0f;
    if (range_x_ >= extern_defined_range_x) range_x_ = extern_defined_range_x;
    if (range_y_ >= extern_defined_range_y) range_y_ = extern_defined_range_y;
    if (range_z_ >= extern_defined_range_z) range_z_ = extern_defined_range_z;
    forest_min_x_ = - range_x_ - root_range_;
    forest_min_y_ = - range_y_- root_range_;
    forest_min_z_ = - range_z_- root_range_;
    forest_max_x_ = range_x_ + root_range_;
    forest_max_y_ = range_y_ + root_range_;
    forest_max_z_ = range_z_ + root_range_;
    dynamic_leafs_num_ = 0;
    dynamic_pts_.resize(estimate_pts_num * 2 * 4, 0.0f);
    search_angle_id_.resize(9, 0); //注意搜索角度范围固定为1
    horize_angle_pieces_ = static_cast<int>(360.0f / angle_resolution_);
    vertikal_angle_pieces_ = static_cast<int>(180.0f / angle_resolution_);
    angle_total_pieces_ = horize_angle_pieces_ * vertikal_angle_pieces_;
    horize_angle_max_id_ = horize_angle_pieces_ - 1;
    vertikal_angle_max_id_ = vertikal_angle_pieces_ - 1;
    angle_voxel_start_id_.resize(horize_angle_pieces_ * vertikal_angle_pieces_, 0);
    angle_voxel_end_id_.resize(horize_angle_pieces_ * vertikal_angle_pieces_, 0);
    angle_voxel_num_.resize(horize_angle_pieces_ * vertikal_angle_pieces_, 0);
    voxel_xyz_sqr_dist_.resize(estimate_voxel_num * 4);
    voxel_tmp_dist_.resize(estimate_voxel_num);
    voxel_seq_id_.resize(estimate_voxel_num, -1);
    pts_angle_id_.resize(estimate_pts_num, -1);
    pts_xyz_dist_.resize(estimate_pts_num * 4, 0.0f);
    catch_dist_.resize(estimate_voxel_num, 0.0f);
    filtered_pts_status_.resize(estimate_pts_num, 1);
    cur_angle_start_id_.resize(horize_angle_pieces_ * vertikal_angle_pieces_, 0);
    cur_angle_end_id_.resize(horize_angle_pieces_ * vertikal_angle_pieces_, 0);
    cur_angle_pts_num_.resize(horize_angle_pieces_ * vertikal_angle_pieces_, 0);
    cur_pts_angle_id_.resize(estimate_pts_num * 2, -1);
    cur_xyz_sqr_dist_.resize(estimate_pts_num * 2 * 4);
    cur_tmp_dist_.resize(estimate_pts_num * 2);
    cur_catch_dist_.resize(estimate_pts_num * 2, 0.0f);
    pts_seq_id_.resize(estimate_pts_num * 2, -1);
    voxel_angle_id_.resize(estimate_voxel_num * 2, -1);
    voxel_xyz_dist_.resize(estimate_voxel_num * 2 * 4, 0.0f);
    reso2radius_fac_ = (180.0f / angle_resolution_) / M_PI;
    float voxel_filter_pts_occlusion_range_ = 4.0f * resolution_ * resolution_;
    float voxel_filter_line_range_ = 0.25f * resolution_ * resolution_;
    float voxel_filter_catch_dist_threshold_ = 2.0f * resolution_;
    float voxel_filter_catch_angle_threshold_ = 0.09;
    float pts_filter_voxel_occlusion_range_ = resolution_ * resolution_;
    float pts_filter_line_range_ = resolution_ * resolution_;
    float pts_filter_catch_dist_threshold_ = 0.4 * resolution_;
    float pts_filter_catch_angle_threshold_ = 0.09;
}

BiLayerCubicTreeForest::~BiLayerCubicTreeForest(){
    // std::cout<<"forest deconstruct"<<std::endl;
    for (int i = 0; i < roots_num_; i++){
        if (roots_pp_[i] != nullptr){
            delete roots_pp_[i];
            roots_pp_[i] = nullptr;
        }
    }
    delete[] roots_pp_;
    roots_pp_ = nullptr;
    delete[] move_roots_pp_;
    move_roots_pp_ = nullptr;
}

bool BiLayerCubicTreeForest::setOpticalFlowArgs(const int &catch_dist_adjust_mode, const float &catch_dist_angle_factor, 
                            const float &voxel_filter_pts_occlusion_range, const float &voxel_filter_line_range,
                            const float &voxel_filter_catch_dist_threshold, const float &voxel_filter_catch_angle_threshold, 
                            const float &pts_filter_voxel_occlusion_range, const float &pts_filter_line_range, 
                            const float &pts_filter_catch_dist_threshold, const float &pts_filter_catch_angle_threshold){
    catch_dist_adjust_mode_ = catch_dist_adjust_mode;
    catch_dist_angle_factor_ = catch_dist_angle_factor;
    voxel_filter_pts_occlusion_range_ = voxel_filter_pts_occlusion_range * voxel_filter_pts_occlusion_range;
    voxel_filter_line_range_ = voxel_filter_line_range * voxel_filter_line_range;
    voxel_filter_catch_dist_threshold_ = voxel_filter_catch_dist_threshold;
    voxel_filter_catch_angle_threshold_ = voxel_filter_catch_angle_threshold;
    pts_filter_voxel_occlusion_range_ = pts_filter_voxel_occlusion_range * pts_filter_voxel_occlusion_range;
    pts_filter_line_range_ = pts_filter_line_range * pts_filter_line_range;
    pts_filter_catch_dist_threshold_ = pts_filter_catch_dist_threshold;
    pts_filter_catch_angle_threshold_ = pts_filter_catch_angle_threshold;
    return true;
}

bool BiLayerCubicTreeForest::setFlattenArgs(const float &z_min_threshold, const float &z_max_threshold,
                        const float &map_x_range, const float &map_y_range, const float &map_resolution){
    z_min_threshold_ = z_min_threshold;
    z_max_threshold_ = z_max_threshold;
    map_x_range_ = map_x_range;
    map_y_range_ = map_y_range;
    map_resolution_ = map_resolution;
    map_col_limit_ = static_cast<int>(map_x_range_ / map_resolution_);
    map_row_limit_ = static_cast<int>(map_y_range_ / map_resolution_);
    compute_offset_x_ = map_col_limit_ * map_resolution_;
    compute_offset_y_ = map_row_limit_ * map_resolution_;
    map_cols_ = map_col_limit_ * 2;
    map_rows_ = map_row_limit_ * 2;
    map_col_limit_ = map_cols_ - 1;
    map_row_limit_ = map_rows_ - 1;
    flatten_map_.resize(map_rows_ * map_cols_);
    return true;
}

bool BiLayerCubicTreeForest::getFlattenMapSize(int &rows, int &cols){
    rows = map_rows_;
    cols = map_cols_;
    return true;
}

bool BiLayerCubicTreeForest::checkUpdateOriginRangeConstrain(const float &cur_center_x, const float &cur_center_y, const float &cur_center_z){
    int roots_offset_x = static_cast<int>((cur_center_x - forest_center_x_) / root_range_);
    int roots_offset_y = static_cast<int>((cur_center_y - forest_center_y_) / root_range_);
    int roots_offset_z = static_cast<int>((cur_center_z - forest_center_z_) / root_range_);
    if (roots_offset_x != 0 || roots_offset_y != 0 || roots_offset_z != 0){
        for (int i = 0; i < roots_num_; i++){
            int to_roots_id_x = i & roots_x_mask_;
            int to_roots_id_y = (i >> log_root_level_x_) & roots_y_mask_;
            int to_roots_id_z = ((i >> log_root_level_x_) >> log_root_level_y_) & roots_z_mask_;
            int from_roots_id_x = to_roots_id_x + roots_offset_x;
            int from_roots_id_y = to_roots_id_y + roots_offset_y;
            int from_roots_id_z = to_roots_id_z + roots_offset_z;
            int from_roots_id_x_clip = (from_roots_id_x + roots_x_num_) & roots_x_mask_;
            int from_roots_id_y_clip = (from_roots_id_y + roots_y_num_) & roots_y_mask_;
            int from_roots_id_z_clip = (from_roots_id_z + roots_z_num_) & roots_z_mask_;
            int from_roots_id = (((from_roots_id_z_clip << log_root_level_y_) + from_roots_id_y_clip) << log_root_level_x_) + from_roots_id_x_clip;
            BaseBiLayerCubicTree* tmp_root_p = roots_pp_[from_roots_id];
            roots_pp_[from_roots_id] = nullptr;
            if (from_roots_id_x < 0 || from_roots_id_x >= roots_x_num_ 
                || from_roots_id_y < 0 || from_roots_id_y >= roots_y_num_
                || from_roots_id_z < 0 || from_roots_id_z >= roots_z_num_){
                tmp_root_p->resetTree();
            }
            move_roots_pp_[i] = tmp_root_p;
            tmp_root_p = nullptr;
        }
        BaseBiLayerCubicTree** tmp_roots_pp = move_roots_pp_;
        move_roots_pp_ = roots_pp_;
        roots_pp_ = tmp_roots_pp;
        tmp_roots_pp = nullptr;
        forest_center_x_ += static_cast<float>(roots_offset_x) * root_range_;
        forest_center_y_ += static_cast<float>(roots_offset_y) * root_range_;
        forest_center_z_ += static_cast<float>(roots_offset_z) * root_range_;
        forest_min_x_ += static_cast<float>(roots_offset_x) * root_range_;
        forest_min_y_ += static_cast<float>(roots_offset_y) * root_range_;
        forest_min_z_ += static_cast<float>(roots_offset_z) * root_range_;
        forest_max_x_ += static_cast<float>(roots_offset_x) * root_range_;
        forest_max_y_ += static_cast<float>(roots_offset_y) * root_range_;
        forest_max_z_ += static_cast<float>(roots_offset_z) * root_range_;
    }
    
    //往帧删尾巴
    int pre_range_min_x = std::max(static_cast<int>((pre_center_x_ - range_x_ - forest_min_x_) / root_range_), 0);
    int pre_range_min_y = std::max(static_cast<int>((pre_center_y_ - range_y_ - forest_min_y_) / root_range_), 0);
    int pre_range_min_z = std::max(static_cast<int>((pre_center_z_ - range_z_ - forest_min_z_) / root_range_), 0);
    int cur_range_min_x = std::max(static_cast<int>((cur_center_x - range_x_ - forest_min_x_) / root_range_), 0);
    int cur_range_min_y = std::max(static_cast<int>((cur_center_y - range_y_ - forest_min_y_) / root_range_), 0);
    int cur_range_min_z = std::max(static_cast<int>((cur_center_z - range_z_ - forest_min_z_) / root_range_), 0); //移动已经结束，应该只可能是 0,1
    int pre_range_max_x = std::min(static_cast<int>((pre_center_x_ + range_x_ - forest_min_x_) / root_range_), roots_x_mask_);
    int pre_range_max_y = std::min(static_cast<int>((pre_center_y_ + range_y_ - forest_min_y_) / root_range_), roots_y_mask_);
    int pre_range_max_z = std::min(static_cast<int>((pre_center_z_ + range_z_ - forest_min_z_) / root_range_), roots_z_mask_);
    int cur_range_max_x = std::min(static_cast<int>((cur_center_x + range_x_ - forest_min_x_) / root_range_), roots_x_mask_);
    int cur_range_max_y = std::min(static_cast<int>((cur_center_y + range_y_ - forest_min_y_) / root_range_), roots_y_mask_);
    int cur_range_max_z = std::min(static_cast<int>((cur_center_z + range_z_ - forest_min_z_) / root_range_), roots_z_mask_); //移动已经结束，应该只可能是mask,mask-1

    int check_roots_max_x = std::max(pre_range_max_x, cur_range_max_x);
    int check_roots_max_y = std::max(pre_range_max_y, cur_range_max_y);
    int check_roots_max_z = std::max(pre_range_max_z, cur_range_max_z);
    int check_roots_min_x = std::min(pre_range_min_x, cur_range_min_x);
    int check_roots_min_y = std::min(pre_range_min_y, cur_range_min_y);
    int check_roots_min_z = std::min(pre_range_min_z, cur_range_min_z);
    
    if (cur_center_x - pre_center_x_ >= 0) check_roots_max_x = std::max(pre_range_min_x, cur_range_min_x);
    else check_roots_min_x = std::min(pre_range_max_x, cur_range_max_x);
    if (cur_center_y - pre_center_y_ >= 0) check_roots_max_y = std::max(pre_range_min_y, cur_range_min_y);
    else check_roots_min_y = std::min(pre_range_max_y, cur_range_max_y);
    if (cur_center_z - pre_center_z_ >= 0) check_roots_max_z = std::max(pre_range_min_z, cur_range_min_z);
    else check_roots_min_z = std::min(pre_range_max_z, cur_range_max_z);

    // if (roots_offset_x > 0) check_roots_min_x = 0;
    // if (roots_offset_y > 0) check_roots_min_y = 0;
    // if (roots_offset_z > 0) check_roots_min_z = 0;
    // if (roots_offset_x < 0) check_roots_max_x = roots_x_mask_;
    // if (roots_offset_y < 0) check_roots_max_y = roots_y_mask_;
    // if (roots_offset_z < 0) check_roots_max_z = roots_z_mask_; //移动区域后反而要查两个

    int tree_leaf_num = (1 << log_level_branch_) << log_level_leaf_;
    int cur_relative_min_x = std::min(std::max(static_cast<int>((cur_center_x - range_x_ - forest_min_x_) / resolution_), 0), (tree_leaf_num << log_root_level_x_) - 1);
    int cur_relative_min_y = std::min(std::max(static_cast<int>((cur_center_y - range_y_ - forest_min_y_) / resolution_), 0), (tree_leaf_num << log_root_level_y_) - 1);
    int cur_relative_min_z = std::min(std::max(static_cast<int>((cur_center_z - range_z_ - forest_min_z_) / resolution_), 0), (tree_leaf_num << log_root_level_z_) - 1);
    int cur_relative_max_x = std::min(std::max(static_cast<int>((cur_center_x + range_x_ - forest_min_x_) / resolution_), 0), (tree_leaf_num << log_root_level_x_) - 1);
    int cur_relative_max_y = std::min(std::max(static_cast<int>((cur_center_y + range_y_ - forest_min_y_) / resolution_), 0), (tree_leaf_num << log_root_level_y_) - 1);
    int cur_relative_max_z = std::min(std::max(static_cast<int>((cur_center_z + range_z_ - forest_min_z_) / resolution_), 0), (tree_leaf_num << log_root_level_z_) - 1);

    if (cur_center_x - pre_center_x_ >= 0) cur_relative_max_x = (tree_leaf_num << log_root_level_x_) - 1;
    else cur_relative_min_x = 0;
    if (cur_center_y - pre_center_y_ >= 0) cur_relative_max_y = (tree_leaf_num << log_root_level_y_) - 1;
    else cur_relative_min_y = 0;
    if (cur_center_z - pre_center_z_ >= 0) cur_relative_max_z = (tree_leaf_num << log_root_level_z_) - 1;
    else cur_relative_min_z = 0;

    for (int i = 0; i < roots_num_; i++){
        int roots_x = i & roots_x_mask_;
        int roots_y = (i >> log_root_level_x_) & roots_y_mask_;
        int roots_z = ((i >> log_root_level_x_) >> log_root_level_y_) & roots_z_mask_;
        int relative_max_x = std::min(tree_leaf_num, cur_relative_max_x - roots_x * tree_leaf_num + 1);
        int relative_max_y = std::min(tree_leaf_num, cur_relative_max_y - roots_y * tree_leaf_num + 1);
        int relative_max_z = std::min(tree_leaf_num, cur_relative_max_z - roots_z * tree_leaf_num + 1);
        int relative_min_x = std::max(0, cur_relative_min_x - roots_x * tree_leaf_num);
        int relative_min_y = std::max(0, cur_relative_min_y - roots_y * tree_leaf_num);
        int relative_min_z = std::max(0, cur_relative_min_z - roots_z * tree_leaf_num);
        if ((roots_x > check_roots_max_x || roots_x < check_roots_min_x) &&
            (roots_y > check_roots_max_y || roots_y < check_roots_min_y) &&
            (roots_z > check_roots_max_z || roots_z < check_roots_min_z)) continue;
        BaseBiLayerCubicTree* tmp_root_p = roots_pp_[i];
        tmp_root_p->checkCoordRangeConstrain(relative_max_x, relative_max_y, relative_max_z, relative_min_x, relative_min_y, relative_min_z);
        tmp_root_p = nullptr;
    }

    pre_center_x_ = cur_center_x;
    pre_center_y_ = cur_center_y;
    pre_center_z_ = cur_center_z;

    int deleted_num = 0;
    for (int i = 0; i < dynamic_leafs_num_; i++){
        float x = dynamic_pts_[i*4];
        float y = dynamic_pts_[i*4 + 1];
        float z = dynamic_pts_[i*4 + 2];
        if (x > forest_max_x_ || x < forest_min_x_ ||
            y > forest_max_y_ || y < forest_min_y_ ||
            z > forest_max_z_ || z < forest_min_z_) continue;
        float relative_x = x - forest_min_x_;
        float relative_y = y - forest_min_y_;
        float relative_z = z - forest_min_z_;
        int root_x = std::min(std::max(static_cast<int>(relative_x / root_range_), 0), roots_x_mask_);
        int root_y = std::min(std::max(static_cast<int>(relative_y / root_range_), 0), roots_y_mask_);
        int root_z = std::min(std::max(static_cast<int>(relative_z / root_range_), 0), roots_z_mask_);
        relative_x -= root_range_ * static_cast<float>(root_x);
        relative_y -= root_range_ * static_cast<float>(root_y);
        relative_z -= root_range_ * static_cast<float>(root_z);
        int root_id = (root_z << log_root_level_y_) | root_y;
        root_id <<= log_root_level_x_;
        root_id |= root_x;
        deleted_num += roots_pp_[root_id]->deleteVoxel(relative_x, relative_y, relative_z);
    }
    dynamic_leafs_num_ = 0;
    deleted_num = 0;

    return true;
}

// bool BiLayerCubicTreeForest::checkRangeConstrain(const float &cur_center_x, const float &cur_center_y, const float &cur_center_z){

// }

int BiLayerCubicTreeForest::getPointRootId(const float &pts_x, const float &pts_y, const float &pts_z){
    int root_x = std::min(std::max(static_cast<int>((pts_x - forest_min_x_) / root_range_), 0), roots_x_mask_);
    int root_y = std::min(std::max(static_cast<int>((pts_y - forest_min_y_) / root_range_), 0), roots_y_mask_);
    int root_z = std::min(std::max(static_cast<int>((pts_z - forest_min_z_) / root_range_), 0), roots_z_mask_);
    int root_id = (root_z << log_root_level_y_) | root_y;
    root_id <<= log_root_level_x_;
    root_id |= root_x;
    return root_id;
}

bool BiLayerCubicTreeForest::addFrame(const float &cur_center_x, const float &cur_center_y, const float &cur_center_z, float* pts_p, const int &pts_num){
    //默认输入为 xyzi
    if (single_mode_ == 1){
        for (int i = 0; i < roots_num_; i++) roots_pp_[i]->resetTree();
    }
    float detective_min_x = cur_center_x - range_x_; 
    float detective_max_x = cur_center_x + range_x_;
    float detective_min_y = cur_center_y - range_y_; 
    float detective_max_y = cur_center_y + range_y_;
    float detective_min_z = cur_center_z - range_z_; 
    float detective_max_z = cur_center_z + range_z_;
    for (int i = 0; i < pts_num; i++){
        float pts_x = pts_p[i*4];
        float pts_y = pts_p[i*4 + 1];
        float pts_z = pts_p[i*4 + 2];
        if (pts_x <= detective_min_x || pts_x >= detective_max_x ||
            pts_y <= detective_min_y || pts_y >= detective_max_y ||
            pts_z <= detective_min_z || pts_z >= detective_max_z) continue;
        float relative_x = pts_x - forest_min_x_;
        float relative_y = pts_y - forest_min_y_;
        float relative_z = pts_z - forest_min_z_;
        int root_x = std::min(std::max(static_cast<int>(relative_x / root_range_), 0), roots_x_mask_);
        int root_y = std::min(std::max(static_cast<int>(relative_y / root_range_), 0), roots_y_mask_);
        int root_z = std::min(std::max(static_cast<int>(relative_z / root_range_), 0), roots_z_mask_);
        relative_x -= root_range_ * static_cast<float>(root_x);
        relative_y -= root_range_ * static_cast<float>(root_y);
        relative_z -= root_range_ * static_cast<float>(root_z);
        int root_id = (root_z << log_root_level_y_) | root_y;
        root_id <<= log_root_level_x_;
        root_id |= root_x;
        roots_pp_[root_id]->addPoint(relative_x, relative_y, relative_z);
    }
    return true;
}

bool BiLayerCubicTreeForest::addFrameUpdateDynamic(const float* pts_p, const char* pts_status_p, const int &pts_num,
                            // const float &cur_center_x, const float &cur_center_y, const float &cur_center_z, std::vector<float> &check){
                            const float &cur_center_x, const float &cur_center_y, const float &cur_center_z){
    //默认输入为 xyzi
    if (single_mode_ == 1){
        for (int i = 0; i < roots_num_; i++) roots_pp_[i]->resetTree();
    }
    std::vector<TreeLeaf*> pts_relative_additional_leafs_p(pts_num, nullptr);
    int additional_leafs_num = 0;
    float detective_min_x = cur_center_x - range_x_; 
    float detective_max_x = cur_center_x + range_x_;
    float detective_min_y = cur_center_y - range_y_; 
    float detective_max_y = cur_center_y + range_y_;
    float detective_min_z = cur_center_z - range_z_; 
    float detective_max_z = cur_center_z + range_z_;
    for (int i = 0; i < pts_num; i++){
        float pts_x = pts_p[i*4];
        float pts_y = pts_p[i*4 + 1];
        float pts_z = pts_p[i*4 + 2];
        if (pts_x <= detective_min_x || pts_x >= detective_max_x ||
            pts_y <= detective_min_y || pts_y >= detective_max_y ||
            pts_z <= detective_min_z || pts_z >= detective_max_z) continue;
        float relative_x = pts_x - forest_min_x_;
        float relative_y = pts_y - forest_min_y_;
        float relative_z = pts_z - forest_min_z_;
        int root_x = std::min(std::max(static_cast<int>(relative_x / root_range_), 0), roots_x_mask_);
        int root_y = std::min(std::max(static_cast<int>(relative_y / root_range_), 0), roots_y_mask_);
        int root_z = std::min(std::max(static_cast<int>(relative_z / root_range_), 0), roots_z_mask_);
        relative_x -= root_range_ * static_cast<float>(root_x);
        relative_y -= root_range_ * static_cast<float>(root_y);
        relative_z -= root_range_ * static_cast<float>(root_z);
        int root_id = (root_z << log_root_level_y_) | root_y;
        root_id <<= log_root_level_x_;
        root_id |= root_x;
        TreeLeaf* tmp_leaf_p = roots_pp_[root_id]->addPointAndDynamicStatus(relative_x, relative_y, relative_z, pts_status_p[i]);
        pts_relative_additional_leafs_p[i] = tmp_leaf_p;
        if (tmp_leaf_p != nullptr) additional_leafs_num++;
        tmp_leaf_p = nullptr;
    }
    // std::cout<<"finish add cur frame"<<std::endl;
    // int deleted_num = 0;
    // for (int i = 0; i < dynamic_leafs_num_; i++){
    //     float x = dynamic_pts_[i*4];
    //     float y = dynamic_pts_[i*4 + 1];
    //     float z = dynamic_pts_[i*4 + 2];
    //     if (x > forest_max_x_ || x < forest_min_x_ ||
    //         y > forest_max_y_ || y < forest_min_y_ ||
    //         z > forest_max_z_ || z < forest_min_z_) continue;
    //     float relative_x = x - forest_min_x_;
    //     float relative_y = y - forest_min_y_;
    //     float relative_z = z - forest_min_z_;
    //     int root_x = std::min(std::max(static_cast<int>(relative_x / root_range_), 0), roots_x_mask_);
    //     int root_y = std::min(std::max(static_cast<int>(relative_y / root_range_), 0), roots_y_mask_);
    //     int root_z = std::min(std::max(static_cast<int>(relative_z / root_range_), 0), roots_z_mask_);
    //     relative_x -= root_range_ * static_cast<float>(root_x);
    //     relative_y -= root_range_ * static_cast<float>(root_y);
    //     relative_z -= root_range_ * static_cast<float>(root_z);
    //     int root_id = (root_z << log_root_level_y_) | root_y;
    //     root_id <<= log_root_level_x_;
    //     root_id |= root_x;
    //     deleted_num += roots_pp_[root_id]->deleteVoxel(relative_x, relative_y, relative_z);
    // }
    // // std::cout<<"finish deleted pre-dynamic "<<dynamic_leafs_num_<<' '<<deleted_num<<std::endl;
    // dynamic_leafs_num_ = 0;
    // deleted_num = 0;
    if (additional_leafs_num > dynamic_pts_.size() / 4) dynamic_pts_.resize(additional_leafs_num*2*4);
    for (int i = 0; i < pts_num; i++){
        TreeLeaf* tmp_leaf_p = pts_relative_additional_leafs_p[i];
        if (tmp_leaf_p == nullptr) continue;
        if (tmp_leaf_p->getLeafStatus() == 0){
            dynamic_pts_[dynamic_leafs_num_*4] = pts_p[i*4];
            dynamic_pts_[dynamic_leafs_num_*4 + 1] = pts_p[i*4 + 1];
            dynamic_pts_[dynamic_leafs_num_*4 + 2] = pts_p[i*4 + 2];
            dynamic_leafs_num_++;
        }
        tmp_leaf_p = nullptr;
    }
    // std::cout<<"finish update cur-dynamic "<<std::endl;
    return true;                            
}

std::vector<float> BiLayerCubicTreeForest::checkAllLeafAbsolutePosition(const int & frame_seq_thres){
    if (frame_seq_thres > 0) for (int i = 0; i < roots_num_; i++) roots_pp_[i]->checkLeafSeqLen(frame_seq_thres);
    int total_voxels_num = 0;
    for (int i = 0; i < roots_num_; i++) total_voxels_num += roots_pp_[i]->getValidLeafNum();
    // std::cout << "valid leaf total: "<<total_voxels_num<<std::endl;
    std::vector<float> ret(total_voxels_num*4, 0.0f);
    int cur_num = 0;
    for (int i = 0; i < roots_num_; i++){
        int cur_root_leaf_num = roots_pp_[i]->getValidLeafNum();
        if (cur_root_leaf_num == 0) continue;
        int roots_x = i & roots_x_mask_;
        int roots_y = (i >> log_root_level_x_) & roots_y_mask_;
        int roots_z = ((i >> log_root_level_x_) >> log_root_level_y_) & roots_z_mask_;
        float root_origin_x = forest_min_x_ + static_cast<float>(roots_x) * root_range_;
        float root_origin_y = forest_min_y_ + static_cast<float>(roots_y) * root_range_;
        float root_origin_z = forest_min_z_ + static_cast<float>(roots_z) * root_range_;
        roots_pp_[i]->checkLeafAbsolutePosition(root_origin_x, root_origin_y, root_origin_z, ret.data() + cur_num * 4);
        cur_num += cur_root_leaf_num;
    }
    return ret;
}

std::vector<float> BiLayerCubicTreeForest::checkAllLeafRelativePosition(const float* quaternion_p, 
                                                    const bool &rotate){
    //因为旋转的麻烦以及会导致位置错位等问题，当前仅考虑平移变换
    //注意给定的变换是初始系到目标系的变换，所求的是初始系坐标变换为目标系坐标
    int total_voxels_num = 0;
    for (int i = 0; i < roots_num_; i++) total_voxels_num += roots_pp_[i]->getValidLeafNum();
    // std::cout << "valid leaf total: "<<total_voxels_num<<std::endl;
    std::vector<float> ret(total_voxels_num*4, 0.0f);
    int cur_num = 0;
    for (int i = 0; i < roots_num_; i++){
        int cur_root_leaf_num = roots_pp_[i]->getValidLeafNum();
        if (cur_root_leaf_num == 0) continue;
        int roots_x = i & roots_x_mask_;
        int roots_y = (i >> log_root_level_x_) & roots_y_mask_;
        int roots_z = ((i >> log_root_level_x_) >> log_root_level_y_) & roots_z_mask_;
        float root_origin_x = -range_x_ + static_cast<float>(roots_x - 1) * root_range_ + forest_center_x_ - pre_center_x_;
        float root_origin_y = -range_y_ + static_cast<float>(roots_y - 1) * root_range_ + forest_center_y_ - pre_center_y_;
        float root_origin_z = -range_z_ + static_cast<float>(roots_z - 1) * root_range_ + forest_center_z_ - pre_center_z_;
        roots_pp_[i]->checkLeafAbsolutePosition(root_origin_x, root_origin_y, root_origin_z, ret.data() + cur_num * 4);
        cur_num += cur_root_leaf_num;
    }
    //这里做了解耦，理论上可以进行耦合
    if (rotate){
        std::vector<float> rotation(9);
        quaternion2Rotation(quaternion_p, rotation.data());
        for (int i = 0; i < cur_num; i++){
            float x = ret[i*4];
            float y = ret[i*4 + 1];
            float z = ret[i*4 + 2];
            ret[i*4] = rotation[0] * x + rotation[3] * y + rotation[6] * z;
            ret[i*4 + 1] = rotation[1] * x + rotation[4] * y + rotation[7] * z;
            ret[i*4 + 2] = rotation[2] * x + rotation[5] * y + rotation[8] * z;
        }
    }
    return ret;
}

std::vector<float> BiLayerCubicTreeForest::checkAllLeafRelativePositionRotMat(const float* rotation_p, 
                                                    const bool &rotate){
    //因为旋转的麻烦以及会导致位置错位等问题，当前仅考虑平移变换
    //注意给定的变换是初始系到目标系的变换，所求的是初始系坐标变换为目标系坐标
    int total_voxels_num = 0;
    for (int i = 0; i < roots_num_; i++) total_voxels_num += roots_pp_[i]->getValidLeafNum();
    // std::cout << "valid leaf total: "<<total_voxels_num<<std::endl;
    std::vector<float> ret(total_voxels_num*4, 0.0f);
    int cur_num = 0;
    for (int i = 0; i < roots_num_; i++){
        int cur_root_leaf_num = roots_pp_[i]->getValidLeafNum();
        if (cur_root_leaf_num == 0) continue;
        int roots_x = i & roots_x_mask_;
        int roots_y = (i >> log_root_level_x_) & roots_y_mask_;
        int roots_z = ((i >> log_root_level_x_) >> log_root_level_y_) & roots_z_mask_;
        float root_origin_x = -range_x_ + static_cast<float>(roots_x - 1) * root_range_ + forest_center_x_ - pre_center_x_;
        float root_origin_y = -range_y_ + static_cast<float>(roots_y - 1) * root_range_ + forest_center_y_ - pre_center_y_;
        float root_origin_z = -range_z_ + static_cast<float>(roots_z - 1) * root_range_ + forest_center_z_ - pre_center_z_;
        roots_pp_[i]->checkLeafAbsolutePosition(root_origin_x, root_origin_y, root_origin_z, ret.data() + cur_num * 4);
        cur_num += cur_root_leaf_num;
    }
    //这里做了解耦，理论上可以进行耦合
    if (rotate){
        for (int i = 0; i < cur_num; i++){
            float x = ret[i*4];
            float y = ret[i*4 + 1];
            float z = ret[i*4 + 2];
            ret[i*4] = rotation_p[0] * x + rotation_p[3] * y + rotation_p[6] * z;
            ret[i*4 + 1] = rotation_p[1] * x + rotation_p[4] * y + rotation_p[7] * z;
            ret[i*4 + 2] = rotation_p[2] * x + rotation_p[5] * y + rotation_p[8] * z;
        }
    }
    return ret;
}

const char* BiLayerCubicTreeForest::getFlattenMapFromVoxel(const float* voxel_p, const int &voxel_num, int &map_rows, int &map_cols, int &valid_grids_num){
    //voxel align to 4
    if (map_cols != map_cols_ || map_rows != map_rows_){
        map_cols = map_cols_;
        map_rows = map_rows_;
        std::cout<<"warning: excepted map row & col inconsistent, now set them to row="<<map_rows<<", col="<<map_cols<<std::endl;
    }
    valid_grids_num = 0;
    std::memset(flatten_map_.data(), 0, sizeof(char)*flatten_map_.size());
    for (int i = 0; i < voxel_num; i++){
        float voxel_x = voxel_p[i*4];
        float voxel_y = voxel_p[i*4 + 1];
        float voxel_z = voxel_p[i*4 + 2];
        if (voxel_z < z_min_threshold_ || voxel_z > z_max_threshold_) continue;
        if (voxel_x < -map_x_range_ || voxel_x > map_x_range_ || voxel_y < -map_y_range_ || voxel_y > map_y_range_) continue;
        int row = std::max(0, std::min(map_row_limit_, static_cast<int>((compute_offset_y_ + voxel_y) / map_resolution_)));
        int col = std::max(0, std::min(map_col_limit_, static_cast<int>((compute_offset_x_ + voxel_x) / map_resolution_)));
        valid_grids_num += (1 - std::min(1, static_cast<int>(flatten_map_[row * map_cols_ + col])));
        flatten_map_[row * map_cols_ + col] = std::min(127, flatten_map_[row * map_cols_ + col] + 1);
    }
    // std::cout<<valid_grids_num<<' '<<z_min_threshold_<<' '<<z_max_threshold_<<std::endl;
    return flatten_map_.data();
}

//朴素三维光追
//当前帧射线角度分区，原有网格中心在当前原点射线角度分区
//当前帧射线追踪距离判定-->按射线角度邻近，搜索点线距离小于网格半对角线长（大致）
//原网格按当前帧射线判定删节-->仅按照射线角度邻近，以网格中心点距离判定
//当前帧所有格添加（即addFrame）



inline void BiLayerCubicTreeForest::updateCatchDist(float* xyz_sqr_dist_p, int start_id, int end_id, float range_threshold_sqr,
                    float line_x, float line_y, float line_z, float sqr_line_dist_origin_fac, float &sqr_line_dist){
    for (int i = start_id; i < end_id; i++){
        float x = xyz_sqr_dist_p[i*4];
        float y = xyz_sqr_dist_p[i*4 + 1];
        float z = xyz_sqr_dist_p[i*4 + 2];
        // float sqr_dist = x*x + y*y + z*z;
        float sqr_dist = xyz_sqr_dist_p[i*4 + 3];
        float dot_line_pts = (x*line_x + y*line_y + z*line_z);
        float sqr_len_cos = dot_line_pts * dot_line_pts * sqr_line_dist_origin_fac;
        float sqr_pts_line_dist = sqr_dist - sqr_len_cos;
        if (sqr_pts_line_dist < range_threshold_sqr) sqr_line_dist = std::min(sqr_line_dist, sqr_dist + sqr_pts_line_dist); //可以对参数实行调整
    }
}

inline char BiLayerCubicTreeForest::updateFilteredOutVoxel(float* line_xyz_sqr_dist_p, float* line_catch_dist_p, int start_id, int end_id, 
                            float voxel_x, float voxel_y, float voxel_z, float voxel_dist, float sqr_dist,
                            float range_threshold_sqr, float catch_dist_threshold, float angle_ref_threshold){
    //
    for (int i = start_id; i < end_id; i++){
        float line_x = line_xyz_sqr_dist_p[i*4];
        float line_y = line_xyz_sqr_dist_p[i*4 + 1];
        float line_z = line_xyz_sqr_dist_p[i*4 + 2];
        float sqr_line_dist = line_xyz_sqr_dist_p[i*4 + 3];
        float dot_line_voxel = (line_x*voxel_x + line_y*voxel_y + line_z*voxel_z);
        float sqr_len_cos = dot_line_voxel * dot_line_voxel / sqr_line_dist;
        float sqr_voxel_line_dist = sqr_dist - sqr_len_cos;
        float voxel_catch_angle_ref = sqr_voxel_line_dist / (sqr_line_dist + sqr_dist - 2.0f * dot_line_voxel);
        float voxel_catch_dist_ref = line_catch_dist_p[i] - voxel_dist;
        if (sqr_voxel_line_dist < range_threshold_sqr && 
            ((voxel_catch_dist_ref > catch_dist_threshold && voxel_catch_angle_ref > angle_ref_threshold) 
            || (voxel_catch_dist_ref > catch_dist_angle_factor_*catch_dist_threshold))
            ){ //可以对参数实行调整，或者改成投票制？
            return 1;
        }
    }
    return 0;
}

inline bool BiLayerCubicTreeForest::getSearchAngleId(const int &vertikal_angle_id, const int &horize_angle_id){
    //角度可以考虑切分为二进制，方便使用位操作？
    int vertikal_offset_0 = std::max(vertikal_angle_id - 1, 0) * horize_angle_pieces_;
    int vertikal_offset_1 = vertikal_angle_id * horize_angle_pieces_;
    int vertikal_offset_2 = std::min(vertikal_angle_id + 1, vertikal_angle_max_id_) * horize_angle_pieces_;
    int horize_offset_base = horize_angle_id + horize_angle_pieces_ - 1;
    int horize_offset_0 = (horize_offset_base - 1) % horize_angle_pieces_;
    int horize_offset_1 = horize_offset_base % horize_angle_pieces_;
    int horize_offset_2 = (horize_offset_base + 1) % horize_angle_pieces_;
    search_angle_id_[0] = vertikal_offset_0 + horize_offset_0;
    search_angle_id_[1] = vertikal_offset_0 + horize_offset_1;
    search_angle_id_[2] = vertikal_offset_0 + horize_offset_2;
    search_angle_id_[3] = vertikal_offset_1 + horize_offset_0;
    search_angle_id_[4] = vertikal_offset_1 + horize_offset_1;
    search_angle_id_[5] = vertikal_offset_1 + horize_offset_2;
    search_angle_id_[6] = vertikal_offset_2 + horize_offset_0;
    search_angle_id_[7] = vertikal_offset_2 + horize_offset_1;
    search_angle_id_[8] = vertikal_offset_2 + horize_offset_2;
    return true;
}

bool BiLayerCubicTreeForest::setupStartEndId(int* start_id_p, int* end_id_p, int* num_p){
    int cur_start = 0;
    for (int i = 0; i < angle_total_pieces_; i++){
        if (num_p[i] != 0){
            start_id_p[i] = cur_start;
            cur_start += num_p[i];
            end_id_p[i] = cur_start;
            num_p[i] = 0;
        }
    }
    return true;
}

bool BiLayerCubicTreeForest::setupAngleDist(float center_x, float center_y, float center_z, int coord_num,
                                            const float* coord_p, float* tmp_dist_p, int* angle_coord_num_p, int* coord_angle_id_p){
    for (int i = 0; i < coord_num; i++){
        float x = coord_p[i*4] - center_x;
        float y = coord_p[i*4 + 1] - center_y;
        float z = coord_p[i*4 + 2] - center_z; //注意voxel当前是 3*float，后面可能需要对齐到4*float
        float horize_dist = std::sqrt(x*x + y*y);
        //头顶和底部不考虑在内，理论上不应在本帧出现水平距离0
        if (horize_dist <= 1e-5f) continue; //使angle_id=-1，无效
        float dist = std::sqrt(x*x + y*y + z*z);
        float horize_angle = std::acos(x / horize_dist);
        if (y < 0) horize_angle = 2.0f*M_PI - horize_angle;
        int horize_angle_id = std::max(0, std::min(static_cast<int>(horize_angle * reso2radius_fac_), horize_angle_max_id_));
        // int horize_angle_id = static_cast<int>(horize_angle * reso2radius_fac_);
        // rangeConstrain<int>(0, horize_angle_max_id_, &horize_angle_id);
        float vertikal_angle = std::acos(horize_dist / dist);
        int vertikal_angle_id = std::max(0, std::min(static_cast<int>(vertikal_angle * reso2radius_fac_), vertikal_angle_max_id_));
        int angle_id = (vertikal_angle_id << 16) | (horize_angle_id & 0xffff);
        angle_coord_num_p[vertikal_angle_id * horize_angle_pieces_ + horize_angle_id] += 1;
        tmp_dist_p[i] = dist;
        coord_angle_id_p[i] = angle_id;
    }
    return true;
}

bool BiLayerCubicTreeForest::filterVoxelByCurFrame(const float &cur_center_x, const float &cur_center_y, const float &cur_center_z,
                                const float* voxels_p, const float* pts_p, const int &voxels_num, const int &pts_num){
    //默认输入为 xyzi
    //本步应当位于坐标移动后，添加帧格前
    if (cur_pts_angle_id_.size() < pts_num){
        cur_pts_angle_id_.resize(pts_num * 2);
        cur_xyz_sqr_dist_.resize(pts_num * 2 * 4);
        cur_tmp_dist_.resize(pts_num * 2);
        pts_seq_id_.resize(pts_num * 2);
        cur_catch_dist_.resize(pts_num * 2);
    }
    if (voxel_xyz_dist_.size() / 4 < voxels_num){
        voxel_angle_id_.resize(voxels_num * 2);
        voxel_xyz_dist_.resize(voxels_num * 2 * 4);
    }
    std::memset(cur_angle_start_id_.data(), 0, sizeof(int)*cur_angle_start_id_.size());
    std::memset(cur_angle_end_id_.data(), 0, sizeof(int)*cur_angle_end_id_.size());
    std::memset(cur_angle_pts_num_.data(), 0, sizeof(int)*cur_angle_pts_num_.size());
    std::memset(cur_pts_angle_id_.data(), -1, sizeof(int) * pts_num);
    std::memset(voxel_angle_id_.data(), -1, sizeof(int) * voxels_num);
    setupAngleDist(cur_center_x, cur_center_y, cur_center_z, pts_num,
                    pts_p, cur_tmp_dist_.data(), cur_angle_pts_num_.data(), cur_pts_angle_id_.data());
    setupStartEndId(cur_angle_start_id_.data(), cur_angle_end_id_.data(), cur_angle_pts_num_.data());
    for (int i = 0; i < pts_num; i++){
        int angle_id = cur_pts_angle_id_[i];
        if (angle_id == -1) continue;
        int horize_angle_id = angle_id & 0xffff;
        int vertikal_angle_id = (angle_id >> 16) & 0xffff;
        angle_id = vertikal_angle_id * horize_angle_pieces_ + horize_angle_id;
        int cur_pts_seq_id = cur_angle_start_id_[angle_id] + cur_angle_pts_num_[angle_id];
        cur_angle_pts_num_[angle_id] ++;
        cur_xyz_sqr_dist_[cur_pts_seq_id * 4] = pts_p[i*4] - cur_center_x;
        cur_xyz_sqr_dist_[cur_pts_seq_id * 4 + 1] = pts_p[i*4 + 1] - cur_center_y;
        cur_xyz_sqr_dist_[cur_pts_seq_id * 4 + 2] = pts_p[i*4 + 2] - cur_center_z;
        cur_xyz_sqr_dist_[cur_pts_seq_id * 4 + 3] = cur_tmp_dist_[i] * cur_tmp_dist_[i];
        pts_seq_id_[i] = cur_pts_seq_id;
    }
    // std::cout<<"finish frame angle seg"<<std::endl;
    if (catch_dist_adjust_mode_){
        for (int i = 0; i < pts_num; i++){
            float tmp_catch_dist = cur_tmp_dist_[i] * cur_tmp_dist_[i];
            int angle_id = cur_pts_angle_id_[i];
            if (angle_id == -1) continue;
            int horize_angle_id = angle_id & 0xffff;
            int vertikal_angle_id = (angle_id >> 16) & 0xffff;
            getSearchAngleId(vertikal_angle_id, horize_angle_id);
            float line_x = pts_p[i*4] - cur_center_x;
            float line_y = pts_p[i*4 + 1] - cur_center_y;
            float line_z = pts_p[i*4 + 2] - cur_center_z;
            float sqr_line_dist_origin_fac = 1.0f / tmp_catch_dist;
            for (int j = 0; j < search_angle_id_.size(); j++){
                int search_angle_id = search_angle_id_[j];
                updateCatchDist(cur_xyz_sqr_dist_.data(), cur_angle_start_id_[search_angle_id], cur_angle_end_id_[search_angle_id],
                    voxel_filter_pts_occlusion_range_, line_x, line_y, line_z, sqr_line_dist_origin_fac, tmp_catch_dist);
            }
            cur_catch_dist_[pts_seq_id_[i]] = std::sqrt(tmp_catch_dist);
        }
    }   
    else{
        for (int i = 0; i < pts_num; i++){
            int angle_id = cur_pts_angle_id_[i];
            if (angle_id == -1) continue;
            cur_catch_dist_[pts_seq_id_[i]] = cur_tmp_dist_[i];
        }
    }
    // std::cout<<"finish frame angle dist adjust"<<std::endl;
    for (int i = 0; i < voxels_num; i++){
        float x = voxels_p[i*4] - cur_center_x;
        float y = voxels_p[i*4 + 1] - cur_center_y;
        float z = voxels_p[i*4 + 2] - cur_center_z; //注意voxel需要对齐到4*float
        float horize_dist = std::sqrt(x*x + y*y);
        //头顶和底部不考虑在内，理论上不应在本帧出现水平距离0
        if (horize_dist <= 1e-5f) continue; //使angle_id=-1，无效
        float dist = std::sqrt(x*x + y*y + z*z);
        float horize_angle = std::acos(x / horize_dist);
        if (y < 0) horize_angle = 2.0f*M_PI - horize_angle;
        int horize_angle_id = std::max(0, std::min(static_cast<int>(horize_angle * reso2radius_fac_), horize_angle_max_id_));
        float vertikal_angle = std::acos(horize_dist / dist);
        int vertikal_angle_id = std::max(0, std::min(static_cast<int>(vertikal_angle * reso2radius_fac_), vertikal_angle_max_id_));
        int angle_id = (vertikal_angle_id << 16) | (horize_angle_id & 0xffff);
        voxel_xyz_dist_[i*4] = x;
        voxel_xyz_dist_[i*4 + 1] = y;
        voxel_xyz_dist_[i*4 + 2] = z;
        voxel_xyz_dist_[i*4 + 3] = dist;
        voxel_angle_id_[i] = angle_id;
    }
    float* filtered_out_voxels_p = voxel_xyz_dist_.data();
    int filtered_out_voxel_num = 0;
    for (int i = 0; i < voxels_num; i++){
        int angle_id = voxel_angle_id_[i];
        if (angle_id == -1) continue; 
        int horize_angle_id = angle_id & 0xffff;
        int vertikal_angle_id = (angle_id >> 16) & 0xffff;
        getSearchAngleId(vertikal_angle_id, horize_angle_id);
        float voxel_x = voxel_xyz_dist_[i*4];
        float voxel_y = voxel_xyz_dist_[i*4 + 1];
        float voxel_z = voxel_xyz_dist_[i*4 + 2];
        float voxel_dist = voxel_xyz_dist_[i*4 + 3];
        float sqr_dist = voxel_dist * voxel_dist;
        for (int j = 0; j < search_angle_id_.size(); j++){
            int search_angle_id = search_angle_id_[j];
            char catched = updateFilteredOutVoxel(cur_xyz_sqr_dist_.data(), cur_catch_dist_.data(),
                                    cur_angle_start_id_[search_angle_id], cur_angle_end_id_[search_angle_id],
                                    voxel_x, voxel_y, voxel_z, voxel_dist, sqr_dist,
                                    voxel_filter_line_range_, voxel_filter_catch_dist_threshold_, voxel_filter_catch_angle_threshold_);
            if (catched == 1){
                filtered_out_voxels_p[filtered_out_voxel_num*4] = voxel_x;
                filtered_out_voxels_p[filtered_out_voxel_num*4 + 1] = voxel_y;
                filtered_out_voxels_p[filtered_out_voxel_num*4 + 2] = voxel_z;
                filtered_out_voxel_num ++;
                break;
            } 
        }
    }

    // std::cout<<"finish voxel extract "<<voxels_num<<' '<<filtered_out_voxel_num<<std::endl;
    //以上完成去除网格提取
    //后续进行剔除
    int deleted_num = 0;
    for (int i = 0; i < filtered_out_voxel_num; i++){
        float voxel_x = filtered_out_voxels_p[i*4] + cur_center_x;
        float voxel_y = filtered_out_voxels_p[i*4 + 1] + cur_center_y;
        float voxel_z = filtered_out_voxels_p[i*4 + 2] + cur_center_z;
        if (voxel_x > forest_max_x_ || voxel_x < forest_min_x_ ||
            voxel_y > forest_max_y_ || voxel_y < forest_min_y_ ||
            voxel_z > forest_max_z_ || voxel_z < forest_min_z_) continue;
        float relative_x = voxel_x - forest_min_x_;
        float relative_y = voxel_y - forest_min_y_;
        float relative_z = voxel_z - forest_min_z_;
        int root_x = std::min(std::max(static_cast<int>(relative_x / root_range_), 0), roots_x_mask_);
        int root_y = std::min(std::max(static_cast<int>(relative_y / root_range_), 0), roots_y_mask_);
        int root_z = std::min(std::max(static_cast<int>(relative_z / root_range_), 0), roots_z_mask_);
        relative_x -= root_range_ * static_cast<float>(root_x);
        relative_y -= root_range_ * static_cast<float>(root_y);
        relative_z -= root_range_ * static_cast<float>(root_z);
        int root_id = (root_z << log_root_level_y_) | root_y;
        root_id <<= log_root_level_x_;
        root_id |= root_x;
        deleted_num += roots_pp_[root_id]->deleteVoxel(relative_x, relative_y, relative_z);
    }
    int total_voxels_num = 0;
    for (int i = 0; i < roots_num_; i++) {total_voxels_num += roots_pp_[i]->getValidLeafNum();
    if (roots_pp_[i]->getValidLeafNum() < 0) std::cout <<"invalid tree leaf num: "<<roots_pp_[i]->getValidLeafNum()<<std::endl;}
    if (deleted_num != filtered_out_voxel_num){std::cout<<"check failed in delete "<<deleted_num<<':'<<filtered_out_voxel_num<<std::endl;abort();}
    // std::cout<<"finish voxel delete "<<total_voxels_num<<' '<<deleted_num<<std::endl;
    return true;
}

std::vector<char> BiLayerCubicTreeForest::curFrameRecordDynamic(const float &last_center_x, const float &last_center_y, const float &last_center_z,
                                const float* voxels_p, const float* pts_p, const int &voxels_num, const int &pts_num){
    //更新后的网格对当前帧进行标记，应当使用前一帧坐标原点
    //默认输入为 xyzi
    //本步应当位于坐标移动后，添加帧格前
    if (voxel_tmp_dist_.size() < voxels_num){
        voxel_angle_id_.resize(voxels_num * 2);
        voxel_xyz_sqr_dist_.resize(voxels_num * 2 * 4);
        voxel_tmp_dist_.resize(voxels_num * 2);
        voxel_seq_id_.resize(voxels_num * 2);
        catch_dist_.resize(voxels_num * 2);
    }
    if (pts_angle_id_.size() < pts_num){
        pts_angle_id_.resize(pts_num * 2);
        pts_xyz_dist_.resize(pts_num * 2 * 4);
        filtered_pts_status_.resize(pts_num * 2);
    }
    std::memset(angle_voxel_start_id_.data(), 0, sizeof(int)*angle_voxel_start_id_.size());
    std::memset(angle_voxel_end_id_.data(), 0, sizeof(int)*angle_voxel_end_id_.size());
    std::memset(angle_voxel_num_.data(), 0, sizeof(int)*angle_voxel_num_.size());
    std::memset(voxel_angle_id_.data(), -1, sizeof(int)*voxels_num);
    std::memset(pts_angle_id_.data(), -1, sizeof(int)*pts_num);
    std::memset(filtered_pts_status_.data(), 1, sizeof(char)*pts_num);
    for (int i = 0; i < pts_num; i++){
        float x = pts_p[i*4] - last_center_x;
        float y = pts_p[i*4 + 1] - last_center_y;
        float z = pts_p[i*4 + 2] - last_center_z;
        float horize_dist = std::sqrt(x*x + y*y);
        //头顶和底部不考虑在内，理论上不应在本帧出现水平距离0
        if (horize_dist <= 1e-5f) continue; //使angle_id=-1，无效
        float dist = std::sqrt(x*x + y*y + z*z);
        float horize_angle = std::acos(x / horize_dist);
        if (y < 0) horize_angle = 2.0f*M_PI - horize_angle;
        int horize_angle_id = std::max(0, std::min(static_cast<int>(horize_angle * reso2radius_fac_), horize_angle_max_id_));
        float vertikal_angle = std::acos(horize_dist / dist);
        int vertikal_angle_id = std::max(0, std::min(static_cast<int>(vertikal_angle * reso2radius_fac_), vertikal_angle_max_id_));
        int angle_id = (vertikal_angle_id << 16) | (horize_angle_id & 0xffff);
        pts_xyz_dist_[i*4] = x;
        pts_xyz_dist_[i*4 + 1] = y;
        pts_xyz_dist_[i*4 + 2] = z;
        pts_xyz_dist_[i*4 + 3] = dist;
        pts_angle_id_[i] = angle_id;
    }
    // std::cout<<"finish frame angle seg"<<std::endl;
    setupAngleDist(last_center_x, last_center_y, last_center_z, voxels_num,
                    voxels_p, voxel_tmp_dist_.data(), angle_voxel_num_.data(), voxel_angle_id_.data());
    setupStartEndId(angle_voxel_start_id_.data(), angle_voxel_end_id_.data(), angle_voxel_num_.data());
    
    for (int i = 0; i < voxels_num; i++){
        int angle_id = voxel_angle_id_[i];
        if (angle_id == -1) continue;
        int horize_angle_id = angle_id & 0xffff;
        int vertikal_angle_id = (angle_id >> 16) & 0xffff;
        angle_id = vertikal_angle_id * horize_angle_pieces_ + horize_angle_id;
        int cur_voxel_seq_id = angle_voxel_start_id_[angle_id] + angle_voxel_num_[angle_id];
        angle_voxel_num_[angle_id] ++;
        voxel_xyz_sqr_dist_[cur_voxel_seq_id * 4] = voxels_p[i*4] - last_center_x;
        voxel_xyz_sqr_dist_[cur_voxel_seq_id * 4 + 1] = voxels_p[i*4 + 1] - last_center_y;
        voxel_xyz_sqr_dist_[cur_voxel_seq_id * 4 + 2] = voxels_p[i*4 + 2] - last_center_z;
        voxel_xyz_sqr_dist_[cur_voxel_seq_id * 4 + 3] = voxel_tmp_dist_[i] * voxel_tmp_dist_[i];
        voxel_seq_id_[i] = cur_voxel_seq_id;
    }
    // std::cout<<"finish voxel angle seg"<<std::endl;

    for (int i = 0; i < pts_num; i++){
        int angle_id = pts_angle_id_[i];
        if (angle_id == -1) continue; 
        int horize_angle_id = angle_id & 0xffff;
        int vertikal_angle_id = (angle_id >> 16) & 0xffff;
        getSearchAngleId(vertikal_angle_id, horize_angle_id);
        for (int j = 0; j < search_angle_id_.size(); j++){
            int search_angle_id = search_angle_id_[j];
            angle_voxel_num_[search_angle_id] = -1;
        }
    }
    for (int i = 0; i < voxels_num; i++){
        float tmp_catch_dist = voxel_tmp_dist_[i] * voxel_tmp_dist_[i];
        int angle_id = voxel_angle_id_[i];
        if (angle_id == -1) continue; //使catch_dist=0,相当于不追踪
        int horize_angle_id = angle_id & 0xffff;
        int vertikal_angle_id = (angle_id >> 16) & 0xffff;
        if (angle_voxel_num_[vertikal_angle_id*horize_angle_pieces_ + horize_angle_id] >= 0) continue;
        getSearchAngleId(vertikal_angle_id, horize_angle_id);
        float voxel_x = voxels_p[i*4] - last_center_x;
        float voxel_y = voxels_p[i*4 + 1] - last_center_y;
        float voxel_z = voxels_p[i*4 + 2] - last_center_z; //?这里该做法变慢了？
        float sqr_voxel_dist_origin_fac = 1.0f / tmp_catch_dist;
        for (int j = 0; j < search_angle_id_.size(); j++){
            int search_angle_id = search_angle_id_[j];
            updateCatchDist(voxel_xyz_sqr_dist_.data(), angle_voxel_start_id_[search_angle_id], angle_voxel_end_id_[search_angle_id],
                pts_filter_voxel_occlusion_range_, voxel_x, voxel_y, voxel_z, sqr_voxel_dist_origin_fac, tmp_catch_dist);
        }
        catch_dist_[voxel_seq_id_[i]] = std::sqrt(tmp_catch_dist);
    }
    // std::cout<<"finish voxel catch dist adjust"<<std::endl;

    float* filtered_out_pts_p = pts_xyz_dist_.data();
    int filtered_out_pts_num = 0;
    
    for (int i = 0; i < pts_num; i++){
        int angle_id = pts_angle_id_[i];
        if (angle_id == -1) continue; 
        int horize_angle_id = angle_id & 0xffff;
        int vertikal_angle_id = (angle_id >> 16) & 0xffff;
        getSearchAngleId(vertikal_angle_id, horize_angle_id);
        float pts_x = pts_xyz_dist_[i*4];
        float pts_y = pts_xyz_dist_[i*4 + 1];
        float pts_z = pts_xyz_dist_[i*4 + 2];
        float pts_dist = pts_xyz_dist_[i*4 + 3];
        float sqr_dist = pts_dist * pts_dist;
        for (int j = 0; j < search_angle_id_.size(); j++){
            int search_angle_id = search_angle_id_[j];
            char catched = updateFilteredOutVoxel(voxel_xyz_sqr_dist_.data(), catch_dist_.data(),
                                    angle_voxel_start_id_[search_angle_id], angle_voxel_end_id_[search_angle_id],
                                    pts_x, pts_y, pts_z, pts_dist, sqr_dist,
                                    pts_filter_line_range_, pts_filter_catch_dist_threshold_, pts_filter_catch_angle_threshold_);
            if (catched == 1){
                filtered_pts_status_[i] = 0;
                break;
            } 
        }
    }
    // std::cout<<"finish pts dynamic extract"<<std::endl;

    return filtered_pts_status_;
}


} // namespace multiree
