#include "multitree_forest.h"
// #include "multitree_base_tree.h"

#include <fstream>
#include <sstream>
#include <iomanip>

#include <chrono>

#include <json_custom.h>

template <typename Src, typename Aim>
    std::vector<Aim> loadDataFromFile(std::string file_path){
        std::ifstream file(file_path, std::ios::binary);
        if (!file.good()){
            std::cout<<"file abnormal, check path or is broken: " << file_path<<std::endl;
            return std::vector<Aim>(0);
        } 
        file.seekg(0, file.end);
        int64_t end_byte = file.tellg();
        file.seekg(0, file.beg);
        int64_t beg_byte = file.tellg();
        int64_t byte_length = end_byte - beg_byte;
        int64_t num_element = byte_length / sizeof(Src);
        std::vector<Aim> ret(num_element);
        std::vector<Src> load(num_element);
        file.read(reinterpret_cast<char*>(load.data()), byte_length);
        for (int i = 0; i < num_element; i++) ret[i] = static_cast<Aim>(load[i]);
        return ret;
    }
size_t physical_memory_used_by_process(){
    FILE* file = fopen("/proc/self/status", "r");
    int result = -1;
    char line[128];
    while (fgets(line, 128, file) != nullptr) {
        if (strncmp(line, "VmRSS:", 6) == 0) {
            int len = strlen(line);
            const char* p = line;
            for (; std::isdigit(*p) == false; ++p) {}
            line[len - 3] = 0;
            result = atoi(p);
            break;
        }
    }
    fclose(file);
    return result;
}
int main(){
    // std::vector<float> pts = loadDataFromFile<float, float>("/home/dong/tmp_support/compare/point_clouds_xyzi/0089.bin");
    // multitree::BaseBiLayerCubicTree test_tree_0(4, 3, 0.1, 0); //12.8m, origin->-6.4,-6.4,-6.4
    // // multitree::BaseBiLayerCubicTree test_tree_1(3, 4, 0.1, 0);
    // std::cout<<pts.size()<<std::endl;
    // int pts_num = pts.size() / 4;
    // int valid_pts = 0;
    // for (int i = 0; i < pts_num; i++){
    //     float relative_x = pts[i*4] + 6.4f;
    //     float relative_y = pts[i*4 + 1] + 6.4f;
    //     float relative_z = pts[i*4 + 2] + 6.4f;
    //     if (relative_x < 0.0f || relative_x >= 12.8f || relative_y < 0.0f || relative_y >= 12.8f || relative_z < 0.0f || relative_z >= 12.8f) continue;
    //     test_tree_0.addPoint(relative_x, relative_y, relative_z);
    //     valid_pts ++;
    // }
    // std::cout<<pts_num<<' '<<valid_pts<<' '<<test_tree_0.getValidLeafNum()<<std::endl;

    // std::vector<int> check_coord = test_tree_0.checkLeafIntCoord();
    // std::vector<float> check_xyz(check_coord.size()*3);
    // for (int i = 0; i < check_coord.size(); i++){
    //     check_xyz[i*3] = static_cast<float>((check_coord[i]>>14)&0x7f)*0.1f + 0.05f - 6.4f;
    //     check_xyz[i*3 + 1] = static_cast<float>((check_coord[i]>>7)&0x7f)*0.1f + 0.05f - 6.4f;
    //     check_xyz[i*3 + 2] = static_cast<float>((check_coord[i])&0x7f)*0.1f + 0.05f - 6.4f;
    //     // std::cout<<check_xyz[i*3]<<' '<<check_xyz[i*3 + 1]<<' '<<check_xyz[i*3 + 2]<<std::endl;
    // }

    // std::vector<float> check_xyz = test_tree_0.checkLeafAbsolutePosition(-6.4f, -6.4f, -6.4f);
    // std::ofstream file("../data/0089-voxel.bin", std::ios::binary);
    // file.write(reinterpret_cast<char*>(check_xyz.data()), sizeof(float)*check_xyz.size());
    // file.close();

    nlohmann::json forest_cfg;
    std::string cfg_path = "../config.json";
    json::customfunc::getJsonFromFile(cfg_path, forest_cfg);
    nlohmann::json topic_args = forest_cfg.at("topic_args").get<nlohmann::json>();
    nlohmann::json forest_base_args = forest_cfg.at("forest_base_args").get<nlohmann::json>();
    nlohmann::json optical_flow_args = forest_cfg.at("optical_flow_args").get<nlohmann::json>();
    nlohmann::json flatten_map_args = forest_cfg.at("flatten_map_args").get<nlohmann::json>();

    std::string ros_node_id = topic_args.at("ros_node_id").get<std::string>();
    std::string pose_topic_id = topic_args.at("pose_topic_id").get<std::string>();
    std::string pts_topic_id = topic_args.at("pts_topic_id").get<std::string>();
    std::string voxel_topic_id = topic_args.at("voxel_topic_id").get<std::string>();
    std::string global_topic_frame_id = topic_args.at("global_topic_frame_id").get<std::string>();
    std::string voxel_topic_namespace = topic_args.at("voxel_topic_namespace").get<std::string>();
    std::string point_cloud_pub_topic_id = topic_args.at("point_cloud_pub_topic_id").get<std::string>();
    std::string flatten_map_pub_topic_id = topic_args.at("flatten_map_pub_topic_id").get<std::string>();

    int log_root_level_x = forest_base_args.at("log_root_level_x").get<int>();
    int log_root_level_y = forest_base_args.at("log_root_level_y").get<int>();
    int log_root_level_z = forest_base_args.at("log_root_level_z").get<int>();
    int log_level_branch = forest_base_args.at("log_level_branch").get<int>();
    int log_level_leaf = forest_base_args.at("log_level_leaf").get<int>();
    int estimate_pts_num = forest_base_args.at("estimate_pts_num").get<int>();
    int estimate_voxel_num = forest_base_args.at("estimate_voxel_num").get<int>();
    float resolution = forest_base_args.at("resolution").get<float>();
    float angle_resolution = forest_base_args.at("angle_resolution").get<float>();
    int single_mode = forest_base_args.at("single_mode").get<int>();
    int extern_defined_range_x = forest_base_args.at("extern_defined_range_x").get<int>();
    int extern_defined_range_y = forest_base_args.at("extern_defined_range_y").get<int>();
    int extern_defined_range_z = forest_base_args.at("extern_defined_range_z").get<int>();

    float catch_dist_angle_factor = optical_flow_args.at("catch_dist_angle_factor").get<float>();
    float voxel_filter_pts_occlusion_range = optical_flow_args.at("voxel_filter_pts_occlusion_range").get<float>();
    float voxel_filter_line_range = optical_flow_args.at("voxel_filter_line_range").get<float>();
    float voxel_filter_catch_dist_threshold = optical_flow_args.at("voxel_filter_catch_dist_threshold").get<float>();
    float voxel_filter_catch_angle_threshold = optical_flow_args.at("voxel_filter_catch_angle_threshold").get<float>();
    float pts_filter_voxel_occlusion_range = optical_flow_args.at("pts_filter_voxel_occlusion_range").get<float>();
    float pts_filter_line_range = optical_flow_args.at("pts_filter_line_range").get<float>();
    float pts_filter_catch_dist_threshold = optical_flow_args.at("pts_filter_catch_dist_threshold").get<float>();
    float pts_filter_catch_angle_threshold = optical_flow_args.at("pts_filter_catch_angle_threshold").get<float>();

    float z_min_threshold = flatten_map_args.at("z_min_threshold").get<float>();
    float z_max_threshold = flatten_map_args.at("z_max_threshold").get<float>();
    float map_x_range = flatten_map_args.at("map_x_range").get<float>(); 
    float map_y_range = flatten_map_args.at("map_y_range").get<float>(); 
    float map_resolution = flatten_map_args.at("map_resolution").get<float>();

    multitree::BiLayerCubicTreeForest* test_forest = new multitree::BiLayerCubicTreeForest(log_root_level_x, log_root_level_y, log_root_level_z,
                                                                                        log_level_branch, log_level_leaf,
                                                                                        estimate_pts_num, estimate_voxel_num,
                                                                                        resolution, angle_resolution, single_mode,
                                                                                        extern_defined_range_x, extern_defined_range_y, extern_defined_range_z);
    test_forest->setOpticalFlowArgs(catch_dist_angle_factor, 
                                    voxel_filter_pts_occlusion_range, voxel_filter_line_range, 
                                    voxel_filter_catch_dist_threshold, voxel_filter_catch_angle_threshold, 
                                    pts_filter_voxel_occlusion_range, pts_filter_line_range, 
                                    pts_filter_catch_dist_threshold, pts_filter_catch_angle_threshold);
    test_forest->setFlattenArgs(z_min_threshold, z_max_threshold, map_x_range, map_y_range, map_resolution);

    std::stringstream file_id;
    std::stringstream pose_id;
    std::stringstream output_id;
    double time_update = 0.0f;
    double time_check = 0.0f;
    int frame_num = 0;
    int max_pts_num = 0;
    int min_pts_num = 1000000;
    int frame_id = 89;
    std::vector<float> check_xyz;
    // std::cout<<file_id.str()<<std::endl;
    // file_id.clear();std::cout<<file_id.str()<<std::endl;
    //     file_id.str("");std::cout<<file_id.str()<<std::endl;
    //     file_id << std::setw(4)<<std::setfill('0') <<frame_id;std::cout<<file_id.str()<<std::endl;
    float pre_center_x = 0.0f;
    float pre_center_y = 0.0f;
    float pre_center_z = 0.0f;
    while(1){
        std::cout<<frame_id<<":"<<std::endl;
        if (frame_id >=858) {frame_id = 89; break;
        } 
        file_id.clear(); 
        file_id.str(""); 
        file_id << std::setw(4)<<std::setfill('0') <<frame_id;
        std::vector<float> xyzi = loadDataFromFile<float, float>("/home/dong/tmp_support/compare/point_clouds_xyzi/" + file_id.str() + ".bin");
        int pts_num = xyzi.size() / 4;
        pose_id.clear();
        pose_id.str("");
        pose_id<<std::setw(4)<<std::setfill('0')<<(frame_id-89);
        std::vector<float> pose = loadDataFromFile<float, float>("/home/dong/tmp_support/compare/tf_pose/" + pose_id.str() + ".bin");
        std::cout<<pose[0]<<' '<<pose[1]<<' '<<pose[2]<<std::endl;
        auto t0 = std::chrono::system_clock::now();

        test_forest->checkUpdateOriginRangeConstrain(pose[0], pose[1], pose[2]);

        std::vector<char> xyzi_status = test_forest->curFrameRecordDynamic(pre_center_x, pre_center_y, pre_center_z, 
                                                                        check_xyz.data(), xyzi.data(), check_xyz.size() / 4, pts_num);
        // std::cout<<"check0"<<std::endl;
        test_forest->filterVoxelByCurFrame(check_xyz.data(), xyzi.data(), check_xyz.size() / 4, pts_num);
        // std::cout<<"check1"<<std::endl;
        // test_forest->addFrame(pose[0], pose[1], pose[2], xyzi.data(), pts_num);
        test_forest->addFrameUpdateDynamic(xyzi.data(), xyzi_status.data(), pts_num, pose[0], pose[1], pose[2]);
        
        auto t1 = std::chrono::system_clock::now();
        double duration0 = std::chrono::duration<double>(t1 - t0).count();
        duration0 *= 1000.0f;
        std::cout<<"tree update time cost: "<<duration0<<" ms"<<std::endl;
        t0 = std::chrono::system_clock::now();
        check_xyz = test_forest->checkAllLeafAbsolutePosition();
        t1 = std::chrono::system_clock::now();
        double duration1 = std::chrono::duration<double>(t1 - t0).count();
        duration1 *= 1000.0f;
        std::cout<<"voxel get time cost: "<<duration1<<" ms"<<std::endl;
        // std::cout<<"voxel num: "<<check_xyz.size() / 4<<std::endl;
        output_id.clear();
        output_id.str("");
        output_id<<std::setw(4)<<std::setfill('0')<<(frame_id-89);
        std::cout<<"used cpu mem: "<<double(physical_memory_used_by_process()) / 1024.0 <<"MB"<<std::endl;

        pre_center_x = pose[0];
        pre_center_y = pose[1];
        pre_center_z = pose[2];

        // std::ofstream file("/home/dong/tmp_support/compare/tree_voxels/" + output_id.str() + ".bin", std::ios::binary);
        // file.write(reinterpret_cast<char*>(check_xyz.data()), sizeof(float)*check_xyz.size());
        // file.close();
        if (check_xyz.size()/4 > 0 && check_xyz.size()/4<150000){
            frame_num++;
            time_update += duration0;
            time_check += duration1;
            max_pts_num = std::max(max_pts_num, pts_num);
            min_pts_num = std::min(min_pts_num, pts_num);
        }
        frame_id++;
    }
    delete test_forest;
    std::cout<<"used cpu mem: "<<double(physical_memory_used_by_process()) / 1024.0 <<"MB"<<std::endl;
    std::cout<<time_update / static_cast<double>(frame_num)<<' '<<time_check / static_cast<double>(frame_num)<<std::endl;
    std::cout<<sizeof(multitree::TreeLeaf)<<' '<<max_pts_num<<' '<<min_pts_num<<std::endl;
    
    // std::vector<float> check_xyz = test_forest.checkAllLeafAbsolutePosition();
    // std::ofstream file("../data/0089-0408-voxel.bin", std::ios::binary);
    // file.write(reinterpret_cast<char*>(check_xyz.data()), sizeof(float)*check_xyz.size());
    // file.close();
    // while(1){;;}
    return 0;
}