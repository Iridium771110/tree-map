#include <iostream>
#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/PointCloud2.h>
#include <tf2_msgs/TFMessage.h>
#include <geometry_msgs/TransformStamped.h>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <nav_msgs/GridCells.h>
#include "navigation/LocalMap.h"
#include <tf/transform_listener.h>
#include <stdlib.h>

#include "message_filters/subscriber.h"
#include "message_filters/synchronizer.h"
#include "message_filters/sync_policies/approximate_time.h"
#include "message_filters/sync_policies/exact_time.h"

#include <fstream>
#include <sstream>
#include <iomanip>

#include <vector>
#include <boost/bind.hpp>
#include "multitree_forest.h"
#include <json_custom.h>
#include <chrono>
#include <iomanip>
#include "yaml-cpp/yaml.h"

inline float getYawFromQuaternion(const float* q_p){
    //gimbal lock?
    float w = q_p[0];
    float x = q_p[1];
    float y = q_p[2];
    float z = q_p[3];
    std::cout<<"yaw: "<<std::atan2(2.0f * (y*z + w*x), w*w - x*x - y*y + z*z)<<"pitch: "<<std::asin(-2.0f*(x*z - w*y))
            <<"roll: "<<std::atan2(2.0f*(x*y + w*z), w*w + x*x - y*y - z*z)<<std::endl;
    // return std::atan2(2.0f * (y*z + w*x), w*w - x*x - y*y + z*z);

    return std::atan2(2.0f*(x*y + w*z), w*w + x*x - y*y - z*z);
}

inline float getYawFromRotMat(const float* rot_p){
    //gimbal lock?
    
    std::cout<<"yaw: "<<std::atan2(rot_p[7], rot_p[8])<<"pitch: "<<std::asin(-rot_p[6])
            <<"roll: "<<std::atan2(rot_p[3], rot_p[0])<<std::endl;
    return std::atan2(rot_p[3], rot_p[0]);
}

inline std::vector<float> getRotMatFromYaw(const float yaw){
    return std::vector<float>({std::cos(yaw), -std::sin(yaw), 0.0f,
                                std::sin(yaw), std::cos(yaw), 0.0f,
                                0.0f, 0.0f, 1.0f});
}

void tmpTransMatFuse(const float* right_rot_p, const float* right_trans_p, const bool right_inverse,
                    float* rot_p, float* trans_p){
    std::vector<float> rot_mat(9);
    std::vector<float> trans_mat(3);
    std::memcpy(rot_mat.data(), right_rot_p, 9*sizeof(float));
    std::memcpy(trans_mat.data(), right_trans_p, 3*sizeof(float));
    if (right_inverse){
        float tmp;
        tmp = rot_mat[1]; rot_mat[1] = rot_mat[3]; rot_mat[3] = tmp;
        tmp = rot_mat[2]; rot_mat[2] = rot_mat[6]; rot_mat[6] = tmp;
        tmp = rot_mat[5]; rot_mat[5] = rot_mat[7]; rot_mat[7] = tmp;
        trans_mat[0] = rot_mat[0]*right_trans_p[0] + rot_mat[1]*right_trans_p[1] + rot_mat[2]*right_trans_p[2];
        trans_mat[1] = rot_mat[3]*right_trans_p[0] + rot_mat[4]*right_trans_p[1] + rot_mat[5]*right_trans_p[2];
        trans_mat[2] = rot_mat[6]*right_trans_p[0] + rot_mat[7]*right_trans_p[1] + rot_mat[8]*right_trans_p[2];
        trans_mat[0] = - trans_mat[0];
        trans_mat[1] = - trans_mat[1];
        trans_mat[2] = - trans_mat[2];
    }
    trans_p[0] = rot_p[0] * trans_mat[0] + rot_p[1] * trans_mat[1] + rot_p[2] * trans_mat[2] + trans_p[0];
    trans_p[1] = rot_p[3] * trans_mat[0] + rot_p[4] * trans_mat[1] + rot_p[5] * trans_mat[2] + trans_p[1];
    trans_p[2] = rot_p[6] * trans_mat[0] + rot_p[7] * trans_mat[1] + rot_p[8] * trans_mat[2] + trans_p[2];
    std::vector<float> tmp(9);
    std::memcpy(tmp.data(), rot_p, 9*sizeof(float));
    rot_p[0] = tmp[0]*rot_mat[0] + tmp[1]*rot_mat[3] + tmp[2]*rot_mat[6];
    rot_p[1] = tmp[0]*rot_mat[1] + tmp[1]*rot_mat[4] + tmp[2]*rot_mat[7];
    rot_p[2] = tmp[0]*rot_mat[2] + tmp[1]*rot_mat[5] + tmp[2]*rot_mat[8];
    rot_p[3] = tmp[3]*rot_mat[0] + tmp[4]*rot_mat[3] + tmp[5]*rot_mat[6];
    rot_p[4] = tmp[3]*rot_mat[1] + tmp[4]*rot_mat[4] + tmp[5]*rot_mat[7];
    rot_p[5] = tmp[3]*rot_mat[2] + tmp[4]*rot_mat[5] + tmp[5]*rot_mat[8];
    rot_p[6] = tmp[6]*rot_mat[0] + tmp[7]*rot_mat[3] + tmp[8]*rot_mat[6];
    rot_p[7] = tmp[6]*rot_mat[1] + tmp[7]*rot_mat[4] + tmp[8]*rot_mat[7];
    rot_p[8] = tmp[6]*rot_mat[2] + tmp[7]*rot_mat[5] + tmp[8]*rot_mat[8];
}

void tmpInverseRot(const float* quaternion_p, const float* trans_p, float* xyzi_p, int pts_num, bool inverse){
    std::vector<float> rot_mat(9);
    std::vector<float> trans_mat(3);
    multitree::quaternion2Rotation(quaternion_p, rot_mat.data());
    trans_mat[0] = trans_p[0]; trans_mat[1] = trans_p[1]; trans_mat[2] = trans_p[2];
    if (inverse){
        float tmp;
        tmp = rot_mat[1]; rot_mat[1] = rot_mat[3]; rot_mat[3] = tmp;
        tmp = rot_mat[2]; rot_mat[2] = rot_mat[6]; rot_mat[6] = tmp;
        tmp = rot_mat[5]; rot_mat[5] = rot_mat[7]; rot_mat[7] = tmp;
        trans_mat[0] = rot_mat[0]*trans_p[0] + rot_mat[1]*trans_p[1] + rot_mat[2]*trans_p[2];
        trans_mat[1] = rot_mat[3]*trans_p[0] + rot_mat[4]*trans_p[1] + rot_mat[5]*trans_p[2];
        trans_mat[2] = rot_mat[6]*trans_p[0] + rot_mat[7]*trans_p[1] + rot_mat[8]*trans_p[2];
        trans_mat[0] = - trans_mat[0];
        trans_mat[1] = - trans_mat[1];
        trans_mat[2] = - trans_mat[2];
    }
    for (int i = 0; i < pts_num; i++){
        float x = xyzi_p[i*4];
        float y = xyzi_p[i*4 + 1];
        float z = xyzi_p[i*4 + 2];
        xyzi_p[i*4] = rot_mat[0] * x + rot_mat[1] * y + rot_mat[2] * z + trans_mat[0];
        xyzi_p[i*4 + 1] = rot_mat[3] * x + rot_mat[4] * y + rot_mat[5] * z + trans_mat[1];
        xyzi_p[i*4 + 2] = rot_mat[6] * x + rot_mat[7] * y + rot_mat[8] * z + trans_mat[2];
    }
}

void tmpInverseRotMat(const float* rotation_p, const float* trans_p, float* xyzi_p, int pts_num, bool inverse){
    std::vector<float> rot_mat(9);
    std::vector<float> trans_mat(3);
    std::memcpy(rot_mat.data(), rotation_p, 9*sizeof(float));
    std::memcpy(trans_mat.data(), trans_p, 3*sizeof(float));
    if (inverse){
        float tmp;
        tmp = rot_mat[1]; rot_mat[1] = rot_mat[3]; rot_mat[3] = tmp;
        tmp = rot_mat[2]; rot_mat[2] = rot_mat[6]; rot_mat[6] = tmp;
        tmp = rot_mat[5]; rot_mat[5] = rot_mat[7]; rot_mat[7] = tmp;
        trans_mat[0] = rot_mat[0]*trans_p[0] + rot_mat[1]*trans_p[1] + rot_mat[2]*trans_p[2];
        trans_mat[1] = rot_mat[3]*trans_p[0] + rot_mat[4]*trans_p[1] + rot_mat[5]*trans_p[2];
        trans_mat[2] = rot_mat[6]*trans_p[0] + rot_mat[7]*trans_p[1] + rot_mat[8]*trans_p[2];
        trans_mat[0] = - trans_mat[0];
        trans_mat[1] = - trans_mat[1];
        trans_mat[2] = - trans_mat[2];
    }
    for (int i = 0; i < pts_num; i++){
        float x = xyzi_p[i*4];
        float y = xyzi_p[i*4 + 1];
        float z = xyzi_p[i*4 + 2];
        xyzi_p[i*4] = rot_mat[0] * x + rot_mat[1] * y + rot_mat[2] * z + trans_mat[0];
        xyzi_p[i*4 + 1] = rot_mat[3] * x + rot_mat[4] * y + rot_mat[5] * z + trans_mat[1];
        xyzi_p[i*4 + 2] = rot_mat[6] * x + rot_mat[7] * y + rot_mat[8] * z + trans_mat[2];
    }
}

inline void tmpTranPtsRotMat(const float* rot_p, const float* trans_p, float* pts_p){
    float x = pts_p[0];
    float y = pts_p[1];
    float z = pts_p[2];
    pts_p[0] = rot_p[0] * x + rot_p[1] * y + rot_p[2] * z + trans_p[0];
    pts_p[1] = rot_p[3] * x + rot_p[4] * y + rot_p[5] * z + trans_p[1];
    pts_p[2] = rot_p[6] * x + rot_p[7] * y + rot_p[8] * z + trans_p[2];
}

void odomCallback(const nav_msgs::OdometryConstPtr &msg, ros::Time* time_stamp_p, float* pose_p){
    std::cout<<"catch odom "<<std::endl;
    ros::Time tmp_time_stamp = msg->header.stamp;
    std::vector<float> tmp_pose(7);
    tmp_pose[0] = msg->pose.pose.position.x;
    tmp_pose[1] = msg->pose.pose.position.y;
    tmp_pose[2] = msg->pose.pose.position.z;
    tmp_pose[3] = msg->pose.pose.orientation.w;
    tmp_pose[4] = msg->pose.pose.orientation.x;
    tmp_pose[5] = msg->pose.pose.orientation.y;
    tmp_pose[6] = msg->pose.pose.orientation.z;
    for (int i = 0; i < 19; i++) std::memcpy(pose_p + i*7, pose_p + i*7 + 7, sizeof(float)*7);
    std::memcpy(pose_p + 19*7, tmp_pose.data(), sizeof(float)*7);
    for (int i = 0; i < 19; i++) time_stamp_p[i] = time_stamp_p[i + 1];
    time_stamp_p[19] = tmp_time_stamp;
}

void markerArrayCallback(const visualization_msgs::MarkerArrayConstPtr &msg, ros::Time* time_stamp, float* box_with_pose_p, int* box_num){
    std::cout<<"catch filtering bboxes"<<std::endl;
    *box_num = msg->markers.size();
    *time_stamp = msg->markers[0].header.stamp;
    for (int i = 0; i < *box_num; i++){
        box_with_pose_p[i*10] = msg->markers[i].pose.position.x;
        box_with_pose_p[i*10 + 1] = msg->markers[i].pose.position.y;
        box_with_pose_p[i*10 + 2] = msg->markers[i].pose.position.z;
        box_with_pose_p[i*10 + 3] = msg->markers[i].pose.orientation.w;
        box_with_pose_p[i*10 + 4] = msg->markers[i].pose.orientation.x;
        box_with_pose_p[i*10 + 5] = msg->markers[i].pose.orientation.y;
        box_with_pose_p[i*10 + 6] = msg->markers[i].pose.orientation.z;
        box_with_pose_p[i*10 + 7] = msg->markers[i].scale.x;
        box_with_pose_p[i*10 + 8] = msg->markers[i].scale.y;
        box_with_pose_p[i*10 + 9] = msg->markers[i].scale.z;
    }
    std::cout<<"catch filtering bboxes finish, bbox num: "<<*box_num<<std::endl;
}

void pcdCallback1(const sensor_msgs::PointCloud2ConstPtr &msg, ros::Time* time_stamp, float* pts_p, int* pts_num){
    std::cout<<"catch pcd "<<std::endl;
    *time_stamp = msg->header.stamp;
    *pts_num = msg->width * msg->height;
    int pts_offset = msg->point_step;
    for (int i = 0; i < *pts_num; i++){
        std::memcpy(pts_p + i*4, msg->data.data() + i*pts_offset, 3*sizeof(float)); //only consider x,y,z as first three float data
    }
    std::cout<<"catch pcd finish, pts num: "<<*pts_num<<", pts offset step="<<pts_offset<<std::endl;
}

void pcdCallback1Filtered(const sensor_msgs::PointCloud2ConstPtr &msg, ros::Time* time_stamp, float* pts_p, int* pts_num, float* pose_p,
                        float* xyz_minmax_p, float angle_resolution, float dist_thres){
    std::cout<<"catch pcd "<<std::endl;
    *time_stamp = msg->header.stamp;
    *pts_num = msg->width * msg->height;
    int pts_offset = msg->point_step;
    std::cout<<"catch pcd finish, pts num: "<<*pts_num<<std::endl;
    float tmp_pts_p[4]; //pts cheated as 4*float, first three is x y z
    float reso2radius_fac_ = (180.0f / angle_resolution) / M_PI;
    int horize_angle_max_id_ = static_cast<int>(360.0f / angle_resolution) - 1;
    std::vector<float> rot(9);
    multitree::quaternion2Rotation(pose_p + 3, rot.data());
    float x_min = xyz_minmax_p[0];
    float x_max = xyz_minmax_p[1];
    float y_min = xyz_minmax_p[2];
    float y_max = xyz_minmax_p[3];
    float z_min = xyz_minmax_p[4];
    float z_max = xyz_minmax_p[5];

    auto t0 = std::chrono::system_clock::now();
    if (angle_resolution < 0.0f){
        int valid_num = 0;
        for (int i = 0; i < *pts_num; i++){
            std::memcpy(tmp_pts_p, msg->data.data() + i*pts_offset, 4*sizeof(float));
            // tmpInverseRot(pose_p+3, pose_p, tmp_pts_p, 1, false);
            tmpTranPtsRotMat(rot.data(), pose_p, tmp_pts_p);
            float x = tmp_pts_p[0];
            float y = tmp_pts_p[1];
            float z = tmp_pts_p[2];
            if (x < x_min || x > x_max || y < y_min || y > y_max || z < z_min || z > z_max) continue;
            float horize_dist = std::sqrt(x*x + y*y);
            if (horize_dist <= 1e-5f || horize_dist > dist_thres) continue; 
            std::memcpy(pts_p + valid_num*4, tmp_pts_p, 4*sizeof(float)); 
            valid_num++;
        }
        *pts_num = valid_num;
    }
    else{
        std::vector<float> stored_pts((horize_angle_max_id_+1)*4, 2000.0f);
        for (int i = 0; i < *pts_num; i++){
            std::memcpy(tmp_pts_p, msg->data.data() + i*pts_offset, 4*sizeof(float));
            // tmpInverseRot(pose_p+3, pose_p, tmp_pts_p, 1, false);
            tmpTranPtsRotMat(rot.data(), pose_p, tmp_pts_p);
            float x = tmp_pts_p[0];
            float y = tmp_pts_p[1];
            float z = tmp_pts_p[2];
            if (z < z_min || z > z_max) continue;
            float horize_dist = std::sqrt(x*x + y*y);
            if (horize_dist <= 1e-5f || horize_dist > dist_thres) continue; 
            float dist = std::sqrt(x*x + y*y + z*z);
            float horize_angle = std::acos(x / horize_dist);
            if (y < 0) horize_angle = 2.0f*M_PI - horize_angle;
            int horize_angle_id = std::max(0, std::min(static_cast<int>(horize_angle * reso2radius_fac_), horize_angle_max_id_));
            if (stored_pts[horize_angle_id*4+3] > dist){
                stored_pts[horize_angle_id*4] = tmp_pts_p[0];
                stored_pts[horize_angle_id*4 + 1] = tmp_pts_p[1];
                stored_pts[horize_angle_id*4 + 2] = tmp_pts_p[2];
                stored_pts[horize_angle_id*4 + 3] = dist;
            }
        }
        *pts_num = 0;
        for (int i = 0; i <= horize_angle_max_id_; i++){
            if (stored_pts[i*4+3]<1000.0f){
                std::memcpy(pts_p + (*pts_num)*4, stored_pts.data()+i*4, 4*sizeof(float)); 
                *pts_num += 1;
            } 
        }
    }
    auto t1 = std::chrono::system_clock::now();
            double duration0 = std::chrono::duration<double>(t1 - t0).count();
            duration0 *= 1000.0f;
            std::cout<<"filter pcd total cost: "<<duration0<<" ms"<<std::endl;
    std::cout<<"filter pcd finish, pts num: "<<*pts_num<<", pts offset step="<<pts_offset<<std::endl;
}

void getPoseFromTrans(float* pose_p, tf::StampedTransform &trans){
    pose_p[0] = trans.getOrigin().x();
    pose_p[1] = trans.getOrigin().y();
    pose_p[2] = trans.getOrigin().z();
    pose_p[3] = trans.getRotation().w();
    pose_p[4] = trans.getRotation().x();
    pose_p[5] = trans.getRotation().y();
    pose_p[6] = trans.getRotation().z();
}

void mapFilter(const char* map_p, char* map_status_p, int* cal_map_p, int rows, int cols, int row_window_radius, int col_window_radius, char threshold){
    std::memset(cal_map_p, 0, sizeof(int)*rows*cols);
    cal_map_p[0] = static_cast<int>(map_p[0]);
    for (int col = 1; col < cols; col++) cal_map_p[col] = cal_map_p[col - 1] + static_cast<int>(map_p[col]);
    for (int row = 1; row < rows; row++) cal_map_p[row*cols] = cal_map_p[(row - 1) * cols] + static_cast<int>(map_p[row*cols]);
    for (int row = 1; row < rows; row++){
        for (int col = 1; col < cols; col++){
            cal_map_p[row*cols + col] = cal_map_p[row*cols + col - 1] + cal_map_p[(row - 1)*cols + col] - cal_map_p[(row - 1)*cols + col - 1] + static_cast<int>(map_p[row*cols + col]);
        }
    }
    for (int row = 0; row < rows; row++){
        for (int col = 0; col < cols; col++){
            if (map_p[row*cols + col] == 0) continue;
            int row_min = std::max(0, row - row_window_radius - 1);
            int row_max = std::min(rows - 1, row + row_window_radius);
            int col_min = std::max(0, col - col_window_radius - 1);
            int col_max = std::min(cols - 1, col + col_window_radius);
            int tmp = cal_map_p[row_min*cols + col_min] + cal_map_p[row_max*cols + col_max] - cal_map_p[row_min*cols + col_max] - cal_map_p[row_max*cols + col_min];
            if (tmp > threshold) map_status_p[row*cols + col] = 1;
        }
    }
}

void voxelPublish(multitree::BiLayerCubicTreeForest* forest_p,
                ros::Publisher &marker_pub, ros::Publisher &map_pub,
                float* pts_p, float* pose_p, int pts_num, float* pre_pose_p, float* ref_pose_p, float* localization_pose_p, float* sensor_extra_rot_trans_p,
                int* cal_map_p, char* map_status_p, int frame_window,
                visualization_msgs::Marker &marker_pre,
                visualization_msgs::Marker &marker_cur,
                navigation::LocalMap &map_msg,
                visualization_msgs::Marker &marker_grid_pre,
                visualization_msgs::Marker &marker_grid_cur,
                const ros::Time &stampe, float grid_resolution, std::vector<int> map_filter,
                bool local_coordinate_align, bool optical_flow_on){
    marker_pre = marker_cur;
    marker_grid_pre = marker_grid_cur;
    marker_pre.action = visualization_msgs::Marker::DELETE;
    marker_grid_pre.action = visualization_msgs::Marker::DELETE;
    
    std::vector<float> quaternion(4);
    quaternion[0] = pose_p[3];
    quaternion[1] = pose_p[4];
    quaternion[2] = pose_p[5];
    quaternion[3] = pose_p[6];
    std::vector<float> intern_pts(pts_num*4);
    std::memcpy(intern_pts.data(), pts_p, sizeof(float)*intern_pts.size());
    // float* ori_pts_p = pts_p;
    pts_p = intern_pts.data();

    std::vector<float> rot_trans(12, 0.0f);
    rot_trans[0] = 1.0f; rot_trans[4] = 1.0f; rot_trans[8] = 1.0f;
    std::memcpy(rot_trans.data(), sensor_extra_rot_trans_p, 12*sizeof(float));
    std::vector<float> pre_rot_trans = rot_trans;
    std::vector<float> ref_rot(9);
    std::vector<float> ref_trans(3);
    std::vector<float> rot(9);
    std::vector<float> trans(3);
    std::vector<float> pre_rot(9);
    std::vector<float> pre_trans(3);
    std::memcpy(ref_trans.data(), ref_pose_p, 3*sizeof(float));
    std::memcpy(trans.data(), pose_p, 3*sizeof(float));
    std::memcpy(pre_trans.data(), pre_pose_p, 3*sizeof(float));
    multitree::quaternion2Rotation(ref_pose_p + 3, ref_rot.data());
    multitree::quaternion2Rotation(pose_p + 3, rot.data());
    multitree::quaternion2Rotation(pre_pose_p + 3, pre_rot.data());
    // tmpTransMatFuse(ref_rot.data(), ref_trans.data(), true, rot_trans.data(), rot_trans.data() + 9);
    tmpTransMatFuse(rot.data(), trans.data(), false, rot_trans.data(), rot_trans.data() + 9);
    tmpTransMatFuse(ref_rot.data(), ref_trans.data(), false, rot_trans.data(), rot_trans.data() + 9);
    // tmpTransMatFuse(ref_rot.data(), ref_trans.data(), true, pre_rot_trans.data(), pre_rot_trans.data() + 9);
    tmpTransMatFuse(pre_rot.data(), pre_trans.data(), false, pre_rot_trans.data(), pre_rot_trans.data() + 9);
    tmpTransMatFuse(ref_rot.data(), ref_trans.data(), false, pre_rot_trans.data(), pre_rot_trans.data() + 9);
    
    std::vector<float> map_rot_trans(12, 0.0f);
    map_rot_trans[0] = 1.0f; map_rot_trans[4] = 1.0f; map_rot_trans[8] = 1.0f;
    std::vector<float> localization_rot(9);
    std::vector<float> localization_trans(3);
    std::memcpy(localization_trans.data(), localization_pose_p, 3*sizeof(float));
    multitree::quaternion2Rotation(localization_pose_p + 3, localization_rot.data());
    // tmpTransMatFuse(ref_rot.data(), ref_trans.data(), true, rot_trans.data(), rot_trans.data() + 9);
    tmpTransMatFuse(localization_rot.data(), localization_trans.data(), false, map_rot_trans.data(), map_rot_trans.data() + 9);
    tmpTransMatFuse(ref_rot.data(), ref_trans.data(), false, map_rot_trans.data(), map_rot_trans.data() + 9);

    if (local_coordinate_align){
        float yaw = getYawFromQuaternion(pose_p + 3);
        std::cout<<"yaw: "<<yaw<<std::endl;
        std::vector<float> rot_yaw = getRotMatFromYaw(yaw);
        std::vector<float> pose_rot(9);
        std::vector<float> zero_trans(3, 0.0f);
        multitree::quaternion2Rotation(pose_p + 3, pose_rot.data());
        std::vector<float> align_rot(9);
        std::vector<float> align_trans(3);
        std::memset(align_rot.data(), 0, sizeof(float)*9);
        std::memset(align_trans.data(), 0, sizeof(float)*3);
        align_rot[0] = 1.0f; align_rot[4] = 1.0f; align_rot[8] = 1.0f;
        std::vector<float> pre_align_rot = align_rot;
        std::vector<float> pre_align_trans = align_trans;
        std::vector<float> loc_align_rot = align_rot;
        std::vector<float> loc_align_trans = align_trans;
        tmpTransMatFuse(rot_yaw.data(), zero_trans.data(), true, align_rot.data(), align_trans.data());
        tmpTransMatFuse(pose_rot.data(), zero_trans.data(), false, align_rot.data(), align_trans.data());
        yaw = getYawFromQuaternion(pre_pose_p + 3);
        rot_yaw = getRotMatFromYaw(yaw);
        multitree::quaternion2Rotation(pre_pose_p + 3, pose_rot.data());
        tmpTransMatFuse(rot_yaw.data(), zero_trans.data(), true, pre_align_rot.data(), pre_align_trans.data());
        tmpTransMatFuse(pose_rot.data(), zero_trans.data(), false, pre_align_rot.data(), pre_align_trans.data());
        yaw = getYawFromQuaternion(localization_pose_p + 3);
        rot_yaw = getRotMatFromYaw(yaw);
        multitree::quaternion2Rotation(localization_pose_p + 3, pose_rot.data());
        tmpTransMatFuse(rot_yaw.data(), zero_trans.data(), true, loc_align_rot.data(), loc_align_trans.data());
        tmpTransMatFuse(pose_rot.data(), zero_trans.data(), false, loc_align_rot.data(), loc_align_trans.data());

        tmpTransMatFuse(align_rot.data(), align_trans.data(), true, rot_trans.data(), rot_trans.data() + 9);
        tmpTransMatFuse(pre_align_rot.data(), pre_align_trans.data(), true, pre_rot_trans.data(), pre_rot_trans.data() + 9);
        tmpTransMatFuse(loc_align_rot.data(), loc_align_trans.data(), true, map_rot_trans.data(), map_rot_trans.data() + 9);
    }

    // tmpInverseRotMat(rot_yaw.data(), zero_trans.data(), pts_p, pts_num, true);
    tmpInverseRotMat(rot_trans.data(), rot_trans.data() + 9, pts_p, pts_num, false);



    forest_p->checkUpdateOriginRangeConstrain(rot_trans[9], rot_trans[10], rot_trans[11]);
    std::vector<float> check_xyz = forest_p->checkAllLeafAbsolutePosition(frame_window);
    std::vector<char> xyzi_status(pts_num, 1);
    if (optical_flow_on){
        xyzi_status = forest_p->curFrameRecordDynamic(pre_rot_trans[9], pre_rot_trans[10], pre_rot_trans[11], 
                                                                        check_xyz.data(), pts_p, check_xyz.size() / 4, pts_num);//shall be sensor center position
        forest_p->filterVoxelByCurFrame(rot_trans[9], rot_trans[10], rot_trans[11],
                                    check_xyz.data(), pts_p, check_xyz.size() / 4, pts_num);//shall be sensor center position
    }
    // forest_p->addFrameUpdateDynamic(pts_p, xyzi_status.data(), pts_num, rot_trans[9], rot_trans[10], rot_trans[11], tmp_check);
    forest_p->addFrameUpdateDynamic(pts_p, xyzi_status.data(), pts_num, rot_trans[9], rot_trans[10], rot_trans[11]);

    check_xyz = forest_p->checkAllLeafRelativePositionRotMat(rot_trans.data(), true);
    // check_xyz = forest_p->checkAllLeafRelativePosition(quaternion.data(), true);
    // check_xyz = forest_p->checkAllLeafAbsolutePosition(0);

    // std::vector<float> check_xyz;
    // check_xyz.resize(pts_num*4);
    // std::memcpy(check_xyz.data(), ori_pts_p, sizeof(float)*pts_num*4);
    std::vector<float> tmp_check_xyz = check_xyz;

    int map_rows, map_cols, valid_grids_num, record_grids_num;
    const char* flatten_map_p = forest_p->getFlattenMapFromVoxel(tmp_check_xyz.data(), tmp_check_xyz.size()/4, 
                                                                map_rows, map_cols, valid_grids_num);

    marker_grid_cur.points.resize(valid_grids_num);
    valid_grids_num = 0;
    std::memset(map_status_p, 0, map_rows*map_cols);
    mapFilter(flatten_map_p, map_status_p, cal_map_p, map_rows, map_cols, map_filter[0], map_filter[1], map_filter[2]);
    for (int row = 0; row < map_rows; row++){
        for (int col = 0; col < map_cols; col++){
            map_msg.data[row * map_cols + col].occupancy = map_status_p[row * map_cols + col];
            if (map_status_p[row * map_cols + col] == 0) continue;
            geometry_msgs::Point p;
            p.x = (col - static_cast<float>(map_cols / 2)) * grid_resolution + grid_resolution / 2.0f;
            p.y = (row - static_cast<float>(map_rows / 2)) * grid_resolution + grid_resolution / 2.0f;
            p.z = 0.0f;
            marker_grid_cur.points[valid_grids_num] = p;
            valid_grids_num ++;
        }
    }
    marker_grid_cur.points.resize(valid_grids_num);
    if (marker_grid_cur.points.size() != valid_grids_num){std::cout<<"error: unexpected num for grid-cells: "<<valid_grids_num<< ' '<<marker_grid_cur.points.size()<<std::endl;}
    marker_grid_cur.header.stamp = stampe;
    // marker_grid_cur.header.frame_id = "body_norm";

    int voxel_num = check_xyz.size()/4;
    marker_cur.points.resize(voxel_num);
    marker_cur.header.stamp = stampe;
    for (int i = 0; i < voxel_num; i++){
        geometry_msgs::Point p;
        p.x = check_xyz[i*4];
        p.y = check_xyz[i*4 + 1];
        p.z = check_xyz[i*4 + 2];
        marker_cur.points[i] = p;
    }

    // marker_cur.points.resize(pts_num);
    // for (int i = 0; i < pts_num; i++){
    //     geometry_msgs::Point p;
    //     p.x = pts_p[i*4];
    //     p.y = pts_p[i*4 + 1];
    //     p.z = pts_p[i*4 + 2];
    //     marker_cur.points[i] = p;
    // }

    std::vector<float> tmp_map_pose(7);
    multitree::tmpRot2Quaternion(map_rot_trans.data(), tmp_map_pose.data() + 3);
    // tmp_map_pose[0] = rot_trans[9] - static_cast<float>(map_cols / 2) * grid_resolution;
    // tmp_map_pose[1] = rot_trans[10] - static_cast<float>(map_rows / 2) * grid_resolution;
    // tmp_map_pose[2] = rot_trans[11];
    tmp_map_pose[0] = map_rot_trans[9];
    tmp_map_pose[1] = map_rot_trans[10];
    tmp_map_pose[2] = map_rot_trans[11];

    map_msg.header = marker_cur.header;
    map_msg.info.map_load_time = stampe;
    map_msg.info.origin.position.x = tmp_map_pose[0];
    map_msg.info.origin.position.y = tmp_map_pose[1];
    map_msg.info.origin.position.z = tmp_map_pose[2];
    map_msg.info.origin.orientation.w = tmp_map_pose[3];
    map_msg.info.origin.orientation.x = tmp_map_pose[4];
    map_msg.info.origin.orientation.y = tmp_map_pose[5];
    map_msg.info.origin.orientation.z = tmp_map_pose[6];

    map_pub.publish(map_msg);
    marker_pub.publish(marker_pre);
    marker_pub.publish(marker_cur);
    marker_pub.publish(marker_grid_pre);
    marker_pub.publish(marker_grid_cur);
    std::cout<<"pub finish, voxels: "<<voxel_num<<" frame pts num: "<<pts_num<<std::endl;
}

int pcdFilter(const float* pts_p, const int pts_num, const float* rot_mat_p, const float* trans_p,
                        const float* xyz_minmax_p, const float angle_resolution, const float dist_thres, const float* ori_vertikal_at_body_p,
                        float* valid_pts_p){
    float tmp_pts_p[4]; //pts cheated as 4*float, first three is x y z
    float reso2radius_fac_ = (180.0f / angle_resolution) / M_PI;
    int horize_angle_max_id_ = static_cast<int>(360.0f / angle_resolution) - 1;
    float x_min = xyz_minmax_p[0];
    float x_max = xyz_minmax_p[1];
    float y_min = xyz_minmax_p[2];
    float y_max = xyz_minmax_p[3];
    float z_min = xyz_minmax_p[4];
    float z_max = xyz_minmax_p[5];
    int valid_num = 0;
    if (angle_resolution < 0.0f){
        std::cout<<"pcd filter no angle mode "<<pts_num<<std::endl;
        std::cout<<z_min<<' '<<z_max<<std::endl;
        for (int i = 0; i < pts_num; i++){
            std::memcpy(tmp_pts_p, pts_p + i*4, 4*sizeof(float));
            tmpTranPtsRotMat(rot_mat_p, trans_p, tmp_pts_p);
            float x = tmp_pts_p[0];
            float y = tmp_pts_p[1];
            // float z = tmp_pts_p[2];
            float z = tmp_pts_p[0]*ori_vertikal_at_body_p[0] + tmp_pts_p[1]*ori_vertikal_at_body_p[1] + tmp_pts_p[2]*ori_vertikal_at_body_p[2];
            if (x < x_min || x > x_max || y < y_min || y > y_max || z < z_min || z > z_max) continue;
            float horize_dist = std::sqrt(x*x + y*y);
            if (horize_dist <= 1e-5f || horize_dist > dist_thres) continue; 
            std::memcpy(valid_pts_p + valid_num*4, tmp_pts_p, 4*sizeof(float)); 
            valid_num++;
        }
    }
    else{
        std::cout<<"pcd filter angle mode "<<pts_num<<std::endl;
        std::vector<float> stored_pts((horize_angle_max_id_+1)*4, 2000.0f);
        for (int i = 0; i < pts_num; i++){
            std::memcpy(tmp_pts_p, pts_p + i*4, 4*sizeof(float));
            tmpTranPtsRotMat(rot_mat_p, trans_p, tmp_pts_p);
            float x = tmp_pts_p[0];
            float y = tmp_pts_p[1];
            // float z = tmp_pts_p[2];
            float z = tmp_pts_p[0]*ori_vertikal_at_body_p[0] + tmp_pts_p[1]*ori_vertikal_at_body_p[1] + tmp_pts_p[2]*ori_vertikal_at_body_p[2];
            if (z < z_min || z > z_max) continue;
            float horize_dist = std::sqrt(x*x + y*y);
            if (horize_dist <= 1e-5f || horize_dist > dist_thres) continue; 
            float dist = std::sqrt(x*x + y*y + z*z);
            float horize_angle = std::acos(x / horize_dist);
            if (y < 0) horize_angle = 2.0f*M_PI - horize_angle;
            int horize_angle_id = std::max(0, std::min(static_cast<int>(horize_angle * reso2radius_fac_), horize_angle_max_id_));
            if (stored_pts[horize_angle_id*4+3] > dist){
                stored_pts[horize_angle_id*4] = tmp_pts_p[0];
                stored_pts[horize_angle_id*4 + 1] = tmp_pts_p[1];
                stored_pts[horize_angle_id*4 + 2] = tmp_pts_p[2];
                stored_pts[horize_angle_id*4 + 3] = dist;
            }
        }
        std::cout<<"angle max filtered"<<std::endl;
        std::cout<<z_min<<' '<<z_max<<std::endl;
        valid_num = 0;
        for (int i = 0; i <= horize_angle_max_id_; i++){
            if (stored_pts[i*4+3]<1000.0f){
                std::memcpy(valid_pts_p + (valid_num)*4, stored_pts.data()+i*4, 4*sizeof(float)); 
                valid_num++;
            } 
        }
    }
    std::cout<<"filter pcd finish, pts num: "<<valid_num<<std::endl;
    return valid_num;
}

int boxPtsFilter(const int pts_num, float* pts_p, 
                const std::vector<float> &box_center_x_list, const std::vector<float> &box_center_y_list, const std::vector<float> &box_center_z_list,
                const std::vector<float> &box_range_x_list, const std::vector<float> &box_range_y_list, const std::vector<float> &box_range_z_list){
    int valid_num = pts_num;
    int ori_num = pts_num;
    int num_filters = box_center_x_list.size();
    for (int i = 0; i < num_filters; i++){
        float box_x_up = box_center_x_list[i] + box_range_x_list[i];
        float box_y_up = box_center_y_list[i] + box_range_y_list[i];
        float box_z_up = box_center_z_list[i] + box_range_z_list[i];
        float box_x_low = box_center_x_list[i] - box_range_x_list[i];
        float box_y_low = box_center_y_list[i] - box_range_y_list[i];
        float box_z_low = box_center_z_list[i] - box_range_z_list[i];
        ori_num = valid_num;
        valid_num = 0;
        for (int j = 0; j < ori_num; j++){
            float x = pts_p[j*4];
            float y = pts_p[j*4 + 1];
            float z = pts_p[j*4 + 2];
            if (x > box_x_low && x < box_x_up && y > box_y_low && y < box_y_up && z > box_z_low && z < box_z_up) continue;
            std::memcpy(pts_p + valid_num*4, pts_p + j*4, 4*sizeof(float));
            valid_num++;
        }
    }
    return valid_num;
}

int dynamicBoxPtsFilter(const int pts_num, float* pts_p,
                        const int box_num, const float* box_with_pose_args_p, const float* body2ref_rot_trans_p, 
                        const int offset = 10){
    int valid_num = pts_num;
    int ori_num = pts_num;
    int num_filters = box_num;
    for (int i = 0; i < num_filters; i++){
        std::vector<float> pose(7);
        std::memcpy(pose.data(), box_with_pose_args_p + i*offset, 7*sizeof(float));
        std::vector<float> box_len(3);
        std::memcpy(box_len.data(), box_with_pose_args_p + i*offset + 7, 3*sizeof(float));
        std::vector<float> rot_trans_box(12);
        multitree::quaternion2Rotation(pose.data() + 3, rot_trans_box.data());
        std::memcpy(rot_trans_box.data() + 9, pose.data(), 3*sizeof(float));
        std::vector<float> body2box_rot_trans(12);
        std::memcpy(body2box_rot_trans.data(), body2ref_rot_trans_p, 12*sizeof(float));
        tmpTransMatFuse(rot_trans_box.data(), rot_trans_box.data() + 9, false, body2box_rot_trans.data(), body2box_rot_trans.data() + 9);
        float x_thres = box_len[0]/2.0f;
        float y_thres = box_len[1]/2.0f;
        float z_thres = box_len[2]/2.0f;
        std::vector<float> center_in_body(3, 0.0f);
        std::vector<float> x_vec_in_body = {1.0f, 0.0f, 0.0f};
        std::vector<float> y_vec_in_body = {0.0f, 1.0f, 0.0f};
        std::vector<float> z_vec_in_body = {0.0f, 0.0f, 1.0f};
        tmpInverseRotMat(body2box_rot_trans.data(), center_in_body.data(), x_vec_in_body.data(), 1, false);
        tmpInverseRotMat(body2box_rot_trans.data(), center_in_body.data(), y_vec_in_body.data(), 1, false);
        tmpInverseRotMat(body2box_rot_trans.data(), center_in_body.data(), z_vec_in_body.data(), 1, false);
        std::memcpy(center_in_body.data(), body2box_rot_trans.data() + 9, 3*sizeof(float));
        ori_num = valid_num;
        valid_num = 0;
        for (int j = 0; j < ori_num; j++){
            std::vector<float> pts_center_vec = {center_in_body[0] - pts_p[j*4], center_in_body[1] - pts_p[j*4 + 1], center_in_body[2] - pts_p[j*4 + 2]};
            float x_dot = std::abs((pts_center_vec[0]*x_vec_in_body[0] + pts_center_vec[1]*x_vec_in_body[1] + pts_center_vec[2]*x_vec_in_body[2]));
            float y_dot = std::abs((pts_center_vec[0]*y_vec_in_body[0] + pts_center_vec[1]*y_vec_in_body[1] + pts_center_vec[2]*y_vec_in_body[2]));
            float z_dot = std::abs((pts_center_vec[0]*z_vec_in_body[0] + pts_center_vec[1]*z_vec_in_body[1] + pts_center_vec[2]*z_vec_in_body[2]));
            if (x_dot <= x_thres && y_dot <= y_thres && z_dot <= z_thres) continue;
            std::memcpy(pts_p + valid_num*4, pts_p + j*4, 4*sizeof(float));
            valid_num++;
        }
        std::cout<<"box id "<<i<<' '<<center_in_body[0]<<' '<<center_in_body[1]<<' '<<center_in_body[2]<<' '<<ori_num - valid_num<<std::endl;
        std::cout<<x_vec_in_body[0]<<' '<<x_vec_in_body[1]<<' '<<x_vec_in_body[2]
                <<','<<y_vec_in_body[0]<<' '<<y_vec_in_body[1]<<' '<<y_vec_in_body[2]
                <<','<<z_vec_in_body[0]<<' '<<z_vec_in_body[1]<<' '<<z_vec_in_body[2]<<std::endl;
        std::cout<<"box range: "<<x_thres<<' '<<y_thres<<' '<<z_thres<<std::endl;
    }
    std::cout<<"bbox filter pcd finish, pts num: "<<valid_num<<std::endl;
    return valid_num;
}

int findMatchIdFromTimeStampeQueue(const ros::Time &check_time, const std::vector<ros::Time> &time_stampe_queue){
    ros::Duration diff = check_time - time_stampe_queue[0];
    double abs_time_diff_min = std::abs(diff.toSec());
    int match_id = 0;
    for (int i = 1; i < time_stampe_queue.size(); i++){
        diff = check_time - time_stampe_queue[i];
        double tmp_abs_diff = std::abs(diff.toSec());
        if (tmp_abs_diff < abs_time_diff_min){
            abs_time_diff_min = tmp_abs_diff;
            match_id = i;
        }
    }
    return match_id;
}

int main(int argc, char** argv){
    nlohmann::json forest_cfg;
    std::string agent_type;
    if (argc == 2) {
        agent_type = argv[1];
        std::cout<<"agent type manual defined: "<<agent_type<<std::endl;
    }
    else{
        agent_type = std::getenv("ROBOT_MODEL");
        std::cout<<"no agent type manual defined, using env arg instead: "<<agent_type<<std::endl;
    }
    std::string cfg_path;
    if (agent_type == "humanoid") {cfg_path = "../config_humanoid.json";}
    else if (agent_type == "wa1") {cfg_path = "../config_wa1.json";}
    else if (agent_type == "wa2") {cfg_path = "../config_wa2.json";}
    else{
        while(1) std::cout<<"agent type should be one of these:"<<std::endl
                            <<"humanoid, wa1, wa2"<<std::endl;
    }
    json::customfunc::getJsonFromFile(cfg_path, forest_cfg);
    std::string preference_yaml_path = forest_cfg.at("preference_yaml_path").get<std::string>();
    nlohmann::json topic_args = forest_cfg.at("topic_args").get<nlohmann::json>();
    nlohmann::json forest_base_args = forest_cfg.at("forest_base_args").get<nlohmann::json>();
    nlohmann::json optical_flow_args = forest_cfg.at("optical_flow_args").get<nlohmann::json>();
    nlohmann::json flatten_map_args = forest_cfg.at("flatten_map_args").get<nlohmann::json>();
    nlohmann::json pts_msg_filter_args = forest_cfg.at("pts_msg_filter_args").get<nlohmann::json>();
    nlohmann::json box_pts_filter_args = forest_cfg.at("box_pts_filter_args").get<nlohmann::json>();
    nlohmann::json body_filter_args = forest_cfg.at("body_filter_args").get<nlohmann::json>();
    int test_pose_id = forest_cfg.at("test_pose_id").get<int>();
    std::vector<float> sensor_extra_trans_mat = forest_cfg.at("sensor_extra_trans_mat").get<std::vector<float>>();
    //实际上是初始odom-init的位置的偏移，但是因为和lidar-imu绑定，因此采用sensor安装矩阵的命名形式

    std::string ros_node_id = topic_args.at("ros_node_id").get<std::string>();
    std::string localization_pose_topic_id = topic_args.at("localization_pose_topic_id").get<std::string>();
    std::string odometer_pose_topic_id = topic_args.at("odometer_pose_topic_id").get<std::string>();
    std::string pose_aim_frame = topic_args.at("pose_aim_frame").get<std::string>();
    std::vector<std::string> pts_topic_ids = topic_args.at("pts_topic_ids").get<std::vector<std::string>>();
    std::vector<std::string> static_frames_pts = topic_args.at("static_frames_pts").get<std::vector<std::string>>();
    std::string voxel_topic_id = topic_args.at("voxel_topic_id").get<std::string>();
    std::string global_topic_frame_id = topic_args.at("global_topic_frame_id").get<std::string>();
    std::string voxel_topic_namespace = topic_args.at("voxel_topic_namespace").get<std::string>();
    std::string flatten_grid_topic_namespace = topic_args.at("flatten_grid_topic_namespace").get<std::string>();
    std::string flatten_full_map_pub_topic_id = topic_args.at("flatten_full_map_pub_topic_id").get<std::string>();
    std::string box_arr_filter_topic = topic_args.at("box_arr_filter_topic").get<std::string>();
    std::vector<std::string> pts_repalce_from_yaml_list = topic_args.at("pts_repalce_from_yaml_list").get<std::vector<std::string>>();
    std::string yaml_preference_node_name = topic_args.at("yaml_preference_node_name").get<std::string>();
    std::vector<std::string> yaml_replace_list = topic_args.at("yaml_replace_list").get<std::vector<std::string>>();

    YAML::Node preference_config = YAML::LoadFile(preference_yaml_path);
    YAML::Node preference_topic = preference_config["yaml_preference_node_name"];
    if (pts_repalce_from_yaml_list.size() == pts_topic_ids.size()){
        for (int i = 0; i < pts_topic_ids.size(); i++){
            YAML::Node tmp_node = preference_topic[pts_repalce_from_yaml_list[i]];
            if (!tmp_node.IsNull()){
                if (tmp_node.as<std::string>() != "") pts_topic_ids[i] = tmp_node.as<std::string>();
            }
        }
    }
    else{
        std::cout<<"incompatible point cloud topics for yaml & intern defined, expect "
                <<pts_topic_ids.size()<<" but get " <<pts_repalce_from_yaml_list.size()<<", ignored"<<std::endl;
    }
    std::unordered_map<std::string, std::string> replace_table = {{"localization_pose_topic_id", localization_pose_topic_id},
                                                                {"odometer_pose_topic_id", odometer_pose_topic_id},
                                                                {"voxel_topic_id", voxel_topic_id},
                                                                {"flatten_full_map_pub_topic_id", flatten_full_map_pub_topic_id},
                                                                {"box_arr_filter_topic", box_arr_filter_topic}};
    for (int i = 0; i < yaml_replace_list.size(); i++){
        std::string json_key = yaml_replace_list[i*2];
        std::string yaml_key = yaml_replace_list[i*2 + 1];
        if (replace_table.count(json_key) == 0){
            std::cout<<"not a pre-defined topic id name: "<<json_key<<", skiped"<<std::endl;
            continue;
        }
        if (!preference_topic[yaml_key].IsNull()){
            if (preference_topic[yaml_key].as<std::string>() != "") replace_table[json_key] = preference_topic[yaml_key].as<std::string>();
        }
    }
    localization_pose_topic_id = replace_table.at("localization_pose_topic_id");
    odometer_pose_topic_id = replace_table.at("odometer_pose_topic_id");
    voxel_topic_id = replace_table.at("voxel_topic_id");
    flatten_full_map_pub_topic_id = replace_table.at("flatten_full_map_pub_topic_id");
    box_arr_filter_topic = replace_table.at("box_arr_filter_topic");

    int log_root_level_x = forest_base_args.at("log_root_level_x").get<int>();
    int log_root_level_y = forest_base_args.at("log_root_level_y").get<int>();
    int log_root_level_z = forest_base_args.at("log_root_level_z").get<int>();
    int log_level_branch = forest_base_args.at("log_level_branch").get<int>();
    int log_level_leaf = forest_base_args.at("log_level_leaf").get<int>();
    int estimate_pts_num = forest_base_args.at("estimate_pts_num").get<int>();
    int estimate_voxel_num = forest_base_args.at("estimate_voxel_num").get<int>();
    float resolution = forest_base_args.at("resolution").get<float>();
    float angle_resolution = forest_base_args.at("angle_resolution").get<float>();
    int single_mode = forest_base_args.at("single_mode").get<int>();
    int frame_window = forest_base_args.at("frame_window").get<int>();
    float extern_defined_range_x = forest_base_args.at("extern_defined_range_x").get<float>();
    float extern_defined_range_y = forest_base_args.at("extern_defined_range_y").get<float>();
    float extern_defined_range_z = forest_base_args.at("extern_defined_range_z").get<float>();

    bool optical_flow_on = optical_flow_args.at("optical_flow_on").get<bool>();
    int catch_dist_adjust_mode = optical_flow_args.at("catch_dist_adjust_mode").get<int>();
    float catch_dist_angle_factor = optical_flow_args.at("catch_dist_angle_factor").get<float>();
    float voxel_filter_pts_occlusion_range = optical_flow_args.at("voxel_filter_pts_occlusion_range").get<float>();
    float voxel_filter_line_range = optical_flow_args.at("voxel_filter_line_range").get<float>();
    float voxel_filter_catch_dist_threshold = optical_flow_args.at("voxel_filter_catch_dist_threshold").get<float>();
    float voxel_filter_catch_angle_threshold = optical_flow_args.at("voxel_filter_catch_angle_threshold").get<float>();
    float pts_filter_voxel_occlusion_range = optical_flow_args.at("pts_filter_voxel_occlusion_range").get<float>();
    float pts_filter_line_range = optical_flow_args.at("pts_filter_line_range").get<float>();
    float pts_filter_catch_dist_threshold = optical_flow_args.at("pts_filter_catch_dist_threshold").get<float>();
    float pts_filter_catch_angle_threshold = optical_flow_args.at("pts_filter_catch_angle_threshold").get<float>();

    float z_min_threshold = flatten_map_args.at("z_min_threshold").get<float>();
    float z_max_threshold = flatten_map_args.at("z_max_threshold").get<float>();
    float map_x_range = flatten_map_args.at("map_x_range").get<float>(); 
    float map_y_range = flatten_map_args.at("map_y_range").get<float>(); 
    float map_resolution = flatten_map_args.at("map_resolution").get<float>();
    std::vector<int> map_filter = flatten_map_args.at("map_filter").get<std::vector<int>>();

    float pts_x_min = pts_msg_filter_args.at("x_min_threshold").get<float>();
    float pts_x_max = pts_msg_filter_args.at("x_max_threshold").get<float>();
    float pts_y_min = pts_msg_filter_args.at("y_min_threshold").get<float>();
    float pts_y_max = pts_msg_filter_args.at("y_max_threshold").get<float>();
    float pts_z_min = pts_msg_filter_args.at("z_min_threshold").get<float>();
    float pts_z_max = pts_msg_filter_args.at("z_max_threshold").get<float>();
    float pts_angle_resolution = pts_msg_filter_args.at("angle_resolution").get<float>();
    float pts_dist_threshold = pts_msg_filter_args.at("dist_threshold").get<float>();
    bool body_align_mode = pts_msg_filter_args.at("body_align_mode").get<bool>();
    bool local_coordinate_align = pts_msg_filter_args.at("local_coordinate_align").get<bool>();
    if (!body_align_mode) local_coordinate_align = false;

    std::vector<float> box_center_x_list = box_pts_filter_args.at("box_center_x_list").get<std::vector<float>>();
    std::vector<float> box_center_y_list = box_pts_filter_args.at("box_center_y_list").get<std::vector<float>>();
    std::vector<float> box_center_z_list = box_pts_filter_args.at("box_center_z_list").get<std::vector<float>>();
    std::vector<float> box_range_x_list = box_pts_filter_args.at("box_range_x_list").get<std::vector<float>>();
    std::vector<float> box_range_y_list = box_pts_filter_args.at("box_range_y_list").get<std::vector<float>>();
    std::vector<float> box_range_z_list = box_pts_filter_args.at("box_range_z_list").get<std::vector<float>>();

    int box_estimate_num = body_filter_args.at("box_estimate_num").get<int>();
    std::vector<float> body2dynamic_body_ref_rot_trans = body_filter_args.at("body_norm2root_trans_mat").get<std::vector<float>>();

    ros::init(argc, argv, "test_grid");
    ros::NodeHandle pcd_nh(ros_node_id);
    ros::Rate loop_rate(10);
    ros::Publisher marker_pub = pcd_nh.advertise<visualization_msgs::Marker>(voxel_topic_id, 0);
    float cube_size = resolution;
    int idx = 0;
    visualization_msgs::Marker marker_pre;
    visualization_msgs::Marker marker_cur;
    marker_pre.header.frame_id = global_topic_frame_id;
    marker_pre.header.stamp = ros::Time();
    marker_pre.ns = voxel_topic_namespace;
    marker_pre.id = idx;
    marker_pre.type = visualization_msgs::Marker::CUBE_LIST;
    marker_pre.action = visualization_msgs::Marker::ADD;
    marker_pre.pose.position.x = 0;
    marker_pre.pose.position.y = 0;
    marker_pre.pose.position.z = 0;
    marker_pre.pose.orientation.x = 0.0;
    marker_pre.pose.orientation.y = 0.0;
    marker_pre.pose.orientation.z = 0.0;
    marker_pre.pose.orientation.w = 1.0;
    marker_pre.scale.x = cube_size;
    marker_pre.scale.y = cube_size;
    marker_pre.scale.z = cube_size;
    marker_pre.color.a = 1.0; // Don't forget to set the alpha!
    marker_pre.color.r = 0.0;
    marker_pre.color.g = 1.0;
    marker_pre.color.b = 0.0;
    marker_cur = marker_pre;
    marker_pub.publish(marker_pre);

    visualization_msgs::Marker marker_grid_pre;
    visualization_msgs::Marker marker_grid_cur;
    marker_grid_pre.header.frame_id = global_topic_frame_id;
    marker_grid_pre.header.stamp = ros::Time();
    marker_grid_pre.ns = flatten_grid_topic_namespace;
    marker_grid_pre.id = idx;
    marker_grid_pre.type = visualization_msgs::Marker::CUBE_LIST;
    marker_grid_pre.action = visualization_msgs::Marker::ADD;
    marker_grid_pre.pose.position.x = 0;
    marker_grid_pre.pose.position.y = 0;
    marker_grid_pre.pose.position.z = 0;
    marker_grid_pre.pose.orientation.x = 0.0;
    marker_grid_pre.pose.orientation.y = 0.0;
    marker_grid_pre.pose.orientation.z = 0.0;
    marker_grid_pre.pose.orientation.w = 1.0;
    marker_grid_pre.scale.x = map_resolution;
    marker_grid_pre.scale.y = map_resolution;
    marker_grid_pre.scale.z = map_resolution;
    marker_grid_pre.color.a = 1.0; // Don't forget to set the alpha!
    marker_grid_pre.color.r = 1.0;
    marker_grid_pre.color.g = 0.95;
    marker_grid_pre.color.b = 0.25;
    marker_grid_cur = marker_grid_pre;
    marker_pub.publish(marker_grid_pre);

    std::vector<float> localization_pose_queue(7*20, 0.0f);
    std::vector<ros::Time> localization_pose_time_stampe_queue(20);
    std::vector<float> odometer_pose_queue(7*20, 0.0f);
    std::vector<ros::Time> odometer_pose_time_stampe_queue(20);

    int pcds_num = pts_topic_ids.size();
    std::vector<std::vector<float>> ptss(pcds_num);
    std::vector<std::vector<float>> sensor_body_poses(pcds_num);
    std::vector<int> pts_nums(pcds_num, 0);
    std::vector<ros::Time> pcds_time_stampe(pcds_num);
    ros::Subscriber localization_odom_sub = pcd_nh.subscribe<nav_msgs::Odometry>(localization_pose_topic_id, 20, 
                                                boost::bind(&odomCallback, _1, localization_pose_time_stampe_queue.data(), localization_pose_queue.data()));
    ros::Subscriber odometer_odom_sub = pcd_nh.subscribe<nav_msgs::Odometry>(odometer_pose_topic_id, 20, 
                                                boost::bind(&odomCallback, _1, odometer_pose_time_stampe_queue.data(), odometer_pose_queue.data()));
    std::vector<ros::Subscriber> pcd_subs(pcds_num);

    ros::Time box_with_pose_time_stamp;
    std::vector<float> box_with_pose(box_estimate_num*10*2);
    ros::Subscriber robot_box_sub = pcd_nh.subscribe<visualization_msgs::MarkerArray>(box_arr_filter_topic, 1, 
                                                boost::bind(&markerArrayCallback, _1, &box_with_pose_time_stamp, box_with_pose.data(), &box_estimate_num));

    std::vector<float> xyz_minmax = {pts_x_min, pts_x_max, pts_y_min, pts_y_max, pts_z_min, pts_z_max};
    for (int i = 0; i < pcds_num; i++){
        ptss[i].resize(estimate_pts_num*4, 0.0f);
        sensor_body_poses[i].resize(7, 0.0f);
        // pcd_subs[i] = pcd_nh.subscribe<sensor_msgs::PointCloud2>(pts_topic_ids[i], 1,
        //                                         boost::bind(&pcdCallback1Filtered, _1, &(pcds_time_stampe[i]), ptss[i].data(), &(pts_nums[i]), 
        //                                                     sensor_body_poses[i].data(),
        //                                                     xyz_minmax.data(),
        //                                                     pts_angle_resolution, pts_dist_threshold));
        pcd_subs[i] = pcd_nh.subscribe<sensor_msgs::PointCloud2>(pts_topic_ids[i], 1,
                                                boost::bind(&pcdCallback1, _1, &(pcds_time_stampe[i]), ptss[i].data(), &(pts_nums[i])));
    }

    multitree::BiLayerCubicTreeForest* test_forest = new multitree::BiLayerCubicTreeForest(log_root_level_x, log_root_level_y, log_root_level_z,
                                                                                        log_level_branch, log_level_leaf,
                                                                                        estimate_pts_num, estimate_voxel_num,
                                                                                        resolution, angle_resolution, single_mode,
                                                                                        extern_defined_range_x, extern_defined_range_y, extern_defined_range_z);
    test_forest->setOpticalFlowArgs(catch_dist_adjust_mode, catch_dist_angle_factor, 
                                    voxel_filter_pts_occlusion_range, voxel_filter_line_range, 
                                    voxel_filter_catch_dist_threshold, voxel_filter_catch_angle_threshold, 
                                    pts_filter_voxel_occlusion_range, pts_filter_line_range, 
                                    pts_filter_catch_dist_threshold, pts_filter_catch_angle_threshold);
    test_forest->setFlattenArgs(z_min_threshold, z_max_threshold, map_x_range, map_y_range, map_resolution);

    int map_rows, map_cols;
    test_forest->getFlattenMapSize(map_rows, map_cols);
    std::vector<float> localization_pose(7, 0.0f);
    ros::Time localization_pose_time_stampe;
    std::vector<float> odometer_pose(7, 0.0f);
    ros::Time odometer_pose_time_stampe;
    std::vector<float> pre_odometer_pose = odometer_pose;
    std::vector<int> cal_map(map_rows * map_cols);
    std::vector<char> map_status(map_rows * map_cols);
    ros::Publisher map_pub = pcd_nh.advertise<navigation::LocalMap>(flatten_full_map_pub_topic_id, 0);
    navigation::LocalMap map_msg;
    map_msg.info.resolution = map_resolution;
    map_msg.info.width = map_cols;
    map_msg.info.height = map_rows;
    map_msg.data.resize(map_rows * map_cols);

    tf::TransformListener listener;
    tf::StampedTransform transform;
    float tmp[7];
    std::vector<float> ref_pose(7, 0.0f);
    ref_pose[3] = 1.0f;
    if (pose_aim_frame != ""){
        while (ros::ok()){
            try{
                ros::Time now = ros::Time(0);
                listener.waitForTransform(pose_aim_frame, global_topic_frame_id, now, ros::Duration(0.1));
                listener.lookupTransform(pose_aim_frame, global_topic_frame_id, now, transform);
                getPoseFromTrans(tmp, transform);
                for (int i = 0; i < 7; i++) ref_pose[i] = tmp[i];
                std::cout<<"get ref pose from start"<<std::endl;
                break;
            }
            catch (tf::TransformException(&ex)){
                continue;
            }
        }
    }
    
    std::vector<std::vector<float>> sensor_body_rot(pcds_num);
    for (int i = 0; i < pcds_num; i++){
        while (ros::ok()){
            try{
                ros::Time now = ros::Time(0);
                listener.waitForTransform(global_topic_frame_id, static_frames_pts[i], now, ros::Duration(0.1));
                listener.lookupTransform(global_topic_frame_id, static_frames_pts[i], now, transform);
                getPoseFromTrans(tmp, transform);
                for (int j = 0; j < 7; j++) sensor_body_poses[i][j] = tmp[j];
                std::cout<<"get ref pose from start: "<<global_topic_frame_id<<" to "<<static_frames_pts[i]<<std::endl;
                sensor_body_rot[i].resize(9);
                multitree::quaternion2Rotation(sensor_body_poses[i].data() + 3, sensor_body_rot[i].data());
                break;
            }
            catch (tf::TransformException(&ex)){
                continue;
            }
        }
    }

    std::vector<float> sensor_rot_mat(9);
    std::vector<float> sensor_trans_mat(3);
    std::vector<float> aligned_xyz_minmax = xyz_minmax;
    std::vector<std::vector<float>> pose_serial(10);
    std::vector<ros::Time> time_stamp_serial(10);
    for (int i = 0; i < 10; i++) pose_serial[i].resize(7);

    while (ros::ok()){
        std::cout<<"start one frame"<<std::endl;
ros::spinOnce();
        ros::Duration time_bias(0.00);
        ros::Time check_time = pcds_time_stampe[0] + time_bias;
        int odometer_match_id = findMatchIdFromTimeStampeQueue(check_time, odometer_pose_time_stampe_queue);
        std::memcpy(odometer_pose.data(), odometer_pose_queue.data() + odometer_match_id*7, sizeof(float)*7);
        odometer_pose_time_stampe = odometer_pose_time_stampe_queue[odometer_match_id];
        int localization_match_id = findMatchIdFromTimeStampeQueue(check_time, localization_pose_time_stampe_queue);
        std::memcpy(localization_pose.data(), localization_pose_queue.data() + localization_match_id*7, sizeof(float)*7);
        localization_pose_time_stampe = localization_pose_time_stampe_queue[localization_match_id];

        for (int i = 0; i < pcds_num; i++) std::cout<<pcds_time_stampe[i].sec<<'.'<<std::setw(9)<<std::setfill('0')<<pcds_time_stampe[i].nsec<<std::endl;
        std::cout<<odometer_pose_time_stampe.sec<<'.'<<std::setw(9)<<std::setfill('0')<<odometer_pose_time_stampe.nsec<<std::endl;
        std::cout<<localization_pose_time_stampe.sec<<'.'<<std::setw(9)<<std::setfill('0')<<localization_pose_time_stampe.nsec<<std::endl;
        
        // std::cout<<"test 1"<<std::endl;
        // if (1 ||(pcd_pose_time_stampe.sec == pcd_time_stampe.sec && pcd_pose_time_stampe.nsec == pcd_time_stampe.nsec)){
            auto t0 = std::chrono::system_clock::now();

            // int total_num = 0;
            // for (int i = 0; i < pcds_num; i++) total_num += pts_nums[i];

            int total_num = 0;
            std::vector<float> pose_rot(9);
            multitree::quaternion2Rotation(odometer_pose.data() + 3, pose_rot.data());
            std::vector<float> pose_trans(3, 0.0f);
            std::memcpy(pose_trans.data(), odometer_pose.data(), 3*sizeof(float));
            std::vector<float> tmp_ref_rot(9);
            multitree::quaternion2Rotation(ref_pose.data() + 3, tmp_ref_rot.data());
            std::vector<float> tmp_ref_trans(3, 0.0f);
            std::memcpy(tmp_ref_trans.data(), ref_pose.data(), 3*sizeof(float));
            tmpTransMatFuse(tmp_ref_rot.data(), tmp_ref_trans.data(), false, pose_rot.data(), pose_trans.data());
            float yaw = getYawFromRotMat(pose_rot.data());
            std::vector<float> rot_yaw = getRotMatFromYaw(yaw);

            std::memset(sensor_rot_mat.data(), 0, sizeof(float)*9);
            std::memset(sensor_trans_mat.data(), 0, sizeof(float)*3);
            sensor_rot_mat[0] = 1.0f; sensor_rot_mat[4] = 1.0f; sensor_rot_mat[8] = 1.0f;
            if (body_align_mode){
                // std::cout<<"odom_trans: "
                //                 <<pose_trans[0]<<' '<<pose_trans[1]<< ' '<<pose_trans[2]<<std::endl;
                tmpTransMatFuse(rot_yaw.data(), pose_trans.data(), true, sensor_rot_mat.data(), sensor_trans_mat.data());
                // std::cout<<"algin_trans_mat: "<<sensor_rot_mat[0]<<' '<<sensor_rot_mat[1]<< ' '<<sensor_rot_mat[2]<<std::endl
                //                 <<sensor_rot_mat[3]<<' '<<sensor_rot_mat[4]<< ' '<<sensor_rot_mat[5]<<std::endl
                //                 <<sensor_rot_mat[6]<<' '<<sensor_rot_mat[7]<< ' '<<sensor_rot_mat[8]<<std::endl
                //                 <<sensor_trans_mat[0]<<' '<<sensor_trans_mat[1]<< ' '<<sensor_trans_mat[2]<<std::endl;
                tmpTransMatFuse(pose_rot.data(), pose_trans.data(), false, sensor_rot_mat.data(), sensor_trans_mat.data());
                // std::cout<<"algin_trans_mat: "<<sensor_rot_mat[0]<<' '<<sensor_rot_mat[1]<< ' '<<sensor_rot_mat[2]<<std::endl
                //                 <<sensor_rot_mat[3]<<' '<<sensor_rot_mat[4]<< ' '<<sensor_rot_mat[5]<<std::endl
                //                 <<sensor_rot_mat[6]<<' '<<sensor_rot_mat[7]<< ' '<<sensor_rot_mat[8]<<std::endl
                //                 <<sensor_trans_mat[0]<<' '<<sensor_trans_mat[1]<< ' '<<sensor_trans_mat[2]<<std::endl;
            }
            std::vector<float> tmp_store_rot = sensor_rot_mat;
            std::vector<float> tmp_store_trans = sensor_trans_mat;
            // std::cout<<"algin_trans_mat: "<<sensor_rot_mat[0]<<' '<<sensor_rot_mat[1]<< ' '<<sensor_rot_mat[2]<<std::endl
            //                 <<sensor_rot_mat[3]<<' '<<sensor_rot_mat[4]<< ' '<<sensor_rot_mat[5]<<std::endl
            //                 <<sensor_rot_mat[6]<<' '<<sensor_rot_mat[7]<< ' '<<sensor_rot_mat[8]<<std::endl
            //                 <<sensor_trans_mat[0]<<' '<<sensor_trans_mat[1]<< ' '<<sensor_trans_mat[2]<<std::endl;
            float aligned_z_min = -std::abs(tmp_store_rot[8] * pts_z_min);
            std::vector<float> ori_vertikal_at_body(3);
            ori_vertikal_at_body[0] = 0.0f; ori_vertikal_at_body[1] = 0.0f; ori_vertikal_at_body[2] = 1.0f;
            // if (local_coordinate_align){
                aligned_xyz_minmax[4] = aligned_z_min;
                // aligned_xyz_minmax[5] = aligned_z_max;
            // }
            for (int i = 0; i < pcds_num; i++){
                if (local_coordinate_align){
                    sensor_rot_mat = tmp_store_rot;
                    sensor_trans_mat = tmp_store_trans;
                    tmpTransMatFuse(sensor_body_rot[i].data(), sensor_body_poses[i].data(), false, sensor_rot_mat.data(), sensor_trans_mat.data());
                }
                else{
                    sensor_rot_mat = sensor_body_rot[i];
                    sensor_trans_mat[0] = sensor_body_poses[i][0]; sensor_trans_mat[1] = sensor_body_poses[i][1]; sensor_trans_mat[2] = sensor_body_poses[i][2];
                    tmpInverseRotMat(tmp_store_rot.data(), tmp_store_trans.data(), ori_vertikal_at_body.data(), 1, true);
                }
                std::cout<<aligned_xyz_minmax[4]<<' '<<aligned_xyz_minmax[5]<<std::endl;
                int tmp_valid_num = pcdFilter(ptss[i].data(), pts_nums[i], sensor_rot_mat.data(), sensor_trans_mat.data(),
                        aligned_xyz_minmax.data(), pts_angle_resolution, pts_dist_threshold, ori_vertikal_at_body.data(),
                        ptss[i].data());
                total_num += tmp_valid_num;
                pts_nums[i] = tmp_valid_num;
            }

            std::vector<float> pts(total_num*4, 0.0f);
            total_num = 0;
            for (int i = 0; i < pcds_num; i++){
                std::memcpy(pts.data() + 4*total_num, ptss[i].data(), 4*pts_nums[i]*sizeof(float));
                total_num += pts_nums[i];
                pts_nums[i] = 0;
            }
            total_num = boxPtsFilter(total_num, pts.data(), 
                                    box_center_x_list, box_center_y_list, box_center_z_list,
                                    box_range_x_list, box_range_y_list, box_range_z_list);
            total_num = dynamicBoxPtsFilter(total_num, pts.data(), box_estimate_num, box_with_pose.data(), body2dynamic_body_ref_rot_trans.data(), 10);
            voxelPublish(test_forest, marker_pub, map_pub,
                        pts.data(), 
                        odometer_pose.data(),
                        // odometer_pose_queue.data() + odometer_match_id*7,
                        // pose_serial[9].data(), 
                        total_num, pre_odometer_pose.data(), ref_pose.data(), localization_pose.data(), sensor_extra_trans_mat.data(),
                        cal_map.data(), map_status.data(), frame_window,
                        marker_pre, marker_cur, map_msg,
                        marker_grid_pre, marker_grid_cur, 
                        odometer_pose_time_stampe, 
                        // odometer_pose_time_stampe_queue[odometer_match_id],
                        // time_stamp_serial[9],
                        map_resolution, map_filter,
                        local_coordinate_align, optical_flow_on);
            auto t1 = std::chrono::system_clock::now();
            double duration0 = std::chrono::duration<double>(t1 - t0).count();
            duration0 *= 1000.0f;
            std::cout<<"voxel & grid total cost: "<<duration0<<" ms"<<std::endl;
        // }
        loop_rate.sleep();
        std::cout<<"finish one frame"<<std::endl;
        pre_odometer_pose = odometer_pose;
        // for (int i = 0; i < 9; i++) time_stamp_serial[i] = time_stamp_serial[i+1];
        // time_stamp_serial[9] = odometer_pose_time_stampe;
        // for (int i = 0; i < 9; i++) std::memcpy(pose_serial[i].data(), pose_serial[i+1].data(), sizeof(float)*7);
        // std::memcpy(pose_serial[9].data(), pre_odometer_pose.data(), sizeof(float)*7);
    }

    delete test_forest;
    test_forest = nullptr;

    return 0;
}