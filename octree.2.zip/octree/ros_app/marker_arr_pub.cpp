#include <iostream>
#include <ros/ros.h>
#include <visualization_msgs/MarkerArray.h>

#include <math.h>

int main(int argc, char** argv){
    ros::init(argc, argv, "test_bbox");
    ros::NodeHandle pcd_nh("test_bbox_node");
    ros::Rate loop_rate(10);
    ros::Publisher marker_pub = pcd_nh.advertise<visualization_msgs::MarkerArray>("bbox_list", 0);
    ros::Publisher box_msg_pub = pcd_nh.advertise<visualization_msgs::MarkerArray>("bbox_arr", 0);

    visualization_msgs::Marker marker_model;
    marker_model.header.frame_id = "body_norm";
    marker_model.header.stamp = ros::Time();
    marker_model.ns = "test_bbox_with_pose";
    marker_model.type = visualization_msgs::Marker::CUBE;
    marker_model.action = visualization_msgs::Marker::ADD;
    marker_model.pose.position.x = 0;
    marker_model.pose.position.y = 0;
    marker_model.pose.position.z = 0;
    marker_model.pose.orientation.x = 0.0;
    marker_model.pose.orientation.y = 0.0;
    marker_model.pose.orientation.z = 0.0;
    marker_model.pose.orientation.w = 1.0;
    marker_model.scale.x = 1.0;
    marker_model.scale.y = 0.5;
    marker_model.scale.z = 0.5;
    marker_model.color.a = 0.3; // Don't forget to set the alpha!
    marker_model.color.r = 0.0;
    marker_model.color.g = 0.0;
    marker_model.color.b = 1.0;

    visualization_msgs::MarkerArray box_cur;
    box_cur.markers.resize(3);
    box_cur.markers[0] = marker_model;
    box_cur.markers[1] = marker_model;
    box_cur.markers[2] = marker_model;
    box_cur.markers[1].pose.position.x = 1.5;
    box_cur.markers[1].pose.orientation.x = 0.5;
    box_cur.markers[1].pose.orientation.w = 0.5*std::sqrt(3.0f);
    box_cur.markers[2].pose.position.y = 1.5;
    box_cur.markers[2].pose.orientation.z = 0.5;
    box_cur.markers[2].pose.orientation.w = 0.5*std::sqrt(3.0f);

    visualization_msgs::MarkerArray box_pre = box_cur;

    while (ros::ok()){
        ros::spinOnce();
        box_pre = box_cur;
        for (int i = 0; i < box_pre.markers.size(); i++) box_pre.markers[i].action = visualization_msgs::Marker::DELETE;
        marker_pub.publish(box_pre);
        marker_pub.publish(box_cur);
        box_msg_pub.publish(box_cur);
        loop_rate.sleep();
    }
}