#ifndef OCTREE_MULTITREE_BASE_TREE_H
#define OCTREE_MULTITREE_BASE_TREE_H

#include "multitree_common.h"

namespace multitree{

// class TreeNode{
//     public:
//     TreeNode() = default;
//     virtual ~TreeNode() = default;
//     private:
// };

class TreeLeaf// : TreeNode
{
    public:
    TreeLeaf();
    TreeLeaf(const TreeLeaf &) = delete;
    TreeLeaf(TreeLeaf &&) = delete;
    TreeLeaf & operator=(const TreeLeaf &) = delete;
    TreeLeaf & operator=(TreeLeaf &&) = delete;
    ~TreeLeaf() = default;
    
    void setLeafInfo();
    void updateLeafInfo();
    void updateLeafStatus(char status);
    char getLeafStatus();
    inline int accumulateInfo();
    // void initLeaf();
    // void resetLeaf();
    private:
    char status_; //0 = dynamic, 1=static，后续考虑是否要在中途对节点信息、指针进行保留，减少中途的删除和回退新建，考虑重新命名
    int data_;
};

class TreeBranch// : TreeNode
{
    public:
    TreeBranch() = delete;
    TreeBranch(const TreeBranch &) = delete;
    TreeBranch(TreeBranch &&) = delete;
    TreeBranch & operator=(const TreeBranch &) = delete;
    TreeBranch & operator=(TreeBranch &&) = delete;
    TreeBranch(const int &log_leaf_level);
    ~TreeBranch();

    int resetBranch();
    
    
    inline char getBranchStatus(){ return status_;}
    inline void updateBranchStatus(const char &status){ status_ = status;}
    inline int getBranchLeafNum(){ return branch_leaf_num_;}
    inline TreeLeaf** getLeafPtrPtr(){ return leafs_pp_;}
    inline void accumulateValidLeafNum(const int &num){ valid_leaf_num_ += num;}
    inline int getBranchValidLeafNum(){ return valid_leaf_num_;}

    private:
    const int log_leaf_level_;
    char status_; //0 = inactive, 1 = active
    int branch_leaf_num_;
    int valid_leaf_num_;
    TreeLeaf** leafs_pp_;
};


class BaseBiLayerCubicTree{
    public:
    BaseBiLayerCubicTree() = delete;
    BaseBiLayerCubicTree(const BaseBiLayerCubicTree &) = delete;
    BaseBiLayerCubicTree(BaseBiLayerCubicTree &&) = delete;
    BaseBiLayerCubicTree & operator=(const BaseBiLayerCubicTree &) = delete;
    BaseBiLayerCubicTree & operator=(BaseBiLayerCubicTree &&) = delete;
    BaseBiLayerCubicTree(const int &log_level_branch, const int &log_level_leaf, const float &resolution, const int &single_mode);
    ~BaseBiLayerCubicTree();
    
    bool resetTree();

    // bool buildTree(float* points_p, const int &points_num);
    // bool updateIncrementFrameTree(float* points_p, const int &points_num);
    bool addPoint(const float &x, const float &y, const float &z);
    TreeLeaf* searchPoint(const float &x, const float &y, const float &z);
    TreeLeaf* addPointAndDynamicStatus(const float &x, const float &y, const float &z, const char &status);
    // bool updateCurrentFrameTree(float* points_p, const int &points_num);
    // bool updateStaticTree();
    // bool resetPreviousTree();
    bool checkCoordRangeConstrain(const int &max_x, const int &max_y, const int &max_z, const int &min_x, const int &min_y, const int &min_z);
    int getValidLeafNum();
    int getIntCoord(const float &x, const float &y, const float &z);
    float getResolution();

    bool deleteVoxel(const float &x, const float &y, const float &z);

    
    

    std::vector<int> checkLeafIntCoord();//仅用作检查正确性
    // std::vector<float> checkLeafRelativePosition();
    bool checkLeafAbsolutePosition(const float &origin_x, const float &origin_y, const float &origin_z, float* leaf_p);
    bool checkLeafSeqLen(int frame_seq_thres);
    std::vector<float> checkLeafFlattenAbsolutePosition(const float &z_abs_threshold, const float &origin_x, const float &origin_y, const float &origin_z);

    

    private:
    const int log_level_branch_;
    const int log_level_leaf_;
    const float resolution_;
    const int single_mode_;
    int total_log_level_;
    int direction_max_coord_;
    int coord_mask_branch_;
    int coord_mask_leaf_;
    int tree_branch_num_;

    TreeBranch** branches_pp_;
    int valid_leaf_num_;

    
};

}

namespace gpu_tree{


#pragma pack(4)
struct Node{
    int child_offset_mask;
};
#pragma pack()


}

#endif