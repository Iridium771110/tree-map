#ifndef OCTREE_MULTITREE_COMMON_H
#define OCTREE_MULTITREE_COMMON_H

#include <iostream>
#include <vector>
#include <cstring>
#include <math.h>

// #include <cuda_runtime_api.h>

namespace multitree{

    void tmpRot2Quaternion(const float* rot_p, float* quaternion_p);

    void quaternion2Rotation(const float* quaternion_p, float* rotation_p);

    template <typename T>
    __always_inline void rangeConstrain(const T &min_constrain, const T &max_constrain, T* data_p){
        if (*data_p < min_constrain){
            *data_p = min_constrain;
            return;
        } 
        if (*data_p > max_constrain){
            *data_p = max_constrain;
            return;
        }
    }

    void ptsTransform(const float* quaternion_p, const float* trans_p, float* xyzi_p, int pts_num, bool inverse);
}

#endif