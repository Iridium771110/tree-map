#ifndef OCTREE_MULTITREE_FOREST_H
#define OCTREE_MULTITREE_FOREST_H

#include "multitree_base_tree.h"

namespace multitree{

class BiLayerCubicTreeForest{
    //长绝对距离行进时，可能需要考虑增加中间中继坐标转换的方案，防止浮点数溢出
    public:
    BiLayerCubicTreeForest() = delete;
    BiLayerCubicTreeForest(const BiLayerCubicTreeForest &) = delete;
    BiLayerCubicTreeForest(BiLayerCubicTreeForest &&) = delete;
    BiLayerCubicTreeForest & operator=(const BiLayerCubicTreeForest &) = delete;
    BiLayerCubicTreeForest & operator=(BiLayerCubicTreeForest &&) = delete;
    BiLayerCubicTreeForest(const int &log_root_level_x, const int &log_root_level_y, const int &log_root_level_z, 
                        const int &log_level_branch, const int &log_level_leaf, const int &estimate_pts_num, const int &estimate_voxel_num,
                        const float &resolution, const float &angle_resolution, const int &single_mode,
                        const float &extern_defined_range_x, const float &extern_defined_range_y, const float &extern_defined_range_z);
    // BiLayerCubicTreeForest(const int &log_branch_level, const int &log_leaf_level, 
    //                     const float &range_radius_x, const float &range_radius_y, const float &range_radius_z,
    //                     const float &resolution, const int &single_mode);
    ~BiLayerCubicTreeForest();

    bool setOpticalFlowArgs(const int &catch_dist_adjust_mode, const float &catch_dist_angle_factor, 
                            const float &voxel_filter_pts_occlusion_range, const float &voxel_filter_line_range,
                            const float &voxel_filter_catch_dist_threshold, const float &voxel_filter_catch_angle_threshold, 
                            const float &pts_filter_voxel_occlusion_range, const float &pts_filter_line_range, 
                            const float &pts_filter_catch_dist_threshold, const float &pts_filter_catch_angle_threshold);
    bool setFlattenArgs(const float &z_min_threshold, const float &z_max_threshold,
                        const float &map_x_range, const float &map_y_range, const float &map_resolution);

    bool checkUpdateOriginRangeConstrain(const float &cur_center_x, const float &cur_center_y, const float &cur_center_z);
    // bool checkRangeConstrain(const float &cur_center_x, const float &cur_center_y, const float &cur_center_z);
    // bool addPoint(const float &pts_x, const float &pts_y, const float &pts_z);
    bool addFrame(const float &cur_center_x, const float &cur_center_y, const float &cur_center_z, float* pts_p, const int &pts_num);
    
    int getPointRootId(const float &pts_x, const float &pts_y, const float &pts_z);
    bool filterVoxelByCurFrame(const float &cur_center_x, const float &cur_center_y, const float &cur_center_z,
                                const float* voxels_p, const float* pts_p, const int &voxels_num, const int &pts_num);
    std::vector<char> curFrameRecordDynamic(const float &last_center_x, const float &last_center_y, const float &last_center_z,
                                const float* voxels_p, const float* pts_p, const int &voxels_num, const int &pts_num);
    bool addFrameUpdateDynamic(const float* pts_p, const char* pts_status_p, const int &pts_num,
    //                         const float &cur_center_x, const float &cur_center_y, const float &cur_center_z, std::vector<float> &check);
                            const float &cur_center_x, const float &cur_center_y, const float &cur_center_z);

    std::vector<float> checkAllLeafAbsolutePosition(const int & frame_seq_thres);//仅用作检查正确性，可视化可用，但也可以考虑其它方案
    std::vector<float> checkAllLeafRelativePosition(const float* quaternion_p, 
                                                    const bool &rotate);
    std::vector<float> checkAllLeafRelativePositionRotMat(const float* rotation_p, 
                                                    const bool &rotate);
                                                    //绝对变换pose，自身系到世界系，仅使用于可视化，要不还是用RT吧，emmmm，感觉不适合使用旋转，因为会造成格子混乱的问题
    // std::vector<float> checkAllLeafFlattenAbsolutePosition(const float &z_abs_threshold);
    // std::vector<float> checkAllLeafFlattenRelativePosition(const float &z_abs_threshold, const float &trans_x, const float &trans_y, const float &trans_z,
    //                                                 const float &rot_x, const float &rot_y, const float &rot_z, const float &rot_w);
    const char* getFlattenMapFromVoxel(const float* voxel_p, const int &voxel_num, int &map_rows, int &map_cols, int &valid_grids_num);
    bool getFlattenMapSize(int &rows, int &cols);

    private:
    const int log_root_level_x_;
    const int log_root_level_y_;
    const int log_root_level_z_;
    const int log_level_branch_;
    const int log_level_leaf_;
    const float resolution_;
    const int single_mode_;

    int catch_dist_adjust_mode_;
    float catch_dist_angle_factor_ = 4.0f;
    float voxel_filter_pts_occlusion_range_;
    float voxel_filter_line_range_;
    float voxel_filter_catch_dist_threshold_;
    float voxel_filter_catch_angle_threshold_;
    float pts_filter_voxel_occlusion_range_;
    float pts_filter_line_range_;
    float pts_filter_catch_dist_threshold_;
    float pts_filter_catch_angle_threshold_;

    float z_min_threshold_;
    float z_max_threshold_;
    float map_x_range_; 
    float map_y_range_; 
    float map_resolution_;
    int map_col_limit_;
    int map_row_limit_;
    float compute_offset_x_;
    float compute_offset_y_;
    int map_cols_;
    int map_rows_;

    int roots_num_;
    int roots_x_num_;
    int roots_y_num_;
    int roots_z_num_;
    int roots_x_mask_;
    int roots_y_mask_;
    int roots_z_mask_;

    float forest_center_x_;
    float forest_center_y_;
    float forest_center_z_;
    float pre_center_x_;
    float pre_center_y_;
    float pre_center_z_;
    float range_x_;
    float range_y_;
    float range_z_;//半总长
    float root_range_;//root总长
    float forest_min_x_;
    float forest_min_y_;
    float forest_min_z_;
    float forest_max_x_;
    float forest_max_y_;
    float forest_max_z_;

    BaseBiLayerCubicTree** roots_pp_ = nullptr; // z-y-x
    BaseBiLayerCubicTree** move_roots_pp_ = nullptr;

    int dynamic_leafs_num_ = 0;
    std::vector<char> flatten_map_;
    std::vector<float> dynamic_pts_; //应当是全局坐标
    std::vector<int> search_angle_id_;
    std::vector<int> angle_voxel_start_id_;
    std::vector<int> angle_voxel_end_id_;
    std::vector<int> angle_voxel_num_;
    std::vector<float> voxel_xyz_sqr_dist_;
    std::vector<float> voxel_tmp_dist_;
    std::vector<int> voxel_seq_id_;
    std::vector<float> catch_dist_;
    std::vector<int> pts_angle_id_;
    std::vector<float> pts_xyz_dist_;
    std::vector<char> filtered_pts_status_;
    std::vector<int> cur_angle_start_id_;
    std::vector<int> cur_angle_end_id_;
    std::vector<int> cur_angle_pts_num_;
    std::vector<int> cur_pts_angle_id_;
    std::vector<float> cur_xyz_sqr_dist_;
    std::vector<float> cur_tmp_dist_;
    std::vector<float> cur_catch_dist_;
    std::vector<int> pts_seq_id_;
    std::vector<int> voxel_angle_id_;
    std::vector<float> voxel_xyz_dist_;
    int horize_angle_pieces_;
    int vertikal_angle_pieces_;
    int angle_total_pieces_;
    int horize_angle_max_id_;
    int vertikal_angle_max_id_;
    const float angle_resolution_;
    const float degree2radius_fac_ = 180.0f / M_PI;
    float reso2radius_fac_;

    inline void updateCatchDist(float* xyz_dist_p, int start_id, int end_id, float range_threshold_sqr,
                    float line_x, float line_y, float line_z, float sqr_line_dist_origin, float &sqr_line_dist);
    inline char updateFilteredOutVoxel(float* line_xyz_dist_p, float* line_catch_dist_p, int start_id, int end_id, 
                            float voxel_x, float voxel_y, float voxel_z, float voxel_dist, float sqr_dist,
                            float range_threshold_sqr, float catch_dist_threshold, float angle_ref_threshold);
    inline bool getSearchAngleId(const int &vertikal_angle_id, const int &horize_angle_id);

    bool setupStartEndId(int* start_id_p, int* end_id_p, int* num_p);
    bool setupAngleDist(float center_x, float center_y, float center_z, int coord_num,
                                            const float* coord_p, float* tmp_dist_p, int* angle_coord_num_p, int* coord_angle_id_p);
};

}

#endif